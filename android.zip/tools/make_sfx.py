#!/usr/bin/env python3
"""Makes the interface sounds of the app (app/src/main/res/raw/sfx_*.wav).
Everything is synthesized here (no samples from anywhere), so there is nothing to license.
Run:  python3 tools/make_sfx.py      (needs numpy)  - then rebuild the app."""
import os, wave
import numpy as np

SR = 32000
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "res", "raw")
rng = np.random.default_rng(7)


def t_of(dur):
    return np.arange(int(SR * dur)) / SR


def env_decay(t, rate, attack=0.004):
    e = np.exp(-rate * t)
    a = np.minimum(1.0, t / attack) if attack > 0 else 1.0
    return e * a


def tone(freq, dur, rate=18.0, harm=(1.0,), attack=0.004):
    """Soft bell / pluck: sine + optional partials, exponential decay."""
    t = t_of(dur)
    f = np.asarray(freq, dtype=float) if np.ndim(freq) else np.full_like(t, float(freq))
    ph = 2 * np.pi * np.cumsum(f) / SR
    y = sum(h * np.sin(ph * (k + 1)) for k, h in enumerate(harm))
    return y * env_decay(t, rate, attack)


def sweep(f0, f1, dur, rate=18.0, harm=(1.0,), attack=0.004):
    t = t_of(dur)
    f = f0 * (f1 / f0) ** (t / dur)
    return tone(f, dur, rate, harm, attack)


def lowpass(x, k):
    """One-pole low-pass, k in 0..1 (bigger = brighter)."""
    y = np.zeros_like(x)
    a = 0.0
    for i, v in enumerate(x):
        a += k * (v - a)
        y[i] = a
    return y


def noise(dur):
    return rng.standard_normal(int(SR * dur))


def place(base, part, at):
    i = int(SR * at)
    n = min(len(part), len(base) - i)
    if n > 0:
        base[i:i + n] += part[:n]
    return base


def blank(dur):
    return np.zeros(int(SR * dur))


def finish(name, x, peak=0.8, fade=0.012):
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    n = int(SR * fade)
    if n < len(x):
        x[-n:] *= np.linspace(1, 0, n)
    pcm = (np.clip(x, -1, 1) * 32767).astype("<i2")
    os.makedirs(OUT, exist_ok=True)
    with wave.open(os.path.join(OUT, name + ".wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    print("%-14s %5.2fs %6d bytes" % (name, len(x) / SR, len(pcm) * 2))


# ---- small everyday sounds --------------------------------------------------
# tap: a soft, round pop
finish("sfx_tap", sweep(900, 520, 0.07, rate=55, harm=(1, 0.25)) + 0.12 * lowpass(noise(0.07), 0.3) * env_decay(t_of(0.07), 120))

# tab / segment: two quick rising ticks
x = blank(0.14); place(x, tone(880, 0.09, 40, (1, .3)), 0); place(x, tone(1320, 0.09, 40, (1, .3)), 0.045)
finish("sfx_tab", x)

# select (option / chip): single light tick
finish("sfx_select", tone(1250, 0.06, 70, (1, .2)))

# toggle on / off
x = blank(0.12); place(x, tone(1000, 0.06, 60), 0); place(x, tone(1500, 0.07, 55), 0.04); finish("sfx_on", x)
x = blank(0.12); place(x, tone(1400, 0.06, 60), 0); place(x, tone(850, 0.07, 55), 0.04); finish("sfx_off", x)

# open sheet: soft rising whoosh; close sheet: falling
t = t_of(0.2)
w = lowpass(noise(0.2), 0.15) * np.sin(np.pi * t / 0.2) ** 1.5
finish("sfx_open", 0.9 * w + 0.5 * sweep(320, 760, 0.2, rate=9, attack=0.03))
finish("sfx_close", 0.9 * w[::-1] * 0.8 + 0.4 * sweep(620, 280, 0.2, rate=14, attack=0.01))

# notice: friendly two-note ping (information, "saving...")
x = blank(0.4); place(x, tone(988, 0.3, 11, (1, .35)), 0); place(x, tone(1319, 0.3, 11, (1, .35)), 0.09); finish("sfx_notice", x, 0.7)

# success: bright rising chime
x = blank(0.65)
place(x, tone(784, 0.5, 7, (1, .4, .15)), 0)
place(x, tone(1175, 0.55, 6, (1, .4, .15)), 0.085)
place(x, tone(1568, 0.6, 5, (1, .3, .1)), 0.17)
finish("sfx_success", x)

# error: two low, dull pulses (not scary)
x = blank(0.34)
for at in (0.0, 0.14):
    p = lowpass(tone(210, 0.14, 16, (1, .5, .33, .2)), 0.12)
    place(x, p, at)
finish("sfx_error", x, 0.85)

# delete: falling thud with a little air
t = t_of(0.26)
finish("sfx_delete", sweep(520, 110, 0.26, rate=11, harm=(1, .3)) + 0.35 * lowpass(noise(0.26), 0.2) * env_decay(t, 22))

# locked content: short knock + dull tick
x = blank(0.28); place(x, sweep(170, 105, 0.16, rate=22, harm=(1, .4)), 0); place(x, tone(430, 0.1, 50), 0.11); finish("sfx_locked", x, 0.85)

# video: play (rising), pause (falling), skip (swish)
x = blank(0.16); place(x, tone(620, 0.08, 45, (1, .3)), 0); place(x, tone(930, 0.1, 40, (1, .3)), 0.05); finish("sfx_play", x)
x = blank(0.16); place(x, tone(930, 0.08, 45, (1, .3)), 0); place(x, tone(620, 0.1, 40, (1, .3)), 0.05); finish("sfx_pause", x)
t = t_of(0.16)
sw = lowpass(noise(0.16), 0.35) * np.sin(np.pi * t / 0.16)
finish("sfx_skip", sw + 0.25 * sweep(500, 1100, 0.16, rate=14, attack=0.02), 0.7)

# exam result: pass = little fanfare, fail = gentle fall
x = blank(1.1)
for i, f in enumerate((523, 659, 784, 1047)):
    place(x, tone(f, 0.7, 5.5, (1, .45, .2)), 0.09 * i)
place(x, tone(1319, 0.8, 4.5, (1, .3)), 0.36)
finish("sfx_pass", x)
x = blank(0.8)
place(x, tone(392, 0.5, 7, (1, .4, .15)), 0); place(x, tone(311, 0.6, 6, (1, .4, .15)), 0.17)
finish("sfx_fail", x, 0.7)

# ---- launch animation: 3.3 s ------------------------------------------------
# 0 - 2.26 s  dust is pulled together (rising shimmer + airy noise)
# 2.26 s      the flash / burst of the icon (soft thump + bell chord)
# 2.3 - 3.3 s sparks (small high pings) fading out
D = 3.3; BURST = 2.26
x = blank(D)
t = t_of(D)
g = np.clip(t / BURST, 0, 1)
rise = g ** 2.2
# airy dust: noise that brightens and swells
air = lowpass(noise(D), 0.04) * 0.6 + lowpass(noise(D), 0.25) * 0.4
air = air * (0.15 + rise) * (t < BURST + 0.04) * np.minimum(1, np.maximum(0, (BURST + 0.04 - t) / 0.05))
# pad: detuned sines gliding upward, with a slow shimmer
f = 130 * (4.2 ** g)
ph1 = 2 * np.pi * np.cumsum(f) / SR
ph2 = 2 * np.pi * np.cumsum(f * 1.007) / SR
ph3 = 2 * np.pi * np.cumsum(f * 2.005) / SR
pad = (np.sin(ph1) + np.sin(ph2) + 0.4 * np.sin(ph3)) * (0.08 + rise) * (1 + 0.25 * np.sin(2 * np.pi * (3 + 6 * g) * t))
pad = pad * (t < BURST + 0.03) * np.minimum(1, np.maximum(0, (BURST + 0.03 - t) / 0.04))
x += 0.55 * air + 0.5 * pad
# faint twinkles while the flask forms (from 1.5 s)
for at in np.linspace(1.45, 2.2, 9):
    place(x, 0.09 * tone(rng.choice([1568, 1760, 2093, 2349]), 0.18, 22), float(at))
# burst
place(x, 1.0 * sweep(160, 55, 0.5, rate=7, harm=(1, .4)), BURST)
for f0, d in ((1047, 0.0), (1319, 0.02), (1568, 0.04), (2093, 0.06)):
    place(x, 0.55 * tone(f0, 1.0, 3.2, (1, .35, .12)), BURST + d)
place(x, 0.5 * lowpass(noise(0.35), 0.5) * env_decay(t_of(0.35), 10), BURST)
# sparks
for k in range(14):
    at = BURST + 0.05 + k * 0.07 + rng.random() * 0.03
    place(x, 0.12 * (1 - k / 16) * tone(rng.choice([2093, 2637, 3136, 3520, 4186]), 0.16, 25), float(at))
finish("sfx_splash", x, 0.85, 0.15)
