package com.moknight.nexoraedu

import android.content.Context

/**
 * Release 52: first wiring step. The local login / sign-up stays exactly as it was (it decides whether the user gets in).
 * Right after it succeeds, this mirrors the account to Supabase in the background:
 *  sign in -> if the account does not exist there yet, sign up -> (teacher with a code) claim the teacher code.
 * Silent on purpose: no new screen, no new string, never blocks, and a server that is not ready (SQL not run, offline) changes nothing.
 * Existing users are mirrored the next time they type their password (the password is needed; it is never stored).
 */
object ServerSync {
    private fun sp(c: Context) = c.getSharedPreferences("server_sync", Context.MODE_PRIVATE)

    /** true = the server session belongs to this email. */
    fun mirrored(c: Context, email: String) = Remote.signedIn(c) && sp(c).getString("email", "") == email

    /** Teacher codes are written XXXXXX-YYYYYY on the server; the user may type them with spaces, dashes or lower case. */
    private fun serverCode(raw: String): String {
        val s = raw.uppercase().filter { it in "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" }
        return if (s.length == 12) s.substring(0, 6) + "-" + s.substring(6) else raw.trim()
    }

    /** [role] = "student" | "teacher" | "admin". [code] = the teacher code typed at sign-up (empty otherwise). */
    fun mirror(c: Context, role: String, email: String, pass: String, code: String = "") {
        if (!Remote.enabled) return
        if (mirrored(c, email) && code.isEmpty()) { AdminControl.entered(c, role, "signin"); return }   // release 54: already linked, only tell the main admin
        val ctx = c.applicationContext
        val st = if (role == "student") Store.findStudent(ctx, email) else null
        val name = if (role == "teacher") Store.teacherName(ctx) else st?.name.orEmpty()
        val phone = st?.phone.orEmpty()
        val grade = st?.grade.orEmpty()
        val ready = {
            sp(ctx).edit().putString("email", email).apply()
            // TODO(server): the teacher code is only claimed here; if the server was not ready then, promote the teacher by hand (see SQL notes).
            if (role == "teacher" && code.isNotEmpty()) Remote.claimTeacher(ctx, serverCode(code)) { ok -> if (ok) AdminControl.entered(ctx, role, "signup") }
            else AdminControl.entered(ctx, role, "signin")   // release 54: admin -> becomes admin on the server (first = main), teacher -> alert to the main admin
        }
        Remote.signIn(ctx, email, pass) { ok ->
            if (ok) ready()
            else Remote.signUp(ctx, email, pass, name, phone, grade) { made -> if (made && Remote.signedIn(ctx)) ready() }   // release 57: an admin gets a (limited) account on the server too; the activation code makes it admin
        }
    }

    /**
     * Release 53: creating an account works ONLY online. The server must accept it first; the local account is created by [done]'s caller
     * only when this answers null. Otherwise it answers a string id: [R.string.err_need_net] (no internet / server refused) or
     * [R.string.err_tcode_invalid] (teacher code unknown to the server). Without a server configured (Remote.enabled false) it answers null at once.
     */
    fun register(c: Context, role: String, email: String, pass: String, name: String, phone: String, grade: String, code: String, done: (Int?) -> Unit) {
        if (!Remote.enabled) return done(null)
        val ctx = c.applicationContext
        Remote.signOut(ctx)
        val after = {
            sp(ctx).edit().putString("email", email).apply()
            if (role == "teacher") Remote.claimTeacher(ctx, serverCode(code)) { ok ->
                if (ok) AdminControl.entered(ctx, "teacher", "signup")   // release 54: alert to the main admin
                done(if (ok) null else R.string.err_tcode_invalid)
            }
            else if (role == "admin") AdminControl.registerAdmin(ctx, serverCode(code)) { r ->   // release 57: first admin = main (no code), others need the one-time code
                done(when { r == null -> R.string.err_need_net; r.ok -> null; r.reason == "locked" -> R.string.err_admin_locked; else -> R.string.err_admin_code })
            }
            else done(null)
        }
        Remote.signUp(ctx, email, pass, name, phone, grade) { made ->
            if (made && Remote.signedIn(ctx)) after()
            else Remote.signIn(ctx, email, pass) { ok -> if (ok) after() else done(R.string.err_need_net) } // already on the server (e.g. a retry)
        }
    }

    fun signOut(c: Context) { AdminControl.reset(c); Remote.signOut(c); sp(c).edit().clear().apply() }
}
