package com.moknight.nexoraedu

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Build
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Glass look: soft glowing colour orbs drifting slowly behind every screen (the "blurred background"). */
class AuroraView(ctx: Context) : View(ctx) {
    private class Orb(val color: Int, val bx: Float, val by: Float, val ax: Float, val ay: Float,
                       val fx: Float, val fy: Float, val phase: Float, val radius: Float) {
        var shader: Shader? = null
    }

    private val dark = Prefs.dark(ctx)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val orbs: List<Orb>
    private var phase = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 26000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    init {
        val c1 = themeColor(ctx, R.attr.p1)
        val c2 = themeColor(ctx, R.attr.p2)
        val c3 = ctx.resources.getColor(R.color.orb3, ctx.theme)
        orbs = listOf(
            Orb(c1, 0.15f, 0.12f, 0.10f, 0.06f, 1f, 1f, 0.0f, 0.62f),
            Orb(c2, 0.88f, 0.42f, 0.08f, 0.09f, 1f, 2f, 1.7f, 0.58f),
            Orb(c3, 0.30f, 0.92f, 0.12f, 0.05f, 2f, 1f, 3.4f, 0.55f),
        )
        isClickable = false
        isFocusable = false
    }

    private fun themeColor(c: Context, attr: Int): Int {
        val v = TypedValue()
        c.theme.resolveAttribute(attr, v, true)
        return v.data
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val base = max(w, h).toFloat()
        val a = if (dark) 0x66 else 0x40
        orbs.forEach { o ->
            val r = base * o.radius
            val center = (o.color and 0x00FFFFFF) or (a shl 24)
            val mid = (o.color and 0x00FFFFFF) or ((a * 0.45f).toInt() shl 24)
            o.shader = RadialGradient(0f, 0f, r, intArrayOf(center, mid, Color.TRANSPARENT), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val base = max(w, h)
        val t = (phase * 2.0 * PI).toFloat()
        orbs.forEach { o ->
            val sh = o.shader ?: return@forEach
            val x = w * (o.bx + o.ax * sin(t * o.fx + o.phase))
            val y = h * (o.by + o.ay * cos(t * o.fy + o.phase))
            paint.shader = sh
            canvas.save()
            canvas.translate(x, y)
            canvas.drawCircle(0f, 0f, base * o.radius, paint)
            canvas.restore()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!anim.isStarted) anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    /** Stops drawing while the screen is not visible, so the animation costs nothing in the background. */
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (!anim.isStarted) return
        if (visibility == VISIBLE) anim.resume() else anim.pause()
    }
}

/** A soft "press" for anything tappable: shrinks a little while the finger is down, springs back on release. */
@SuppressLint("ClickableViewAccessibility")
fun pressable(v: View) {
    if (v.getTag(R.id.press_tag) != null) return
    v.setTag(R.id.press_tag, true)
    v.setOnTouchListener { view, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val small = if (view.width > view.resources.displayMetrics.density * 220) 0.975f else 0.93f
                view.animate().setStartDelay(0).setInterpolator(DecelerateInterpolator())
                    .scaleX(small).scaleY(small).setDuration(110).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                view.animate().setStartDelay(0).setInterpolator(OvershootInterpolator(2.2f))
                    .scaleX(1f).scaleY(1f).setDuration(260).start()
                // a finger lifted on the view = a tap (a cancelled touch, like a scroll, stays silent)
                if (e.actionMasked == MotionEvent.ACTION_UP && e.x >= 0 && e.y >= 0 && e.x <= view.width && e.y <= view.height) Sfx.tap(view)
            }
        }
        false // never consume: normal clicks keep working
    }
}

/** Gives [pressable] to every tappable view under [root] (text fields are left alone). */
fun walkPress(root: View) {
    if (root is EditText) return
    if (root.isClickable) pressable(root)
    if (root is ViewGroup) for (i in 0 until root.childCount) walkPress(root.getChildAt(i))
}

/** Children of [parent] slide up and fade in one after the other. */
fun staggerIn(parent: ViewGroup, dp: Float, maxItems: Int = 14) {
    for (i in 0 until min(parent.childCount, maxItems)) {
        val c = parent.getChildAt(i)
        c.alpha = 0f
        c.translationY = 18f * dp
        c.animate().setStartDelay(i * 45L).setInterpolator(DecelerateInterpolator(2f))
            .alpha(1f).translationY(0f).setDuration(380).start()
    }
}

/** Coloured glow under a button / avatar (Android 9+; older phones just get a normal shadow). */
fun glowView(v: View, color: Int, elevationDp: Float = 8f) {
    v.elevation = elevationDp * v.resources.displayMetrics.density
    if (Build.VERSION.SDK_INT >= 28) {
        v.outlineSpotShadowColor = color
        v.outlineAmbientShadowColor = color
    }
    (v.parent as? ViewGroup)?.clipChildren = false
}

/** Real background blur behind a dialog on Android 12+ (ignored on older phones / when the device turns blur off). */
fun blurBehind(d: Dialog, radius: Int = 26) {
    val w = d.window ?: return
    w.setDimAmount(0.32f)
    if (Build.VERSION.SDK_INT >= 31) {
        w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
        val a = w.attributes
        a.blurBehindRadius = radius
        w.attributes = a
    }
}

/** A sheet slides up and fades in. */
fun sheetIn(root: View, dp: Float) {
    root.alpha = 0f
    root.translationY = 56f * dp
    root.animate().setStartDelay(0).setInterpolator(DecelerateInterpolator(2.2f))
        .alpha(1f).translationY(0f).setDuration(320).start()
}
