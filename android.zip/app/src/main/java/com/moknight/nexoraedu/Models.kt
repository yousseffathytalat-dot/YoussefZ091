package com.moknight.nexoraedu

/** A chapter (باب) groups lessons. */
/** A chapter (باب) is also the "course". [price] is in EGP, 0 = free. */
data class Chapter(val id: String, var title: String, var price: Int = 0)

/** A lesson. [chapterId] is empty for a standalone YouTube video. [yt] is the 11-char YouTube id (may be empty). */
data class Lesson(
    val id: String, var chapterId: String, var title: String, var yt: String, val at: Long = System.currentTimeMillis(),
    /** false = hidden from students (the teacher still sees it). */
    var published: Boolean = true,
    /** "yt" = YouTube link, "up" = video file uploaded to the platform (filesDir/videos/<id>). */
    var src: String = "yt",
    /** Price in EGP, 0 = free. */
    var price: Int = 0,
    /** YouTube title/thumbnail imported from the link (may be empty). */
    var thumb: String = ""
)

/** A PDF stored in the app's private storage (filesDir/docs/<id>.pdf). [kind] is "book" or "file". */
data class Doc(val id: String, var title: String, val kind: String, val at: Long = System.currentTimeMillis())

/** Multiple-choice question in the teacher's question bank. */
data class Question(val id: String, var text: String, var chapter: String, var options: List<String>, var answer: Int)

data class Exam(val id: String, var title: String, var official: Boolean, var qids: List<String>, val at: Long = System.currentTimeMillis())

data class Result(val examId: String, val email: String, val score: Int, val correct: Int, val total: Int, val at: Long)

data class Homework(val id: String, var title: String, var note: String, val at: Long = System.currentTimeMillis())

/** A student's answer to a homework. [photo] is the file name in filesDir/hw (empty = no photo). [grade] is -1 until graded (out of 10). */
data class Submission(
    val hwId: String, val email: String, var text: String, var photo: String,
    var grade: Int = -1, var note: String = "", var at: Long = System.currentTimeMillis()
)

data class Note(val text: String, val date: String)

/** A teacher announcement shown on the students' home screen. */
data class Announcement(val id: String, var title: String, var text: String, val at: Long = System.currentTimeMillis())

/** Access to paid content: [target] is "l:<lessonId>" or "c:<chapterId>"; [mode] is "online" (paid in app), "cash" (teacher took cash) or "free" (teacher gift). */
data class Grant(val target: String, val email: String, val mode: String, val by: String, val at: Long = System.currentTimeMillis())
