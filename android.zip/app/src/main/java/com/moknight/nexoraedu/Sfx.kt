package com.moknight.nexoraedu

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock
import android.provider.Settings
import android.view.View

/**
 * Short interface sounds (res/raw/sfx_*.wav, made by tools/make_sfx.py). One SoundPool for the whole app.
 * - Follows the phone: silent / vibrate mode mutes it, and so does the system "Touch sounds" switch.
 * - A plain tap is skipped when a more specific sound (success, error, sheet...) plays at the same moment.
 */
object Sfx {
    enum class S(val res: Int, val vol: Float) {
        TAP(R.raw.sfx_tap, 0.45f),
        TAB(R.raw.sfx_tab, 0.55f),
        SELECT(R.raw.sfx_select, 0.5f),
        ON(R.raw.sfx_on, 0.55f),
        OFF(R.raw.sfx_off, 0.55f),
        OPEN(R.raw.sfx_open, 0.5f),
        CLOSE(R.raw.sfx_close, 0.4f),
        NOTICE(R.raw.sfx_notice, 0.55f),
        SUCCESS(R.raw.sfx_success, 0.7f),
        ERROR(R.raw.sfx_error, 0.75f),
        DELETE(R.raw.sfx_delete, 0.7f),
        LOCKED(R.raw.sfx_locked, 0.7f),
        PLAY(R.raw.sfx_play, 0.5f),
        PAUSE(R.raw.sfx_pause, 0.5f),
        SKIP(R.raw.sfx_skip, 0.5f),
        PASS(R.raw.sfx_pass, 0.75f),
        FAIL(R.raw.sfx_fail, 0.7f),
        SPLASH(R.raw.sfx_splash, 0.8f),
    }

    private var pool: SoundPool? = null
    private var app: Context? = null
    private val ids = HashMap<S, Int>()
    private val ready = HashSet<Int>()
    private val lastPlayed = HashMap<S, Long>()
    private var lastAction = 0L
    private var pending: S? = null

    /** Safe to call from every screen: loads the sounds only once. */
    fun init(ctx: Context) {
        if (pool != null) return
        val a = ctx.applicationContext
        app = a
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val p = SoundPool.Builder().setMaxStreams(5).setAudioAttributes(attrs).build()
        p.setOnLoadCompleteListener { sp, id, status ->
            if (status != 0) return@setOnLoadCompleteListener
            ready.add(id)
            // the launch sound is asked for before loading ends on a cold start: play it now (still in time)
            val s = pending
            if (s != null && ids[s] == id) { pending = null; sp.play(id, s.vol, s.vol, 1, 0, 1f) }
        }
        S.values().forEach { ids[it] = p.load(a, it.res, 1) }
        pool = p
    }

    private fun allowed(): Boolean {
        val c = app ?: return false
        return try {
            Settings.System.getInt(c.contentResolver, Settings.System.SOUND_EFFECTS_ENABLED, 1) != 0
        } catch (e: Exception) { true }
    }

    fun play(s: S) {
        val p = pool ?: return
        val now = SystemClock.uptimeMillis()
        if (s != S.TAP) lastAction = now
        if (now - (lastPlayed[s] ?: 0L) < 45L) return // the same sound twice in a blink
        lastPlayed[s] = now
        if (!allowed()) return
        val id = ids[s] ?: return
        if (id in ready) p.play(id, s.vol, s.vol, 1, 0, 1f)
        else if (s == S.SPLASH) pending = s
    }

    /** Plain tap on a view: waits a moment so a more specific sound (played by the click itself) can replace it. */
    fun tap(v: View) {
        v.postDelayed({ if (SystemClock.uptimeMillis() - lastAction > 150L) play(S.TAP) }, 35L)
    }

    /** The sound that fits a toast message, taken from the name of its string (err_*, *_saved, *_copied...). */
    fun forToast(c: Context, res: Int) {
        val n = try { c.resources.getResourceEntryName(res) } catch (e: Exception) { "" }
        val bad = n.startsWith("err_") || n.contains("_err") || n.endsWith("_fail") || n.endsWith("_bad_limit") ||
            n == "grant_none" || n == "ex_empty_questions"
        val good = n.endsWith("_saved") || n.endsWith("_done") || n.endsWith("_copied") || n.endsWith("_changed") ||
            n.endsWith("_imported") || n == "pw_changed"
        play(if (bad) S.ERROR else if (good) S.SUCCESS else S.NOTICE)
    }
}
