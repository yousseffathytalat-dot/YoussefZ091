package com.moknight.nexoraedu

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import java.io.File

class StudentActivity : ShellActivity() {
    private var me: Student? = null
    private val email get() = me!!.email

    private val openChapters = mutableSetOf<String>()
    private var typeFilter = "all"

    override fun ready(): Boolean {
        val s = Store.session(this)
        me = if (s?.first == "student") Store.findStudent(this, s.second) else null
        return me != null
    }

    override fun hello() = R.string.welcome
    override fun displayName() = me!!.name
    override fun avatarEmail() = me?.email

    override fun buildTabs() = listOf(
        Tab(R.string.tab_home, R.drawable.ic_home) { home() },
        Tab(R.string.tab_subjects, R.drawable.ic_book) { study() },
        Tab(R.string.tab_tests, R.drawable.ic_exam) { examsTab() },
        Tab(R.string.tab_profile, R.drawable.ic_user) { profile() }
    )

    // ------------------------------------------------------------------ favorites / save sheet

    private fun collName(c: String) = when (c) {
        "fav" -> R.string.coll_fav
        "later" -> R.string.coll_later
        else -> R.string.coll_imp
    }

    private fun collIcon(c: String) = when (c) {
        "fav" -> R.drawable.ic_heart
        "later" -> R.drawable.ic_clock
        else -> R.drawable.ic_star
    }

    private fun typeName(t: String) = getString(
        when (t) {
            "lesson" -> R.string.type_lesson
            "video" -> R.string.type_video
            "book" -> R.string.type_book
            else -> R.string.type_file
        }
    )

    /** Heart (favorites) and bookmark (review later / important) buttons for one item. */
    private fun favButtons(type: String, id: String): List<View> {
        val key = "$type|$id"
        val heart = iconBtn(R.drawable.sv_heart, R.color.heart_tint) {}
        val mark = iconBtn(R.drawable.sv_mark, R.color.nav_tint) {}
        fun sync() {
            heart.isSelected = Store.isIn(this, email, "fav", key)
            mark.isSelected = Store.isIn(this, email, "later", key) || Store.isIn(this, email, "imp", key)
        }
        sync()
        heart.setOnClickListener { Store.toggleIn(this, email, "fav", key); sync() }
        mark.setOnClickListener {
            sheet(getString(R.string.save_to)) { c, d ->
                Store.collections.forEach { coll ->
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = android.view.Gravity.CENTER_VERTICAL
                        layoutParams = lp(top = 8)
                    }
                    row.addView(iconBtn(collIcon(coll), R.color.mut) {})
                    row.addView(label(getString(collName(coll)), 15f, R.color.tx, true).apply {
                        layoutParams = lp(w = 0, weight = 1f, start = 6)
                    })
                    row.addView(Switch(this).apply {
                        isChecked = Store.isIn(this@StudentActivity, email, coll, key)
                        setOnCheckedChangeListener { _, on ->
                            if (on != Store.isIn(this@StudentActivity, email, coll, key)) Store.toggleIn(this@StudentActivity, email, coll, key)
                        }
                    })
                    c.addView(row)
                }
                c.addView(link(getString(R.string.done), top = 8) { d.dismiss() })
                d.setOnDismissListener { sync() }
            }
        }
        return listOf(heart, mark)
    }

    private class Res(val type: String, val title: String, val icon: Int, val open: () -> Unit)

    /** Turns a saved key ("type|id") into something we can show; null if the content was deleted. */
    private fun resolve(key: String): Res? {
        val type = key.substringBefore('|')
        val id = key.substringAfter('|')
        return when (type) {
            "lesson", "video" -> Store.publishedLesson(this, id)?.let { l -> Res(type, l.title, R.drawable.ic_play) { openVideo(l, email) } }
            "book", "file" -> Store.doc(this, id)?.let { d ->
                Res(type, d.title, if (type == "book") R.drawable.ic_book else R.drawable.ic_note) { openDoc(d) }
            }
            else -> null
        }
    }

    private fun savedCount(c: String) = Store.favList(this, email, c).count { resolve(it) != null }

    // ------------------------------------------------------------------ row builders

    private fun lessonRow(l: Lesson, parent: LinearLayout = body) {
        val seen = Store.history(this, email).contains(l.id)
        val locked = !Access.canView(this, email, l)
        val sub = when {
            !Store.hasVideo(this, l) -> getString(R.string.no_video_yet)
            locked -> getString(R.string.locked_badge, getString(R.string.price_egp, if (l.price > 0) l.price else Access.coursePrice(this, l)))
            seen -> getString(R.string.watched)
            else -> null
        }
        val type = if (l.chapterId.isEmpty()) "video" else "lesson"
        val row = itemRow(if (locked) R.drawable.ic_lock else R.drawable.ic_play, l.title, sub, favButtons(type, l.id)) { openVideo(l, email) }
        if (seen && !locked && Store.hasVideo(this, l)) row.findViewById<TextView>(R.id.rowSub).drawTick(accent())
        parent.addView(row)
    }

    private fun docRow(d: Doc, parent: LinearLayout = body) {
        parent.addView(
            itemRow(if (d.kind == "book") R.drawable.ic_book else R.drawable.ic_note, d.title, null, favButtons(d.kind, d.id)) { openDoc(d) }
        )
    }

    // ------------------------------------------------------------------ tabs

    private fun home() {
        val s = me!!
        addCard(getString(R.string.welcome), s.name, s.grade)

        val anns = Store.announcements(this).sortedByDescending { it.at }.take(3)
        if (anns.isNotEmpty()) {
            heading(getString(R.string.ann_title))
            anns.forEach { a -> addCard(dateText(a.at), a.title, a.text) }
        }

        heading(getString(R.string.sec_progress))
        val p = Store.progress(this, email)
        val pct = Store.percent(p)
        val prog = card(getString(R.string.study_progress), "$pct%", getString(R.string.lessons_done_of, p.first, p.second))
        (prog as LinearLayout).addView(bar(pct, 12))
        val chapters = Store.chapters(this)
        val seen = Store.history(this, email).toSet()
        val all = Store.publishedLessons(this)
        chapters.forEach { ch ->
            val ls = all.filter { it.chapterId == ch.id }
            if (ls.isNotEmpty()) {
                prog.addView(label(ch.title, 12f, R.color.mut, top = 12))
                prog.addView(bar(ls.count { it.id in seen } * 100 / ls.size, 4))
            }
        }
        body.addView(prog)

        val last = Store.history(this, email).firstNotNullOfOrNull { Store.publishedLesson(this, it) }
        val cont = card(getString(R.string.continue_studying), last?.title ?: getString(R.string.pick_lesson_hint), null) as LinearLayout
        if (last != null) cont.addView(primary(getString(R.string.resume_watching), 12) { openVideo(last, email) })
        body.addView(cont)

        heading(getString(R.string.sec_quick))
        addTiles(
            listOf(
                TileSpec(R.drawable.ic_book, R.string.tab_subjects) { select(1) },
                TileSpec(R.drawable.ic_folder, R.string.books_title) { show { booksScreen() } },
                TileSpec(R.drawable.ic_heart, R.string.coll_fav, savedCount("fav")) { openCollection("fav") }
            )
        )

        val newestLessons = all.sortedByDescending { it.at }.take(2)
        val docs = Store.docs(this).sortedByDescending { it.at }
        val newBooks = docs.filter { it.kind == "book" }.take(2)
        val newFiles = docs.filter { it.kind == "file" }.take(2)
        if (newestLessons.isEmpty() && newBooks.isEmpty() && newFiles.isEmpty()) {
            addEmpty(R.drawable.ic_book, R.string.empty_courses, R.string.empty_courses_sub)
            return
        }
        heading(getString(R.string.latest_content))
        newestLessons.forEach { lessonRow(it) }
        newBooks.forEach { docRow(it) }
        newFiles.forEach { docRow(it) }
    }

    private fun study() {
        val lessons = Store.publishedLessons(this)
        val chapters = Store.chapters(this)
        val docs = Store.docs(this)
        if (lessons.isEmpty() && chapters.isEmpty() && docs.isEmpty()) {
            addEmpty(R.drawable.ic_book, R.string.empty_courses, R.string.empty_courses_sub)
            return
        }
        val videos = lessons.filter { it.chapterId.isEmpty() }
        if (videos.isNotEmpty()) {
            heading(getString(R.string.videos))
            videos.forEach { lessonRow(it) }
        }
        if (chapters.isNotEmpty()) heading(getString(R.string.chapters_title))
        val seen = Store.history(this, email).toSet()
        chapters.forEach { ch ->
            val ls = lessons.filter { it.chapterId == ch.id }
            val done = ls.count { it.id in seen }
            val head = card(null, ch.title, getString(R.string.lessons_done_of, done, ls.size)) as LinearLayout
            head.addView(bar(if (ls.isEmpty()) 0 else done * 100 / ls.size, 10))
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = if (ch.id in openChapters) View.VISIBLE else View.GONE
            }
            ls.forEach { lessonRow(it, box) }
            head.setOnClickListener {
                if (ch.id in openChapters) openChapters.remove(ch.id) else openChapters.add(ch.id)
                box.visibility = if (ch.id in openChapters) View.VISIBLE else View.GONE
            }
            body.addView(head)
            body.addView(box)
        }
        val books = docs.filter { it.kind == "book" }
        if (books.isNotEmpty()) {
            heading(getString(R.string.books_title))
            books.forEach { docRow(it) }
        }
        val files = docs.filter { it.kind == "file" }
        if (files.isNotEmpty()) {
            heading(getString(R.string.files_title))
            files.forEach { docRow(it) }
        }
    }

    /** Big round profile photo (or the first letter) with change / remove links. Stored in filesDir/avatars. */
    private fun avatarBlock(s: Student) {
        val f = Store.avatarFile(this, s.email)
        val bmp = decodeScaled(f, 384)
        val box = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(96), dp(96)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(16) }
        }
        box.addView(TextView(this).apply {
            text = s.name.firstOrNull()?.toString()?.uppercase() ?: "?"
            gravity = Gravity.CENTER
            textSize = 36f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(color(R.color.white))
            setBackgroundResource(R.drawable.avatar_bg)
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        if (bmp != null) box.addView(ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundResource(R.drawable.avatar_bg)
            clipToOutline = true
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        body.addView(box)
        body.addView(link(getString(if (bmp != null) R.string.change_photo else R.string.add_photo)) { pickAvatar() }
            .apply { (layoutParams as LinearLayout.LayoutParams).gravity = Gravity.CENTER_HORIZONTAL })
        if (bmp != null) body.addView(link(getString(R.string.remove_photo), R.color.err) {
            confirm(getString(R.string.confirm_remove_photo), R.string.remove_photo) {
                f.delete()
                refreshAvatar()
                refresh()
            }
        }.apply { (layoutParams as LinearLayout.LayoutParams).gravity = Gravity.CENTER_HORIZONTAL })
    }

    /** Picks an image, saves it as a small JPEG (max 512 px) next to the old one, and only then replaces it. */
    private fun pickAvatar() = pick("image/*") { uri ->
        val dst = Store.avatarFile(this, email)
        val tmp = java.io.File(dst.path + ".tmp")
        if (Store.savePhoto(this, uri, tmp, 512) && tmp.renameTo(dst)) {
            refreshAvatar()
            refresh()
        } else {
            tmp.delete()
            toast(R.string.err_photo)
        }
    }

    private fun profile() {
        val s = me!!
        avatarBlock(s)
        addCard(getString(R.string.role_student_label), s.name, s.grade)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Store.collections.forEach { c -> row.addView(stat(savedCount(c), collName(c), row)) }
        body.addView(row)
        heading(getString(R.string.my_collections))
        addTiles(
            listOf(
                TileSpec(R.drawable.ic_heart, R.string.coll_fav, savedCount("fav")) { openCollection("fav") },
                TileSpec(R.drawable.ic_clock, R.string.coll_later, savedCount("later")) { openCollection("later") },
                TileSpec(R.drawable.ic_star, R.string.coll_imp, savedCount("imp")) { openCollection("imp") },
                TileSpec(R.drawable.ic_note, R.string.notes_title, Store.notes(this, email).size) { show { notesScreen() } },
                TileSpec(R.drawable.ic_hist, R.string.history_title, Store.history(this, email).count { Store.publishedLesson(this, it) != null }) { show { historyScreen() } },
                TileSpec(R.drawable.ic_gear, R.string.settings) { openSettings() }
            )
        )
        heading(getString(R.string.sec_account))
        // every row does something when tapped
        addRow(R.drawable.ic_user, s.name, getString(R.string.role_student_label), listOf(chev())) { editNameSheet() }
        addRow(R.drawable.ic_email, s.email, getString(R.string.acc_tap_copy), listOf(iconBtn(R.drawable.ic_copy, R.color.mut) { copyEmail() })) { copyEmail() }
        addRow(R.drawable.ic_phone, s.phone.ifEmpty { getString(R.string.acc_no_phone) }, getString(R.string.hint_phone), listOf(chev())) { editPhoneSheet() }
        addRow(R.drawable.ic_grade, s.grade, getString(R.string.grade_label), listOf(chev())) { gradeSheet() }
        addRow(R.drawable.ic_key, getString(R.string.acc_change_pw), null, listOf(chev())) { pwSheet() }
    }

    private fun chev(): ImageView = ImageView(this).apply {
        setImageResource(R.drawable.ic_chev)
        imageTintList = resources.getColorStateList(R.color.mut, theme)
        if (resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL) rotation = 180f
        layoutParams = LinearLayout.LayoutParams(dp(20), dp(20))
    }

    /** Applies [change] to the saved copy of this student and keeps [me] in step. */
    private fun saveMe(change: (Student) -> Unit) {
        val list = Store.students(this)
        val i = list.indexOfFirst { it.email == email }
        if (i < 0) return
        change(list[i])
        Store.saveStudents(this, list)
        me = list[i]
    }

    private fun copyEmail() {
        val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("email", email))
        toast(R.string.acc_email_copied)
    }

    private fun editNameSheet() {
        sheet(getString(R.string.acc_edit_name)) { c, d ->
            val f = field(getString(R.string.hint_name)).apply { setText(me!!.name) }
            c.addView(f)
            c.addView(primary(getString(R.string.done), 16) {
                val n = f.text.toString().trim()
                if (n.isEmpty()) return@primary toast(R.string.err_title)
                saveMe { it.name = n }
                d.dismiss()
                refreshHeader()
                toast(R.string.acc_saved)
                refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    private fun editPhoneSheet() {
        sheet(getString(R.string.acc_edit_phone)) { c, d ->
            val f = field(getString(R.string.hint_phone), ltr = true).apply {
                inputType = android.text.InputType.TYPE_CLASS_PHONE
                setText(me!!.phone)
            }
            c.addView(f)
            c.addView(primary(getString(R.string.done), 16) {
                val n = f.text.toString().trim()
                saveMe { it.phone = n }
                d.dismiss()
                toast(R.string.acc_saved)
                refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    private fun gradeSheet() {
        val grades = Store.grades(this)
        if (grades.isEmpty()) return
        var pick = grades.indexOf(me!!.grade).coerceAtLeast(0)
        sheet(getString(R.string.acc_pick_grade)) { c, d ->
            c.addView(singleChoice(grades, pick) { pick = it })
            c.addView(primary(getString(R.string.done), 16) {
                saveMe { it.grade = grades[pick] }
                d.dismiss()
                toast(R.string.acc_saved)
                refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    private fun pwField(hint: CharSequence): android.widget.EditText = field(hint, ltr = true).apply {
        inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        transformationMethod = android.text.method.PasswordTransformationMethod.getInstance()
    }

    private fun pwSheet() {
        sheet(getString(R.string.acc_change_pw)) { c, d ->
            val old = pwField(getString(R.string.hint_current_password))
            val new = pwField(getString(R.string.hint_new_password))
            val again = pwField(getString(R.string.hint_password_confirm))
            c.addView(old)
            c.addView(new)
            c.addView(again)
            c.addView(primary(getString(R.string.done), 16) {
                val st = me ?: return@primary
                val o = old.text.toString()
                val n = new.text.toString()
                if (o.isEmpty() || n.isEmpty()) return@primary toast(R.string.err_enter_creds)
                if (st.pw != Store.hash(o)) return@primary toast(R.string.err_pw_wrong)
                if (n.length < 6) return@primary toast(R.string.err_teacher_short)
                if (n != again.text.toString()) return@primary toast(R.string.err_pw_mismatch)
                saveMe { it.pw = Store.hash(n) }
                d.dismiss()
                toast(R.string.pw_changed)
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    // ------------------------------------------------------------------ sub-screens

    private fun booksScreen() {
        addTop(getString(R.string.books_title))
        val docs = Store.docs(this)
        if (docs.isEmpty()) addEmpty(R.drawable.ic_book, R.string.empty_books, R.string.empty_books_sub)
        docs.filter { it.kind == "book" }.forEach { docRow(it) }
        val files = docs.filter { it.kind == "file" }
        if (files.isNotEmpty()) {
            heading(getString(R.string.files_title))
            files.forEach { docRow(it) }
        }
    }

    private fun openCollection(c: String) {
        typeFilter = "all"
        show { collection(c) }
    }

    private fun collection(c: String) {
        val items = Store.favList(this, email, c).mapNotNull { k -> resolve(k)?.let { k to it } }
        addTop(getString(collName(c)), items.size)
        val kinds = items.map { it.second.type }.distinct()
        if (kinds.size > 1) {
            val labels = listOf(getString(R.string.all)) + kinds.map { typeName(it) }
            val sel = if (typeFilter == "all") 0 else kinds.indexOf(typeFilter) + 1
            body.addView(chipRow(labels, sel.coerceAtLeast(0)) { i ->
                typeFilter = if (i == 0) "all" else kinds[i - 1]
                refresh()
            })
        }
        val list = items.filter { typeFilter == "all" || it.second.type == typeFilter }
        list.forEach { (k, r) ->
            addRow(r.icon, r.title, typeName(r.type), listOf(iconBtn(R.drawable.ic_trash, R.color.mut) {
                Store.toggleIn(this, email, c, k)
                refresh()
            })) { r.open() }
        }
        if (list.isEmpty()) addEmpty(collIcon(c), R.string.nothing_here, R.string.nothing_here_sub)
    }

    private fun notesScreen() {
        val list = Store.notes(this, email)
        addTop(getString(R.string.notes_title), list.size)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.card_glass)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            layoutParams = lp(top = 12)
        }
        val et = field(getString(R.string.note_hint), lines = 3, top = 0)
        box.addView(et)
        box.addView(primary(getString(R.string.add_note), 12) {
            val t = et.text.toString().trim()
            if (t.isNotEmpty()) {
                val l = Store.notes(this, email)
                l.add(0, Note(t, dateText(System.currentTimeMillis())))
                Store.saveNotes(this, email, l)
                refresh()
            }
        })
        body.addView(box)
        if (list.isEmpty()) body.addView(label(getString(R.string.no_notes), 13f, R.color.mut, top = 20))
        list.forEachIndexed { i, n ->
            addRow(R.drawable.ic_note, n.text, n.date, listOf(iconBtn(R.drawable.ic_trash, R.color.mut) {
                val l = Store.notes(this, email)
                if (i < l.size) l.removeAt(i)
                Store.saveNotes(this, email, l)
                refresh()
            }))
        }
    }

    private fun historyScreen() {
        val lessons = Store.history(this, email).mapNotNull { Store.publishedLesson(this, it) }
        addTop(getString(R.string.history_title), lessons.size)
        if (lessons.isEmpty()) {
            addEmpty(R.drawable.ic_hist, R.string.no_history, R.string.no_history_sub)
            return
        }
        body.addView(link(getString(R.string.clear_history), R.color.err, top = 8) {
            confirm(getString(R.string.confirm_clear_history), R.string.clear_history) {
                Store.clearHistory(this, email)
                refresh()
            }
        })
        lessons.forEach { l -> addRow(R.drawable.ic_play, l.title, null) { openVideo(l, email) } }
    }

    // ------------------------------------------------------------------ exams tab: exams / homework

    private var exTab = "exams"

    // the exam being taken (kept here so rebuilding the screen never loses the answers)
    private var runExam: Exam? = null
    private var runQs: List<Question> = emptyList()
    private var runPick = IntArray(0)   // chosen option per question, -1 = none
    private var runIdx = 0

    // the homework answer being written (kept here so the picker / rotation never loses it)
    private var hwText = ""
    private var hwKeep = true    // the saved photo stays unless it is removed or replaced
    private var hwNew = false    // a new photo waits in Store.draftPhoto

    private fun examsTab() {
        val tags = listOf("exams", "homework")
        body.addView(chipRow(listOf(getString(R.string.ex_exams), getString(R.string.ex_homework)), tags.indexOf(exTab), 0) {
            exTab = tags[it]; refresh()
        })
        if (exTab == "homework") homeworkList() else examList()
    }

    private fun cardBox(gap: Int = 12, center: Boolean = false) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        if (center) gravity = Gravity.CENTER_HORIZONTAL
        setBackgroundResource(R.drawable.card_glass)
        setPadding(dp(16), dp(16), dp(16), dp(16))
        layoutParams = lp(top = gap)
    }

    // ---- exams

    private fun examList() {
        val avg = Store.officialAverage(this, email)
        val box = cardBox(14)
        box.addView(label(getString(R.string.ex_official_avg), 12f, R.color.mut))
        box.addView(
            label(if (avg == null) getString(R.string.ex_no_avg) else "$avg%", if (avg == null) 14f else 30f, R.color.mut, true, top = 4)
                .apply { if (avg != null) setTextColor(accent()) }
        )
        body.addView(box)
        val list = Store.exams(this)
        if (list.isEmpty()) return addEmpty(R.drawable.ic_exam, R.string.empty_exams, R.string.empty_exams_sub)
        list.sortedByDescending { it.at }.forEach { e ->
            val last = Store.lastResult(this, email, e.id)
            val sub = getString(if (e.official) R.string.ex_official else R.string.ex_training) + "  •  " +
                getString(R.string.ex_questions_count, e.qids.size) + "  •  " +
                (if (last == null) getString(R.string.ex_not_taken) else getString(R.string.ex_last_result, last.score) + "%")
            addRow(R.drawable.ic_exam, e.title, sub) { startExam(e) }
        }
    }

    private fun startExam(e: Exam) {
        val bank = Store.questions(this)
        val qs = e.qids.mapNotNull { id -> bank.firstOrNull { it.id == id } }.filter { it.options.size >= 2 }
        if (qs.isEmpty()) return toast(R.string.ex_empty_questions)
        runExam = e
        runQs = qs
        runPick = IntArray(qs.size) { -1 }
        runIdx = 0
        show { examQuestion() }
    }

    private fun optionCard(text: String, on: Boolean, click: () -> Unit): View =
        label(text, 15f, R.color.tx, on, top = 8).apply {
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(color(R.color.glass))
                setStroke(dp(if (on) 2 else 1), if (on) accent() else color(R.color.bd))
            }
            setOnClickListener { Sfx.play(Sfx.S.SELECT); click() }
        }

    /** One question at a time. Nothing is saved until the student submits. */
    private fun examQuestion() {
        val e = runExam ?: return
        val q = runQs[runIdx]
        addTop(e.title)
        body.addView(label(getString(R.string.ex_question_of, runIdx + 1, runQs.size), 13f, R.color.mut, top = 14))
        addCard(null, q.text, null)
        q.options.forEachIndexed { k, o ->
            body.addView(optionCard(o, runPick[runIdx] == k) { runPick[runIdx] = k; refresh() })
        }
        val last = runIdx == runQs.size - 1
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutParams = lp(top = 8) }
        nav.addView(link(getString(R.string.ex_prev), R.color.mut) {
            if (runIdx > 0) { runIdx--; replace { examQuestion() } }
        }.apply { layoutParams = lp(w = 0, weight = 1f); alpha = if (runIdx > 0) 1f else 0.4f })
        nav.addView(primary(getString(if (last) R.string.ex_submit else R.string.ex_next), 0) {
            if (!last) { runIdx++; replace { examQuestion() }; return@primary }
            if (runPick.any { it < 0 }) confirm(getString(R.string.ex_unanswered), R.string.ex_submit) { finishExam() } else finishExam()
        }.apply { layoutParams = lp(w = 0, h = dp(50), weight = 1.6f, start = 8) })
        body.addView(nav)
    }

    private fun finishExam() {
        val e = runExam ?: return
        val total = runQs.size
        val correct = runQs.indices.count { runPick[it] == runQs[it].answer }
        val score = correct * 100 / total
        Store.addResult(this, Result(e.id, email, score, correct, total, System.currentTimeMillis()))
        Sfx.play(if (score >= 50) Sfx.S.PASS else Sfx.S.FAIL)
        replace { examResult(correct, total, score) }
    }

    private fun examResult(correct: Int, total: Int, score: Int) {
        addTop(getString(R.string.ex_result_title))
        val box = cardBox(14, center = true)
        box.addView(label("$score%", 48f, R.color.tx, true).apply { setTextColor(accent()); gravity = Gravity.CENTER })
        box.addView(label(getString(R.string.ex_result_line, correct, total), 15f, R.color.tx, true, top = 4).apply { gravity = Gravity.CENTER })
        body.addView(box)
        body.addView(primary(getString(R.string.ex_retake), 14) {
            runPick = IntArray(runQs.size) { -1 }
            runIdx = 0
            replace { examQuestion() }
        })
        heading(getString(R.string.ex_review))
        runQs.forEachIndexed { i, q ->
            val ok = runPick[i] == q.answer
            val card = cardBox(8)
            card.addView(label(q.text, 15f, R.color.tx, true))
            val mine = getString(R.string.ex_your_answer) + ": " + (if (runPick[i] < 0) "—" else q.options[runPick[i]])
            card.addView(label(mine, 14f, R.color.tx, top = 6).apply { setTextColor(if (ok) accent() else color(R.color.err)) })
            if (!ok) card.addView(label(getString(R.string.ex_right_answer) + ": " + q.options.getOrNull(q.answer).orEmpty(), 12f, R.color.mut, top = 2))
            body.addView(card)
        }
    }

    // ---- homework

    private fun homeworkList() {
        val list = Store.homework(this)
        if (list.isEmpty()) return addEmpty(R.drawable.ic_pencil, R.string.ex_empty_hw, R.string.ex_empty_hw_sub)
        list.sortedByDescending { it.at }.forEach { h ->
            val s = Store.submission(this, h.id, email)
            val status = when {
                s == null -> getString(R.string.hw_status_none)
                s.grade >= 0 -> getString(R.string.hw_status_graded, s.grade)
                else -> getString(R.string.hw_status_sent)
            }
            addRow(R.drawable.ic_pencil, h.title, status) { openHomework(h) }
        }
    }

    private fun openHomework(h: Homework) {
        val old = Store.submission(this, h.id, email)
        hwText = old?.text ?: ""
        hwKeep = true
        hwNew = false
        Store.draftPhoto(this, email).delete()
        show { homeworkForm(h) }
    }

    /** One homework: the teacher's note, the grade (if graded) and the answer form (text + one photo). */
    private fun homeworkForm(h: Homework) {
        val old = Store.submission(this, h.id, email)
        val draft = Store.draftPhoto(this, email)
        addTop(h.title)
        if (h.note.isNotEmpty()) addCard(getString(R.string.hw_note), h.note, null)

        // status + the teacher's feedback
        val st = cardBox(12)
        val graded = old != null && old.grade >= 0
        st.addView(
            label(
                when {
                    old == null -> getString(R.string.hw_status_none)
                    graded -> getString(R.string.hw_status_graded, old.grade)
                    else -> getString(R.string.hw_status_sent)
                }, 15f, R.color.tx, true
            ).apply { setTextColor(if (old == null) color(R.color.mut) else if (graded) accent() else color(R.color.gold)) }
        )
        if (old != null && graded && old.note.isNotEmpty())
            st.addView(label(getString(R.string.hw_teacher_note) + ": " + old.note, 12f, R.color.mut, top = 4))
        body.addView(st)

        // answer form
        body.addView(label(getString(R.string.hw_your_answer), 13f, R.color.mut, top = 16))
        val et = field(getString(R.string.hw_your_answer), lines = 5, top = 6)
        et.setText(hwText)
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { hwText = s?.toString() ?: "" }
        })
        body.addView(et)

        val shown: File? = when {
            hwNew && draft.exists() -> draft
            hwKeep && old != null && old.photo.isNotEmpty() -> Store.photoFile(this, old.photo)
            else -> null
        }
        if (shown != null) {
            val bmp = decodeScaled(shown, 1024)
            if (bmp != null) body.addView(ImageView(this).apply {
                setImageBitmap(bmp)
                adjustViewBounds = true
                maxHeight = dp(260)
                layoutParams = lp(top = 10)
            }) else body.addView(label(getString(R.string.hw_photo_missing), 12f, R.color.mut, top = 10))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = lp(top = 4) }
        row.addView(link(getString(R.string.hw_choose_photo)) {
            pick("image/*") { uri ->
                val tmp = File(draft.path + ".tmp")
                if (Store.savePhoto(this, uri, tmp) && tmp.renameTo(draft)) {
                    hwNew = true
                    hwKeep = false
                    refresh()
                } else {
                    tmp.delete()
                    toast(R.string.hw_err_photo)
                }
            }
        })
        if (shown != null) row.addView(link(getString(R.string.hw_remove_photo), R.color.err) {
            draft.delete()
            hwNew = false
            hwKeep = false
            refresh()
        })
        body.addView(row)

        body.addView(primary(getString(if (old == null) R.string.hw_submit else R.string.hw_resubmit), 16) {
            val answer = hwText.trim()
            val hasNew = hwNew && draft.exists()
            val hasOld = hwKeep && old != null && old.photo.isNotEmpty()
            if (answer.isEmpty() && !hasNew && !hasOld) return@primary toast(R.string.hw_err_empty)
            var keep = if (hasOld) old!!.photo else ""
            if (hasNew) {
                val name = Store.newId() + ".jpg"
                if (!draft.renameTo(Store.photoFile(this, name))) return@primary toast(R.string.hw_err_photo)
                keep = name
            }
            // the old photo goes away when it was replaced or removed
            if (old != null && old.photo.isNotEmpty() && old.photo != keep) Store.photoFile(this, old.photo).delete()
            Store.putSubmission(this, Submission(h.id, email, answer, keep, -1, "", System.currentTimeMillis()))
            hwNew = false
            Sfx.play(Sfx.S.SUCCESS)
            back()   // the list shows the new status
        })
    }
}
