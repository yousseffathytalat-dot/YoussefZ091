package com.moknight.nexoraedu

import android.animation.AnimatorListenerAdapter
import android.animation.Animator
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.AnimatedVectorDrawable
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/* New in release 16: one moving indicator for two-way switches, a drawn checkbox, small icon animations. */

internal fun Context.themeAttr(attr: Int): Int {
    val v = TypedValue()
    theme.resolveAttribute(attr, v, true)
    return v.data
}

/**
 * A two (or more) way switch with ONE accent indicator that slides from item to item (with a tiny overshoot)
 * while the label colours cross-fade. Works the same in RTL and LTR.
 */
class SegControl @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : FrameLayout(ctx, attrs) {
    private val dens = resources.displayMetrics.density
    private val ind = View(ctx)
    private val row = LinearLayout(ctx)
    private val items = ArrayList<TextView>()
    private val onColor = Color.WHITE
    private val offColor = resources.getColor(R.color.tx, ctx.theme)

    var index = 0
        private set
    var onSelect: ((Int) -> Unit)? = null

    init {
        val p = (3 * dens).toInt()
        setPadding(p, p, p, p)
        background = resources.getDrawable(R.drawable.seg_bg, ctx.theme)
        ind.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(ctx.themeAttr(R.attr.p1), ctx.themeAttr(R.attr.p2))
        ).apply { cornerRadius = 13 * dens }

        addView(ind, LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT))
        row.orientation = LinearLayout.HORIZONTAL
        addView(row, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    /** Changes the colours of the sliding indicator (login: purple for the teacher). */
    fun setAccent(a: Int, b: Int) {
        (ind.background as? GradientDrawable)?.colors = intArrayOf(a, b)
    }

    fun setItems(labels: List<CharSequence>, selected: Int) {
        row.removeAllViews()
        items.clear()
        index = selected.coerceIn(0, max(0, labels.size - 1))
        labels.forEachIndexed { i, s ->
            val t = TextView(context).apply {
                text = s
                gravity = Gravity.CENTER
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (i == index) onColor else offColor)
                setOnClickListener { select(i, true) }
            }
            items.add(t)
            row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        requestLayout()
    }

    /** Moves to item [i]. [user] = true when the finger did it (calls [onSelect]). */
    fun select(i: Int, user: Boolean) {
        if (i == index || i !in items.indices) return
        val from = index
        index = i
        place(true)
        fade(items[from], onColor, offColor)
        fade(items[i], offColor, onColor)
        if (user) { Sfx.play(Sfx.S.TAB); onSelect?.invoke(i) }
    }

    private fun fade(t: TextView, from: Int, to: Int) {
        ValueAnimator.ofObject(ArgbEvaluator(), from, to).apply {
            duration = 280
            addUpdateListener { t.setTextColor(it.animatedValue as Int) }
            start()
        }
    }

    private fun place(animate: Boolean) {
        val t = items.getOrNull(index) ?: return
        if (t.width == 0) return
        val tx = (row.left + t.left - ind.left).toFloat()
        ind.animate().cancel()
        if (animate) {
            ind.animate().translationX(tx).setInterpolator(OvershootInterpolator(0.8f)).setDuration(360).start()
        } else {
            ind.translationX = tx
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val n = items.size
        if (n > 0) {
            val inner = MeasureSpec.getSize(widthMeasureSpec) - paddingLeft - paddingRight
            (ind.layoutParams as LayoutParams).width = max(0, inner / n)
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (changed) place(false)
    }
}

/**
 * A checkbox drawn with the Canvas: a rounded box that fills with the accent gradient while the tick is drawn
 * stroke by stroke (and the box gives a small bounce). Tap = toggle.
 */
class DrawnCheck @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val dens = resources.displayMetrics.density
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * dens }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 2.2f * dens
        color = Color.WHITE
    }
    private val tick = Path()
    private val seg = Path()
    private val measure = PathMeasure()
    private val rect = RectF()
    private var c1 = ctx.themeAttr(R.attr.p1)
    private var c2 = ctx.themeAttr(R.attr.p2)
    private val off = resources.getColor(R.color.mut, ctx.theme)
    private val argb = ArgbEvaluator()
    private var p = 0f
    private var anim: ValueAnimator? = null

    var checked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null

    init {
        isClickable = true
        contentDescription = ctx.getString(R.string.signup_new)
        setOnClickListener { setChecked(!checked, true) }
    }

    fun setAccent(a: Int, b: Int) { c1 = a; c2 = b; invalidate() }

    fun setChecked(v: Boolean, animate: Boolean, notify: Boolean = true) {
        if (v == checked && anim == null) {
            p = if (v) 1f else 0f
            invalidate()
            return
        }
        checked = v
        anim?.cancel()
        val target = if (v) 1f else 0f
        if (!animate) {
            p = target
            anim = null
            invalidate()
        } else {
            anim = ValueAnimator.ofFloat(p, target).apply {
                duration = if (v) 360L else 220L
                interpolator = DecelerateInterpolator(1.4f)
                addUpdateListener { p = it.animatedValue as Float; invalidate() }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: Animator) { anim = null }
                })
                start()
            }
            if (v) {
                animate().cancel()
                scaleX = 0.82f
                scaleY = 0.82f
                animate().scaleX(1f).scaleY(1f).setInterpolator(OvershootInterpolator(3.2f)).setDuration(380).start()
            }
        }
        if (notify) { Sfx.play(if (v) Sfx.S.ON else Sfx.S.OFF); onChange?.invoke(v) }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val s = min(w, h).toFloat()
        val ox = (w - s) / 2f
        val oy = (h - s) / 2f
        val inset = boxPaint.strokeWidth / 2f + dens
        rect.set(ox + inset, oy + inset, ox + s - inset, oy + s - inset)
        tick.reset()
        tick.moveTo(ox + s * 0.27f, oy + s * 0.53f)
        tick.lineTo(ox + s * 0.43f, oy + s * 0.69f)
        tick.lineTo(ox + s * 0.74f, oy + s * 0.35f)
        measure.setPath(tick, false)
        fillPaint.shader = LinearGradient(ox, oy, ox + s, oy + s, c1, c2, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val r = 8f * dens
        fillPaint.alpha = (255 * min(1f, p * 1.7f)).toInt()
        canvas.drawRoundRect(rect, r, r, fillPaint)
        boxPaint.color = argb.evaluate(min(1f, p * 1.4f), off, c1) as Int
        canvas.drawRoundRect(rect, r, r, boxPaint)
        val t = ((p - 0.3f) / 0.7f).coerceIn(0f, 1f)
        if (t > 0f) {
            seg.reset()
            measure.getSegment(0f, measure.length * t, seg, true)
            canvas.drawPath(seg, tickPaint)
        }
    }
}

/** Shows a small expanding / collapsing field row (fixed height [h] + top margin [m], both in px). */
fun animateRow(v: View, show: Boolean, delay: Long, h: Int, m: Int, animate: Boolean) {
    val lp = v.layoutParams as ViewGroup.MarginLayoutParams
    (v.getTag(R.id.row_anim) as? ValueAnimator)?.cancel()
    val d = v.resources.displayMetrics.density
    if (!animate) {
        lp.height = if (show) h else 0
        lp.topMargin = if (show) m else 0
        v.layoutParams = lp
        v.alpha = 1f
        v.translationY = 0f
        v.visibility = if (show) View.VISIBLE else View.GONE
        return
    }
    val gone = v.visibility == View.GONE
    val from = if (gone) 0f else (lp.height.toFloat() / h).coerceIn(0f, 1f)
    val to = if (show) 1f else 0f
    if (from == to) {
        if (!show) v.visibility = View.GONE
        return
    }
    if (gone) {
        lp.height = 0
        lp.topMargin = 0
        v.layoutParams = lp
        v.alpha = 0f
    }
    v.visibility = View.VISIBLE
    val a = ValueAnimator.ofFloat(from, to)
    a.startDelay = delay
    a.duration = 380
    a.interpolator = DecelerateInterpolator(1.6f)
    a.addUpdateListener {
        val f = it.animatedValue as Float
        lp.height = (h * f).toInt()
        lp.topMargin = (m * f).toInt()
        v.layoutParams = lp
        v.alpha = f.coerceIn(0f, 1f)
        v.translationY = (f - 1f) * 8f * d
    }
    a.addListener(object : AnimatorListenerAdapter() {
        override fun onAnimationEnd(an: Animator) {
            v.setTag(R.id.row_anim, null)
            if (!show && lp.height <= 0) v.visibility = View.GONE
        }
    })
    v.setTag(R.id.row_anim, a)
    a.start()
}

/** The tab icon jumps up and settles with a bounce. */
fun iconHop(icon: View) {
    val d = icon.resources.displayMetrics.density
    icon.animate().cancel()
    icon.translationY = 0f
    icon.animate().translationY(-9f * d).setDuration(140).setInterpolator(DecelerateInterpolator())
        .withEndAction {
            icon.animate().translationY(0f).setDuration(400).setInterpolator(OvershootInterpolator(3.4f)).start()
        }.start()
}

/** The lock shakes a little (on focus / wrong password). */
fun lockWiggle(icon: View) {
    icon.animate().cancel()
    icon.pivotX = icon.width / 2f
    icon.pivotY = icon.height.toFloat()
    val a = ValueAnimator.ofFloat(0f, 1f)
    a.duration = 460
    a.addUpdateListener {
        val t = it.animatedValue as Float
        icon.rotation = (kotlin.math.sin(t * Math.PI * 4).toFloat()) * 14f * (1f - t)
    }
    a.addListener(object : AnimatorListenerAdapter() {
        override fun onAnimationEnd(an: Animator) { icon.rotation = 0f }
    })
    a.start()
}

/** The eye closes, the picture is swapped while it is shut, then it opens again. */
fun eyeBlink(eye: ImageView, nowOpen: Boolean) {
    eye.animate().cancel()
    eye.animate().scaleY(0.08f).setDuration(110).setInterpolator(DecelerateInterpolator())
        .withEndAction {
            eye.setImageResource(if (nowOpen) R.drawable.ic_eye_off else R.drawable.ic_eye)
            eye.animate().scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(2.4f)).start()
        }.start()
}

/** Puts a tick in front of the text and draws it stroke by stroke. */
fun TextView.drawTick(color: Int) {
    val d = resources.getDrawable(R.drawable.avd_check, context.theme).mutate()
    val px = (18 * resources.displayMetrics.density).toInt()
    d.setBounds(0, 0, px, px)
    d.setTint(color)
    compoundDrawablePadding = (6 * resources.displayMetrics.density).toInt()
    setCompoundDrawablesRelative(d, null, null, null)
    (d as? AnimatedVectorDrawable)?.start()
}

/**
 * The class picker for sign-up: three fixed glass chips in one row (first / second / third secondary).
 * The chosen one is filled with the accent gradient and pops; the row follows the layout direction (RTL / LTR).
 */
class GradeChips @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : LinearLayout(ctx, attrs) {
    var onSelect: ((Int) -> Unit)? = null
    var selected = 0
        private set
    private val chips = ArrayList<TextView>()

    init {
        orientation = HORIZONTAL
        layoutDirection = View.LAYOUT_DIRECTION_LOCALE
        val d = resources.displayMetrics.density
        val labels = listOf(R.string.grade_1_short, R.string.grade_2_short, R.string.grade_3_short)
        labels.forEachIndexed { i, res ->
            val t = TextView(ctx).apply {
                setText(res)
                gravity = Gravity.CENTER
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 2
                setPadding((6 * d).toInt(), 0, (6 * d).toInt(), 0)
                setTextColor(resources.getColorStateList(R.color.seg_text, ctx.theme))
                background = resources.getDrawable(R.drawable.grade_chip, ctx.theme)
                isClickable = true
                isSelected = i == 0
                setOnClickListener { select(i, true) }
            }
            val lp = LayoutParams(0, LayoutParams.MATCH_PARENT, 1f)
            if (i > 0) lp.marginStart = (8 * d).toInt()
            addView(t, lp)
            chips.add(t)
        }
    }

    fun select(i: Int, user: Boolean) {
        if (i !in chips.indices) return
        val changed = i != selected
        selected = i
        chips.forEachIndexed { k, c -> c.isSelected = k == i }
        if (user && changed) {
            val c = chips[i]
            c.animate().cancel()
            c.scaleX = 0.92f; c.scaleY = 0.92f
            c.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(3f)).start()
            Sfx.play(Sfx.S.SELECT)
            onSelect?.invoke(i)
        }
    }
}
