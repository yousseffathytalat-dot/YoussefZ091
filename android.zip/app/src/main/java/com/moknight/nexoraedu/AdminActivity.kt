package com.moknight.nexoraedu

import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Typeface
import android.net.Uri
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Admin side: dashboard, teacher account, students, content and own account.
 * Same shell (header, tabs, settings sheet) as the student and teacher screens, with its own gold/orange theme.
 * The content part (add sheets and lists) mirrors TeacherActivity on purpose, so that file stays untouched.
 */
class AdminActivity : ShellActivity() {
    private var email = ""
    private var gradeSel = 0
    private var query = ""

    override fun ready(): Boolean {
        val s = Store.session(this)
        val a = Store.admin(this)
        if (s?.first != "admin" || a == null) return false
        email = a.first
        return true
    }

    override fun hello() = R.string.welcome_admin
    override fun displayName() = email.substringBefore("@")

    override fun buildTabs() = listOf(
        Tab(R.string.tab_dashboard, R.drawable.ic_home) { dashboard() },
        Tab(R.string.tab_teacher, R.drawable.ic_user) { teacherTab() },
        Tab(R.string.tab_students, R.drawable.ic_users) { studentsTab() },
        Tab(R.string.tab_content, R.drawable.ic_folder) { content() },
        Tab(R.string.tab_profile, R.drawable.ic_key) { account() }
    )

    // ------------------------------------------------------------------ dashboard

    private fun dashboard() {
        alertsBlock()
        addStatGrid(
            listOf(
                Store.students(this).size to R.string.stat_students,
                Store.grades(this).size to R.string.stat_classes,
                Store.chapters(this).size to R.string.stat_chapters,
                Store.lessons(this).size to R.string.stat_lessons,
                Store.docs(this).size to R.string.stat_files
            )
        )
        heading(getString(R.string.manage_content))
        addTiles(contentActions())
    }

    private fun contentActions() = listOf(
        TileSpec(R.drawable.ic_folder, R.string.act_chapter) { addChapterSheet() },
        TileSpec(R.drawable.ic_play, R.string.act_lesson) { addLessonSheet() },
        TileSpec(R.drawable.ic_play, R.string.act_video) { addVideoSheet() },
        TileSpec(R.drawable.ic_book, R.string.act_book) { addDocSheet("book") },
        TileSpec(R.drawable.ic_note, R.string.act_file) { addDocSheet("file") }
    )

    // ------------------------------------------------------------------ teacher

    private fun teacherTab() {
        val t = Store.teacher(this)
        if (t == null) {
            addEmpty(R.drawable.ic_user, R.string.adm_no_teacher, R.string.adm_no_teacher_sub)
            staffBlock()
            return
        }
        addCard(getString(R.string.role_teacher_label), Store.teacherName(this).ifEmpty { t.first.substringBefore("@") }, null)
        addCard(getString(R.string.email_label), t.first, null)
        body.addView(primary(getString(R.string.adm_change_pw), 16) { changeTeacherPwSheet(t.first) })
        body.addView(link(getString(R.string.adm_delete_teacher), R.color.err, 6) {
            confirm(getString(R.string.confirm_delete_teacher)) { Store.deleteTeacher(this); refresh() }
        }.apply { layoutParams = lp(top = 6) })
        staffBlock()
    }

    // ------------------------------------------------------------------ release 54: remove teachers / admins (server), alerts for the main admin

    /** Asks first, then the server removes the account at once (it also refuses what is not allowed). [done] runs after the answer. */
    private fun confirmRemove(id: String, name: String, role: String, done: () -> Unit) {
        confirm(getString(if (role == "admin") R.string.confirm_remove_admin else R.string.confirm_remove_teacher, name), yes = R.string.adm_remove) {
            AdminControl.remove(this, id) { ok -> toast(if (ok) R.string.adm_removed else R.string.err_remove_fail); done() }
        }
    }

    /** Every teacher and admin account on the server. Teachers: any admin can remove. Admins: only the main admin. Nobody removes themselves or the main admin. */
    private fun staffBlock() {
        if (!Remote.enabled || !Remote.signedIn(this)) return
        heading(getString(R.string.adm_staff_title))
        if (AdminControl.isMain(this)) body.addView(primary(getString(R.string.adm_newcode), 4) { newAdminCodeSheet() })   // release 57
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(box)
        AdminControl.staff(this) { list ->
            if (isFinishing) return@staff
            if (list == null || list.isEmpty()) {
                box.addView(label(getString(if (list == null) R.string.adm_staff_fail else R.string.adm_staff_empty), 13f, R.color.mut, top = 8))
                return@staff
            }
            val iAmMain = AdminControl.isMain(this)
            val me = Remote.userId(this)
            list.forEach { s ->
                val who = s.name.ifEmpty { s.email.substringBefore("@") }
                val role = getString(if (s.role == "admin") R.string.role_admin_label else R.string.role_teacher_label)
                val trailing = ArrayList<View>()
                when {
                    s.removed -> trailing.add(badge(getString(R.string.adm_removed_badge), R.color.err))
                    s.id == me -> trailing.add(badge(getString(R.string.adm_you_badge)))
                    s.main -> trailing.add(badge(getString(R.string.adm_main_badge)))
                    s.role == "teacher" || iAmMain ->
                        trailing.add(chip(getString(R.string.adm_remove), false) { confirmRemove(s.id, who, s.role) { refresh() } })
                }
                box.addView(itemRow(if (s.role == "admin") R.drawable.ic_key else R.drawable.ic_user, who, role + " · " + s.email, trailing))
            }
        }
    }

    /** Release 57: main admin only. Asks the server for a one-time code (valid for one new admin, 7 days) and shows it to copy. */
    private fun newAdminCodeSheet() {
        AdminControl.newCode(this) { code ->
            if (isFinishing) return@newCode
            if (code == null) { toast(R.string.adm_newcode_fail); return@newCode }
            sheet(getString(R.string.adm_newcode)) { c, d ->
                c.addView(label(getString(R.string.adm_newcode_note), 13f, R.color.mut, top = 10))
                val big = label(code, 26f, R.color.tx, true, top = 12).apply {
                    typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                    textDirection = View.TEXT_DIRECTION_LTR
                    gravity = Gravity.CENTER
                    setBackgroundResource(R.drawable.field_bg)
                    setPadding(dp(14), dp(18), dp(14), dp(18))
                    setTextIsSelectable(true)
                }
                c.addView(big)
                c.addView(primary(getString(R.string.stu_copy), 14) {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("code", big.text))
                    toast(R.string.stu_copied)
                })
                c.addView(link(getString(R.string.close)) { d.dismiss() })
            }
        }
    }

    /** Main admin only (the server sends nothing to anyone else): who signed up / signed in as a teacher or admin and was not read yet. */
    private fun alertsBlock() {
        if (!Remote.enabled || !Remote.signedIn(this)) return
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(box)
        AdminControl.events(this) { list ->
            if (isFinishing || list.isNullOrEmpty()) return@events
            heading(getString(R.string.alerts_title), box)
            list.forEach { e ->
                val who = e.name.ifEmpty { e.email.substringBefore("@") }
                box.addView(itemRow(
                    R.drawable.ic_key, AdminControl.alertText(this, e), e.email + " · " + dateText(e.at),
                    listOf(chip(getString(R.string.adm_remove), false) { confirmRemove(e.userId, who, e.role) { refresh() } })
                ))
            }
            box.addView(link(getString(R.string.alerts_mark_read), top = 4) { AdminControl.markSeen(this) { refresh() } })
        }
    }

    private fun changeTeacherPwSheet(teacherEmail: String) {
        sheet(getString(R.string.adm_change_pw)) { c, d ->
            val pw = pwField(getString(R.string.hint_new_password))
            c.addView(pw)
            c.addView(primary(getString(R.string.done), 16) {
                val p = pw.text.toString()
                if (p.length < 6) return@primary toast(R.string.err_teacher_short)
                Store.setTeacher(this, teacherEmail, p, name = Store.teacherName(this)) // keep the teacher's name
                d.dismiss(); toast(R.string.pw_changed)
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    // ------------------------------------------------------------------ students

    private fun studentsTab() {
        if (Store.students(this).isEmpty()) {
            addEmpty(R.drawable.ic_users, R.string.empty_students, R.string.empty_students_sub)
            return
        }
        val grades = Store.grades(this)
        if (gradeSel > grades.size) gradeSel = 0
        val search = field(getString(R.string.hint_search), top = 4)
        search.setText(query)
        body.addView(search)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun fill() {
            list.removeAllViews()
            val q = query.trim().lowercase()
            val grade = grades.getOrNull(gradeSel - 1)
            val shown = Store.students(this).filter { s ->
                (grade == null || s.grade == grade) &&
                    (q.isEmpty() || s.name.lowercase().contains(q) || s.email.lowercase().contains(q))
            }
            if (shown.isEmpty()) {
                val v = layoutInflater.inflate(R.layout.item_empty, list, false)
                v.findViewById<android.widget.ImageView>(R.id.emptyIcon).setImageResource(R.drawable.ic_users)
                v.findViewById<TextView>(R.id.emptyTitle).setText(R.string.empty_search)
                v.findViewById<TextView>(R.id.emptySub).setText(R.string.empty_search_sub)
                list.addView(v)
            } else shown.forEach { s -> list.addView(studentCard(s) { fill() }) }
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; fill() }
        })
        body.addView(singleChoice(listOf(getString(R.string.all)) + grades, gradeSel, 10) { gradeSel = it; fill() })
        body.addView(list)
        fill()
    }

    /** One student: class, name, email, then active switch, code and delete. [changed] rebuilds the list. */
    private fun studentCard(s: Student, changed: () -> Unit): View {
        val v = card(s.grade, s.name, s.email) as LinearLayout
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = lp(top = 12)
        }
        row.addView(chip(getString(if (s.active) R.string.stu_active else R.string.stu_inactive), s.active) {
            Store.setStudentActive(this, s.email, !s.active)
            changed()
        })
        row.addView(chip(if (s.code.isEmpty()) getString(R.string.stu_code_new) else s.code, false) {
            codeSheet(s.email, changed)
        }.apply {
            if (s.code.isNotEmpty()) {
                typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                textDirection = View.TEXT_DIRECTION_LTR
            }
        })
        row.addView(View(this), lp(w = 0, weight = 1f))
        row.addView(iconBtn(R.drawable.ic_trash, R.color.mut) {
            confirm(getString(R.string.confirm_delete_student, s.name)) { Store.deleteStudent(this, s.email); changed() }
        })
        v.addView(row)
        return v
    }

    /** Makes a code the first time, then shows it (copy / new code). */
    private fun codeSheet(studentEmail: String, changed: () -> Unit) {
        var code = Store.findStudent(this, studentEmail)?.code ?: return
        if (code.isEmpty()) { code = Store.newStudentCode(this, studentEmail); changed() }
        sheet(getString(R.string.stu_code_title)) { c, d ->
            c.addView(label(getString(R.string.stu_code_note), 13f, R.color.mut, top = 10))
            val big = label(code, 26f, R.color.tx, true, top = 12).apply {
                typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                textDirection = View.TEXT_DIRECTION_LTR
                gravity = Gravity.CENTER
                setBackgroundResource(R.drawable.field_bg)
                setPadding(dp(14), dp(18), dp(14), dp(18))
                setTextIsSelectable(true)
            }
            c.addView(big)
            c.addView(primary(getString(R.string.stu_copy), 14) {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("code", big.text))
                toast(R.string.stu_copied)
            })
            c.addView(link(getString(R.string.stu_code_regen), top = 4) {
                big.text = Store.newStudentCode(this, studentEmail)
                changed()
            })
            c.addView(link(getString(R.string.close)) { d.dismiss() })
        }
    }

    // ------------------------------------------------------------------ content

    private fun trash(onYes: () -> Unit, name: String, warn: Int = R.string.confirm_delete) =
        iconBtn(R.drawable.ic_trash, R.color.mut) { confirm(getString(warn, name)) { onYes(); refresh() } }

    private fun content() {
        addTiles(contentActions() + TileSpec(R.drawable.ic_grade, R.string.act_grade) { addGradeSheet() })

        heading(getString(R.string.classes_title))
        val grades = Store.grades(this)
        val students = Store.students(this)
        grades.forEach { g ->
            addRow(
                R.drawable.ic_grade, g, getString(R.string.students_count, students.count { it.grade == g }),
                listOf(trash({ Store.saveGrades(this, Store.grades(this).filter { it != g }) }, g, R.string.confirm_delete_grade))
            )
        }

        val chapters = Store.chapters(this)
        val lessons = Store.lessons(this)
        val docs = Store.docs(this)
        if (chapters.isEmpty() && lessons.isEmpty() && docs.isEmpty()) {
            addEmpty(R.drawable.ic_folder, R.string.empty_content, R.string.empty_content_sub)
            return
        }
        val videos = lessons.filter { it.chapterId.isEmpty() }
        if (videos.isNotEmpty()) {
            heading(getString(R.string.videos))
            videos.forEach { lessonRow(it) }
        }
        if (chapters.isNotEmpty()) heading(getString(R.string.chapters_title))
        chapters.forEach { ch ->
            val ls = lessons.filter { it.chapterId == ch.id }
            addRow(
                R.drawable.ic_folder, ch.title, getString(R.string.lessons_count, ls.size),
                listOf(trash({ Store.deleteChapter(this, ch.id) }, ch.title, R.string.confirm_delete_chapter))
            )
            ls.forEach { lessonRow(it) }
        }
        val books = docs.filter { it.kind == "book" }
        if (books.isNotEmpty()) {
            heading(getString(R.string.books_title))
            books.forEach { docRow(it) }
        }
        val files = docs.filter { it.kind == "file" }
        if (files.isNotEmpty()) {
            heading(getString(R.string.files_title))
            files.forEach { docRow(it) }
        }
    }

    private fun lessonRow(l: Lesson) = addRow(
        R.drawable.ic_play, l.title, if (!Store.hasVideo(this, l)) getString(R.string.no_video_yet) else if (l.src == "up") getString(R.string.lesson_video_upload) else "YouTube",
        listOf(trash({ Store.saveLessons(this, Store.lessons(this).filter { it.id != l.id }) }, l.title))
    ) { openVideo(l) }

    private fun docRow(d: Doc) = addRow(
        if (d.kind == "book") R.drawable.ic_book else R.drawable.ic_note, d.title, dateText(d.at),
        listOf(trash({ Store.deleteDoc(this, d.id) }, d.title))
    ) { openDoc(d) }

    // ------------------------------------------------------------------ my account

    private fun account() {
        addCard(getString(R.string.role_admin_label), displayName(), null)
        addCard(getString(R.string.email_label), email, null)
        body.addView(primary(getString(R.string.adm_change_pw), 16) { changeMyPwSheet() })
        body.addView(primary(getString(R.string.adm_storage), 12) { storageSheet() })
    }

    private fun changeMyPwSheet() {
        sheet(getString(R.string.adm_change_pw)) { c, d ->
            val old = pwField(getString(R.string.hint_current_password))
            val new = pwField(getString(R.string.hint_new_password))
            c.addView(old)
            c.addView(new)
            c.addView(primary(getString(R.string.done), 16) {
                val a = Store.admin(this) ?: return@primary
                val o = old.text.toString()
                val n = new.text.toString()
                if (o.isEmpty() || n.isEmpty()) return@primary toast(R.string.err_enter_creds)
                if (a.second != Store.hash(o)) return@primary toast(R.string.err_pw_wrong)
                if (n.length < 6) return@primary toast(R.string.err_teacher_short)
                Store.setAdmin(this, a.first, n)
                d.dismiss(); toast(R.string.pw_changed)
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    // ------------------------------------------------------------------ storage (display only; the admin edits name, limit, on/off and order)
    // No R2 key, endpoint, bucket or size cap is known here: the server decides and refuses what is not allowed.

    private fun storageBytes(b: Long): String =
        if (b >= (1L shl 30)) String.format(java.util.Locale.US, "%.2f GB", b / (1L shl 30).toDouble())
        else String.format(java.util.Locale.US, "%.0f MB", b / (1L shl 20).toDouble())

    private fun storageGb(b: Long): String {
        val v = b / (1L shl 30).toDouble()
        return if (v == Math.floor(v)) v.toLong().toString() else String.format(java.util.Locale.US, "%.2f", v)
    }

    /** Arabic-Indic digits and the Arabic decimal mark -> plain digits and ".". */
    private fun latinNumber(s: String): String = buildString {
        for (ch in s.trim()) append(when (ch) {
            '\u0660' -> '0'; '\u0661' -> '1'; '\u0662' -> '2'; '\u0663' -> '3'; '\u0664' -> '4'
            '\u0665' -> '5'; '\u0666' -> '6'; '\u0667' -> '7'; '\u0668' -> '8'; '\u0669' -> '9'
            '\u066B', ',', '\u060C' -> '.'
            else -> ch
        })
    }

    private fun storageSheet() {
        sheet(getString(R.string.adm_storage)) { c, d -> storageList(c, d) }
    }

    private fun storageList(c: LinearLayout, d: android.app.Dialog) {
        c.removeAllViews()
        if (!Remote.enabled) { c.addView(label(getString(R.string.st_not_ready), 14f, R.color.mut, top = 12)); return }
        c.addView(android.widget.ProgressBar(this).apply { layoutParams = lp(top = 16) })
        Remote.storages(this) { list ->
            if (!d.isShowing) return@storages
            c.removeAllViews()
            if (list == null) {
                c.addView(label(getString(R.string.st_load_fail), 14f, R.color.err, top = 12))
                c.addView(primary(getString(R.string.st_retry), 12) { storageList(c, d) })
                walkPress(c)
                return@storages
            }
            if (list.isEmpty()) {
                c.addView(label(getString(R.string.st_empty), 15f, R.color.tx, true, top = 12))
                c.addView(label(getString(R.string.st_empty_sub), 13f, R.color.mut, top = 4))
            }
            list.forEach { s -> c.addView(storageRow(c, d, s)) }
            walkPress(c)                                          // press animation, like every tappable card
            staggerIn(c, resources.displayMetrics.density)         // rows slide up one after the other, like the tabs
        }
    }

    private fun storageRow(c: LinearLayout, d: android.app.Dialog, s: Remote.StorageInfo): View {
        // The app's own card (item_card): status line, name, then the bar and the numbers.
        val row = layoutInflater.inflate(R.layout.item_card, c, false) as LinearLayout
        row.findViewById<TextView>(R.id.cardSmall).apply {
            text = getString(if (s.active) R.string.st_on else R.string.st_off)
            if (!s.active) setTextColor(color(R.color.err))
            visibility = View.VISIBLE
        }
        row.findViewById<TextView>(R.id.cardTitle).text = s.name
        row.addView(bar((s.fraction * 100 + 0.5).toInt(), 10))
        row.addView(label(getString(R.string.st_used_fmt, storageBytes(s.usedBytes + s.reservedBytes), storageBytes(s.limitBytes)), 13f, R.color.mut, top = 8))
        if (s.reservedBytes > 0) row.addView(label(getString(R.string.st_reserved_fmt, storageBytes(s.reservedBytes)), 12f, R.color.mut, top = 2))
        row.setOnClickListener { storageForm(c, d, s) }
        return row
    }

    private fun storageForm(c: LinearLayout, d: android.app.Dialog, s: Remote.StorageInfo) {
        c.removeAllViews()
        val name = field(getString(R.string.st_name_hint)).apply { setText(s.name) }
        val limit = field(getString(R.string.st_limit_hint), ltr = true).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(storageGb(s.limitBytes))
        }
        val order = field(getString(R.string.st_order_hint), ltr = true, number = true).apply { setText(s.sortOrder.toString()) }
        var active = s.active
        val sw = glassSwitch(active) { active = it }
        val swRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutParams = lp(top = 14)
            addView(label(getString(R.string.st_switch), 15f, R.color.tx, true).apply { layoutParams = lp(w = 0, weight = 1f) })
            addView(sw)
        }
        c.addView(name); c.addView(limit); c.addView(order); c.addView(swRow)
        var busy = false
        c.addView(primary(getString(R.string.done), 16) {
            if (busy) return@primary
            val n = name.text.toString().trim()
            if (n.isEmpty()) return@primary toast(R.string.err_title)
            val gb = latinNumber(limit.text.toString()).toDoubleOrNull()
            if (gb == null || gb <= 0) return@primary toast(R.string.st_bad_limit)
            val o = latinNumber(order.text.toString()).toIntOrNull() ?: s.sortOrder
            busy = true
            Remote.updateStorage(this, Remote.StorageInfo(s.id, n, (gb * (1L shl 30)).toLong(), s.usedBytes, s.reservedBytes, active, o)) { ok ->
                busy = false
                toast(if (ok) R.string.st_saved else R.string.st_save_fail)
                if (ok) storageList(c, d)
            }
        })
        c.addView(link(getString(R.string.cancel)) { storageList(c, d) })
        walkPress(c)
    }

    private fun pwField(hint: CharSequence): EditText = field(hint, ltr = true).apply {
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        transformationMethod = PasswordTransformationMethod.getInstance()
    }

    // ------------------------------------------------------------------ add sheets (same as the teacher's)

    private fun addGradeSheet() {
        sheet(getString(R.string.act_grade)) { c, d ->
            val name = field(getString(R.string.hint_grade))
            c.addView(name)
            c.addView(primary(getString(R.string.add), 16) {
                val n = name.text.toString().trim()
                if (n.isEmpty()) return@primary toast(R.string.err_title)
                val all = Store.grades(this)
                if (all.any { it == n }) return@primary toast(R.string.err_grade_exists)
                Store.saveGrades(this, all + n)
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    private fun addChapterSheet() {
        sheet(getString(R.string.act_chapter)) { c, d ->
            val title = field(getString(R.string.hint_title))
            c.addView(title)
            c.addView(primary(getString(R.string.add), 16) {
                val t = title.text.toString().trim()
                if (t.isEmpty()) return@primary toast(R.string.err_title)
                Store.saveChapters(this, Store.chapters(this) + Chapter(Store.newId(), t))
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    private fun addLessonSheet() {
        val chapters = Store.chapters(this)
        if (chapters.isEmpty()) return toast(R.string.err_add_chapter_first)
        sheet(getString(R.string.act_lesson)) { c, d ->
            var sel = 0
            val title = field(getString(R.string.hint_title))
            val url = field(getString(R.string.hint_youtube_optional), ltr = true)
            c.addView(title)
            c.addView(label(getString(R.string.pick_chapter), 13f, R.color.mut, top = 14))
            c.addView(singleChoice(chapters.map { it.title }, 0, 8) { sel = it })
            c.addView(url)
            c.addView(primary(getString(R.string.add), 16) {
                val t = title.text.toString().trim()
                if (t.isEmpty()) return@primary toast(R.string.err_title)
                val raw = url.text.toString().trim()
                val yt = if (raw.isEmpty()) "" else youtubeId(raw)
                if (raw.isNotEmpty() && yt.isEmpty()) return@primary toast(R.string.err_bad_link)
                Store.saveLessons(this, Store.lessons(this) + Lesson(Store.newId(), chapters[sel].id, t, yt))
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    private fun addVideoSheet() {
        sheet(getString(R.string.act_video)) { c, d ->
            val title = field(getString(R.string.hint_title))
            val url = field(getString(R.string.hint_youtube), ltr = true)
            c.addView(title)
            c.addView(url)
            c.addView(primary(getString(R.string.add), 16) {
                val t = title.text.toString().trim()
                if (t.isEmpty()) return@primary toast(R.string.err_title)
                val yt = youtubeId(url.text.toString())
                if (yt.isEmpty()) return@primary toast(R.string.err_bad_link)
                Store.saveLessons(this, Store.lessons(this) + Lesson(Store.newId(), "", t, yt))
                d.dismiss(); refresh()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    private fun addDocSheet(kind: String) {
        sheet(getString(if (kind == "book") R.string.act_book else R.string.act_file)) { c, d ->
            var uri: Uri? = null
            var busy = false
            val title = field(getString(R.string.hint_title))
            val chosen = label("", 13f, R.color.mut, top = 4)
            c.addView(title)
            c.addView(link(getString(R.string.choose_pdf), top = 8) {
                pick("application/pdf") { u -> uri = u; chosen.text = getString(R.string.pdf_selected); chosen.drawTick(accent()) }
            })
            c.addView(chosen)
            c.addView(primary(getString(R.string.add), 12) {
                val t = title.text.toString().trim()
                val u = uri
                if (t.isEmpty()) return@primary toast(R.string.err_title)
                if (u == null) return@primary toast(R.string.err_pick_pdf)
                if (busy) return@primary
                busy = true
                toast(R.string.saving)
                val id = Store.newId()
                Thread {
                    val ok = Store.copyUri(this, u, Store.docFile(this, id))
                    runOnUiThread {
                        busy = false
                        if (ok) {
                            Store.saveDocs(this, Store.docs(this) + Doc(id, t, kind))
                            d.dismiss(); refresh()
                        } else toast(R.string.err_copy)
                    }
                }.start()
            })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }
}
