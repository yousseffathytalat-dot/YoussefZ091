package com.moknight.nexoraedu

/**
 * Phone number rules used by the sign-up screen (student only).
 * Accepted: Egyptian mobile `01[0125]xxxxxxxx` (also written `+20 1xxxxxxxxx` / `0020 1xxxxxxxxx`) or any international
 * number `+` followed by 8 to 15 digits. Arabic-Indic digits, spaces, dashes, dots and brackets are fine.
 * Same rules, same names on iPhone (`PhoneRules.swift`) and Windows (`PhoneRules.cs`).
 */
object PhoneRules {
    private val egLocal = Regex("^01[0125][0-9]{8}$")
    private val intl = Regex("^\\+[1-9][0-9]{7,14}$")

    /** Digits turned to 0-9, separators removed, `00` -> `+`, Egyptian `+20` -> `0`. */
    fun clean(raw: String): String {
        val sb = StringBuilder()
        for (ch in raw.trim()) {
            when (ch) {
                in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                in '0'..'9', '+' -> sb.append(ch)
                else -> {} // spaces, - . ( ) and anything else are dropped
            }
        }
        var s = sb.toString()
        if (s.startsWith("00")) s = "+" + s.substring(2)
        if (s.startsWith("+201") && s.length == 13) s = "0" + s.substring(3)
        return s
    }

    /** The number to store, or null when it is not valid. */
    fun normalize(raw: String): String? {
        val s = clean(raw)
        return if (egLocal.matches(s) || intl.matches(s)) s else null
    }

    /** String resource of the message to show under the field, or null when the number is fine. */
    fun error(raw: String): Int? = when {
        raw.isBlank() -> R.string.err_phone_required
        normalize(raw) == null -> R.string.err_phone_invalid
        else -> null
    }
}

/**
 * Sending and checking the SMS code. There is no server in the app yet, so this is the one place to connect it.
 * Only called while [OtpConfig.PhoneOtpEnabled] is true; until a real backend is wired [check] never accepts a code.
 */
object PhoneVerifier {
    fun send(phone: String) { /* TODO: call the SMS backend */ }
    fun check(phone: String, code: String): Boolean = false
}
