package com.moknight.nexoraedu

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

/**
 * Launch animation, all drawn with a Canvas (no libraries):
 *  1. dust floating on the screen is pulled together and forms the rounded square of the icon,
 *  2. a second set of white / gold dust gathers inside the square and draws the flask,
 *  3. the dust turns into the real icon (flash, shine, ring and a small burst of sparks).
 */
class SplashView(ctx: Context) : View(ctx) {
    private class P(
        val sx: Float, val sy: Float, val tx: Float, val ty: Float,
        val delay: Float, val dur: Float, val r: Float, val color: Int, val swirl: Float, val seed: Float,
    )

    companion object {
        /** Real running time. The whole timeline below was written for 4300 ms and is played faster (x1.3) so the entry takes about 3.3 s. */
        const val TOTAL = 3300L
        const val TIMELINE = 4300f

        // timeline (ms, in the TIMELINE scale)
        private const val SOLID_IN = 1100f
        private const val SOLID_OUT = 1750f
        private const val SQ_FADE = 1550f
        private const val SQ_FADE_END = 2100f
        private const val FLASK_IN = 2350f
        private const val FLASK_FULL = 2950f
        private const val FL_FADE_END = 3250f
        private const val BURST = 2950f
        private const val BURST_END = 3950f
    }

    private val d = resources.displayMetrics.density
    private val rnd = Random(11)
    private var cx = 0f
    private var cy = 0f
    private var size = 0f
    private var c1 = Color.CYAN
    private var c2 = Color.BLUE
    private var square: Array<P> = emptyArray()
    private var flask: Array<P> = emptyArray()
    private var sparks: Array<FloatArray> = emptyArray() // angle, speed, size, seed
    private var stars: Array<FloatArray> = emptyArray()  // x (0..1), y (0..1), size, phase
    private val seg = Path()
    private var t = 0f
    private var ready = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val rr = RectF()
    private val clip = Path()
    private var haloShader: Shader? = null
    private var sqShader: Shader? = null
    private var sheenShader: Shader? = null
    private var plateFill: Shader? = null
    private var plateEdge: Shader? = null

    // flask artwork in the same 64 x 64 units as ic_flask.xml
    private val mainLines = ArrayList<Path>()   // width 2.3
    private val thinLines = ArrayList<Path>()   // width 1.6 (the two orbits)
    private val bubbles = ArrayList<Triple<Float, Float, Float>>() // x, y, r
    private val gold = 0xFFF5C451.toInt()

    private val anim = ValueAnimator.ofFloat(0f, TOTAL.toFloat()).apply {
        duration = TOTAL
        interpolator = LinearInterpolator()
        addUpdateListener { t = (it.animatedValue as Float) * (TIMELINE / TOTAL); invalidate() }
    }

    init {
        buildArt()
    }

    private fun buildArt() {
        mainLines.add(Path().apply { moveTo(24f, 9f); lineTo(40f, 9f) })
        mainLines.add(Path().apply {
            moveTo(28f, 9f); lineTo(28f, 24f); lineTo(12.5f, 51.5f)
            quadTo(9.5f, 57f, 16f, 57f); lineTo(48f, 57f)
            quadTo(54.5f, 57f, 51.5f, 51.5f); lineTo(36f, 24f); lineTo(36f, 9f)
        })
        mainLines.add(Path().apply { moveTo(18f, 42f); quadTo(25f, 38f, 32f, 42f); quadTo(39f, 46f, 46f, 42f) })
        for (deg in floatArrayOf(-30f, 30f)) {
            val p = Path().apply { addOval(RectF(32f - 8.5f, 49f - 3f, 32f + 8.5f, 49f + 3f), Path.Direction.CW) }
            val m = Matrix().apply { setRotate(deg, 32f, 49f) }
            p.transform(m)
            thinLines.add(p)
        }
        bubbles.add(Triple(32f, 19f, 1.7f))
        bubbles.add(Triple(33.5f, 14f, 1.1f))
    }

    /** [centerX] / [centerY] (view pixels) and [side] (px) of the icon square. */
    fun begin(centerX: Float, centerY: Float, side: Float, color1: Int, color2: Int) {
        cx = centerX; cy = centerY; size = side; c1 = color1; c2 = color2
        val left = cx - size / 2
        val top = cy - size / 2
        sqShader = LinearGradient(left, top, left + size, top + size, c1, c2, Shader.TileMode.CLAMP)
        sheenShader = LinearGradient(0f, top, 0f, top + size * 0.5f, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        haloShader = RadialGradient(cx, cy, size * 1.15f,
            intArrayOf((c1 and 0xFFFFFF) or 0x66000000, (c2 and 0xFFFFFF) or 0x22000000, Color.TRANSPARENT),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        val pl = size * 0.78f
        plateFill = LinearGradient(0f, cy - pl, 0f, cy + pl,
            intArrayOf(0x4DFFFFFF, 0x14FFFFFF, 0x26FFFFFF), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        plateEdge = LinearGradient(cx - pl, cy - pl, cx + pl, cy + pl,
            intArrayOf(0xCCFFFFFF.toInt(), (c1 and 0xFFFFFF) or 0x55000000, (c2 and 0xFFFFFF) or 0x99000000.toInt()),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        buildSquare()
        buildFlask()
        buildSparks()
        ready = true
        anim.start()
    }

    fun stop() { anim.cancel() }

    private fun mix(a: Int, b: Int, f: Float): Int {
        val k = f.coerceIn(0f, 1f)
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        return Color.rgb(r, g, bl)
    }

    private fun buildSquare() {
        val w = width.toFloat().coerceAtLeast(1f)
        val h = height.toFloat().coerceAtLeast(1f)
        val left = cx - size / 2
        val top = cy - size / 2
        val rad = size * 0.27f
        val list = ArrayList<P>()
        val n = 1100
        while (list.size < n) {
            // 35% on the outline (crisp edges), the rest fills the inside
            var x: Float
            var y: Float
            if (list.size % 100 < 35) {
                val per = 4 * size
                var s = rnd.nextFloat() * per
                if (s < size) { x = left + s; y = top }
                else if (s < 2 * size) { s -= size; x = left + size; y = top + s }
                else if (s < 3 * size) { s -= 2 * size; x = left + size - s; y = top + size }
                else { s -= 3 * size; x = left; y = top + size - s }
                if (!insideRound(x, y, left, top, rad)) continue
            } else {
                x = left + rnd.nextFloat() * size
                y = top + rnd.nextFloat() * size
                if (!insideRound(x, y, left, top, rad)) continue
            }
            val diag = ((x - left) + (y - top)) / (2 * size)
            list.add(P(
                sx = rnd.nextFloat() * w, sy = rnd.nextFloat() * h, tx = x, ty = y,
                delay = rnd.nextFloat() * 600f, dur = 850f + rnd.nextFloat() * 300f,
                r = (0.9f + rnd.nextFloat() * 1.1f) * d, color = mix(c1, c2, diag),
                swirl = (rnd.nextFloat() - 0.5f) * 170f * d, seed = rnd.nextFloat(),
            ))
        }
        square = list.toTypedArray()
    }

    private fun insideRound(x: Float, y: Float, left: Float, top: Float, rad: Float): Boolean {
        val px = x.coerceIn(left + rad, left + size - rad)
        val py = y.coerceIn(top + rad, top + size - rad)
        return hypot(x - px, y - py) <= rad + 0.5f
    }

    private fun buildFlask() {
        val s = size * 0.654f / 64f          // same proportion as the 68dp flask inside the 104dp icon
        val ox = cx - 32f * s
        val oy = cy - 32f * s
        val all = ArrayList<Path>().apply { addAll(mainLines); addAll(thinLines) }
        val lens = all.map { PathMeasure(it, false).length }
        val sum = lens.sum()
        val total = 420
        val list = ArrayList<P>()
        val pos = FloatArray(2)
        for ((i, path) in all.withIndex()) {
            val pm = PathMeasure(path, false)
            val cnt = (total * lens[i] / sum).toInt().coerceAtLeast(8)
            for (k in 0 until cnt) {
                pm.getPosTan(pm.length * (k + rnd.nextFloat() * 0.6f) / cnt, pos, null)
                list.add(flaskParticle(ox + pos[0] * s, oy + pos[1] * s, Color.WHITE, 0.85f + rnd.nextFloat() * 0.6f))
            }
        }
        for (b in bubbles) {
            for (k in 0 until 7) {
                val a = (k / 7f) * 2f * PI.toFloat()
                list.add(flaskParticle(ox + (b.first + cos(a) * b.third) * s, oy + (b.second + sin(a) * b.third) * s, Color.WHITE, 0.8f))
            }
        }
        for (k in 0 until 14) { // the golden nucleus
            val a = rnd.nextFloat() * 2f * PI.toFloat()
            val rr2 = rnd.nextFloat() * 2.3f
            list.add(flaskParticle(ox + (32f + cos(a) * rr2) * s, oy + (49f + sin(a) * rr2) * s, gold, 1.1f))
        }
        flask = list.toTypedArray()
    }

    private fun flaskParticle(x: Float, y: Float, color: Int, r: Float): P {
        // starts somewhere inside the square, so the dust seems to gather "inside the icon"
        return P(
            sx = cx + (rnd.nextFloat() - 0.5f) * size * 0.95f, sy = cy + (rnd.nextFloat() - 0.5f) * size * 0.95f,
            tx = x, ty = y, delay = 1400f + rnd.nextFloat() * 450f, dur = 600f + rnd.nextFloat() * 250f,
            r = r * d, color = color, swirl = (rnd.nextFloat() - 0.5f) * 60f * d, seed = rnd.nextFloat(),
        )
    }

    private fun buildSparks() {
        stars = Array(70) { floatArrayOf(rnd.nextFloat(), rnd.nextFloat(), 0.6f + rnd.nextFloat() * 1.4f, rnd.nextFloat() * 6.28f) }
        sparks = Array(48) {
            floatArrayOf(rnd.nextFloat() * 2f * PI.toFloat(), 0.55f + rnd.nextFloat() * 0.9f, 1f + rnd.nextFloat() * 1.6f, rnd.nextFloat())
        }
    }

    private fun smooth(x: Float): Float { val k = x.coerceIn(0f, 1f); return k * k * (3 - 2 * k) }

    private fun drawParticles(c: Canvas, arr: Array<P>, now: Float, fadeIn: Boolean, alphaMul: Float) {
        if (alphaMul <= 0.01f) return
        for (p in arr) {
            val pr = ((now - p.delay) / p.dur).coerceIn(0f, 1f)
            val e = 1f - (1f - pr).pow(3)
            var x = p.sx + (p.tx - p.sx) * e
            var y = p.sy + (p.ty - p.sy) * e
            if (pr <= 0f) { // waiting: float around where it started
                x += sin(now * 0.0021f + p.seed * 6.28f) * 7f * d
                y += cos(now * 0.0017f + p.seed * 6.28f) * 7f * d
            } else if (pr < 1f) { // flying: a curved path, not a straight line
                val dx = p.tx - p.sx
                val dy = p.ty - p.sy
                val len = hypot(dx, dy).coerceAtLeast(1f)
                val bend = p.swirl * 4f * pr * (1f - pr)
                x += -dy / len * bend
                y += dx / len * bend
            } else { // arrived: tiny shimmer
                x += sin(now * 0.006f + p.seed * 6.28f) * 0.7f * d
                y += cos(now * 0.005f + p.seed * 6.28f) * 0.7f * d
            }
            var a = alphaMul
            if (fadeIn) a *= smooth((now - (p.delay - 250f)) / 250f)
            if (a <= 0.01f) continue
            val col = p.color and 0xFFFFFF
            paint.shader = null
            paint.color = col or ((a * 60).toInt().coerceIn(0, 255) shl 24)
            c.drawCircle(x, y, p.r * 2.4f, paint)
            if (pr > 0f && pr < 1f) { // a short fading tail behind every flying dot
                val dx2 = p.tx - p.sx
                val dy2 = p.ty - p.sy
                val len2 = hypot(dx2, dy2).coerceAtLeast(1f)
                for (k in 1..3) {
                    val pk = (pr - k * 0.05f).coerceAtLeast(0f)
                    val ek = 1f - (1f - pk).pow(3)
                    val bend2 = p.swirl * 4f * pk * (1f - pk)
                    val tx2 = p.sx + dx2 * ek - dy2 / len2 * bend2
                    val ty2 = p.sy + dy2 * ek + dx2 / len2 * bend2
                    paint.color = col or ((a * (95 - k * 28)).toInt().coerceIn(0, 255) shl 24)
                    c.drawCircle(tx2, ty2, p.r * (1f - k * 0.2f), paint)
                }
            }
            paint.color = col or ((a * 255).toInt().coerceIn(0, 255) shl 24)
            c.drawCircle(x, y, p.r, paint)
        }
    }

    override fun onDraw(c: Canvas) {
        if (!ready) return
        // the whole icon gives a small pulse when the burst happens
        val bk = ((t - BURST) / 500f).coerceIn(0f, 1f)
        val bump = if (t >= BURST && t <= BURST + 500f) 1f + 0.07f * sin(bk * PI.toFloat()) else 1f
        c.save()
        c.scale(bump, bump, cx, cy)
        drawAll(c)
        c.restore()
    }

    private fun drawAll(c: Canvas) {
        val now = t
        // twinkling background dust
        val sa = 1f - smooth((now - FL_FADE_END) / 700f) * 0.6f
        for (st in stars) {
            val tw = 0.5f + 0.5f * sin(now * 0.0032f + st[3])
            paint.shader = null
            paint.color = (if (st[3] > 3.1f) c1 else Color.WHITE) and 0xFFFFFF or ((tw * sa * 120).toInt().coerceIn(0, 255) shl 24)
            c.drawCircle(st[0] * width, st[1] * height + sin(now * 0.0007f + st[3]) * 6f * d, st[2] * d, paint)
        }
        val left = cx - size / 2
        val top = cy - size / 2
        val rad = size * 0.27f

        // soft glow behind the square
        val solid = smooth((now - SOLID_IN) / (SOLID_OUT - SOLID_IN))
        if (solid > 0f) {
            val pulse = 0.85f + 0.15f * sin(now * 0.004f)
            paint.shader = haloShader
            paint.alpha = (solid * pulse * 255).toInt().coerceIn(0, 255)
            c.drawCircle(cx, cy, size * 1.15f, paint)
            paint.shader = null
            paint.alpha = 255
        }

        drawGlass(c, now)

        // the solid icon square
        if (solid > 0f) {
            val sc = 1f + 0.05f * (1f - solid)
            c.save()
            c.scale(sc, sc, cx, cy)
            rr.set(left, top, left + size, top + size)
            paint.shader = sqShader
            paint.alpha = (solid * 255).toInt()
            c.drawRoundRect(rr, rad, rad, paint)
            // glass sheen on the top half
            paint.shader = sheenShader
            paint.alpha = (solid * 255).toInt()
            c.drawRoundRect(rr, rad, rad, paint)
            paint.shader = null
            paint.alpha = 255
            c.restore()
        }

        // square dust (fades out while the solid square takes over)
        drawParticles(c, square, now, false, 1f - smooth((now - SQ_FADE) / (SQ_FADE_END - SQ_FADE)))

        // flask dust, then the real flask fades in over it
        val real = smooth((now - FLASK_IN) / (FLASK_FULL - FLASK_IN))
        drawParticles(c, flask, now, true, 1f - smooth((now - FLASK_FULL) / (FL_FADE_END - FLASK_FULL)))
        if (real > 0f) drawFlask(c, real)

        // shine sweeping over the icon + ring + sparks = the "transformation"
        if (now in BURST..BURST_END) {
            val k = (now - BURST) / (BURST_END - BURST)
            // shine band
            c.save()
            clip.reset()
            rr.set(left, top, left + size, top + size)
            clip.addRoundRect(rr, rad, rad, Path.Direction.CW)
            c.clipPath(clip)
            val bx = left - size * 0.6f + (size * 2.2f) * smooth(k)
            paint.shader = LinearGradient(bx, top, bx + size * 0.5f, top + size * 0.5f,
                intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(rr, paint)
            paint.shader = null
            c.restore()
            // ring
            strokePaint.shader = null
            strokePaint.strokeWidth = 2f * d
            strokePaint.color = (c1 and 0xFFFFFF) or (((1f - k) * 200).toInt().coerceIn(0, 255) shl 24)
            val ringR = size * (0.55f + 0.9f * smooth(k))
            c.drawCircle(cx, cy, ringR, strokePaint)
            val k2 = ((now - BURST - 220f) / (BURST_END - BURST)).coerceIn(0f, 1f)
            if (k2 > 0f && k2 < 1f) {
                strokePaint.strokeWidth = 1.5f * d
                strokePaint.color = (c2 and 0xFFFFFF) or (((1f - k2) * 160).toInt().coerceIn(0, 255) shl 24)
                c.drawCircle(cx, cy, size * (0.5f + 1.2f * smooth(k2)), strokePaint)
            }
            // sparks
            for (s in sparks) {
                val sp = (k - s[3] * 0.15f).coerceIn(0f, 1f)
                val dist = size * (0.5f + s[1] * 0.9f * (1f - (1f - sp).pow(2)))
                val x = cx + cos(s[0]) * dist
                val y = cy + sin(s[0]) * dist
                val a = (1f - sp)
                val base = if (s[3] > 0.5f) gold else Color.WHITE
                paint.color = (base and 0xFFFFFF) or ((a * 230).toInt().coerceIn(0, 255) shl 24)
                c.drawCircle(x, y, s[2] * d * (1f - sp * 0.5f), paint)
            }
        }
    }

    /**
     * The glass: a frosted plate that grows behind the icon (soft fill, bright rim, specular line on top) and two glass beads
     * that float around it. It appears with the solid square and stays to the end, so the icon looks like it sits on glass.
     */
    private fun drawGlass(c: Canvas, now: Float) {
        val g = smooth((now - (SOLID_IN - 250f)) / 800f)
        if (g <= 0f) return
        val half = size * 0.78f * (0.86f + 0.14f * g)
        val rad = half * 0.42f
        rr.set(cx - half, cy - half, cx + half, cy + half)
        paint.shader = plateFill
        paint.alpha = (g * 255).toInt()
        c.drawRoundRect(rr, rad, rad, paint)
        paint.shader = null
        paint.alpha = 255
        strokePaint.shader = plateEdge
        strokePaint.strokeWidth = 1.4f * d
        strokePaint.alpha = (g * 255).toInt()
        c.drawRoundRect(rr, rad, rad, strokePaint)
        strokePaint.shader = null
        strokePaint.alpha = 255
        // specular line along the top edge
        paint.color = 0x00FFFFFF or ((g * 120).toInt().coerceIn(0, 255) shl 24)
        c.drawRoundRect(cx - half * 0.55f, cy - half + 5f * d, cx + half * 0.55f, cy - half + 7f * d, 2f * d, 2f * d, paint)
        // two glass beads drifting around the plate
        val beads = arrayOf(floatArrayOf(0.17f, 1.12f, 0.00045f, 0.4f), floatArrayOf(0.1f, 1.32f, -0.0006f, 2.6f))
        for (b in beads) {
            val a = now * b[2] + b[3]
            val bx = cx + cos(a) * size * b[1]
            val by = cy + sin(a) * size * b[1] * 0.8f
            val br = size * b[0]
            paint.color = 0x00FFFFFF or ((g * 46).toInt().coerceIn(0, 255) shl 24)
            c.drawCircle(bx, by, br, paint)
            strokePaint.color = 0x00FFFFFF or ((g * 130).toInt().coerceIn(0, 255) shl 24)
            strokePaint.strokeWidth = 1f * d
            c.drawCircle(bx, by, br, strokePaint)
            paint.color = 0x00FFFFFF or ((g * 150).toInt().coerceIn(0, 255) shl 24)
            c.drawCircle(bx - br * 0.35f, by - br * 0.38f, br * 0.2f, paint)
        }
    }

    /** [alpha] 0..1 = how much of the flask is drawn: the lines are traced stroke by stroke, then the bubbles and the nucleus appear. */
    private fun drawFlask(c: Canvas, alpha: Float) {
        val s = size * 0.654f / 64f
        c.save()
        c.translate(cx - 32f * s, cy - 32f * s)
        c.scale(s, s)
        val a = (alpha * 3f).coerceAtMost(1f)
        strokePaint.shader = null
        strokePaint.color = Color.WHITE
        strokePaint.alpha = (a * 255).toInt().coerceIn(0, 255)
        strokePaint.strokeWidth = 2.3f
        for (p in mainLines) {
            val pm = PathMeasure(p, false)
            seg.reset()
            if (pm.getSegment(0f, pm.length * alpha, seg, true)) c.drawPath(seg, strokePaint)
        }
        strokePaint.strokeWidth = 1.6f
        for (p in thinLines) {
            val pm = PathMeasure(p, false)
            seg.reset()
            if (pm.getSegment(0f, pm.length * alpha, seg, true)) c.drawPath(seg, strokePaint)
        }
        val tail = ((alpha - 0.6f) / 0.4f).coerceIn(0f, 1f)
        strokePaint.alpha = (tail * 255).toInt().coerceIn(0, 255)
        for (b in bubbles) {
            strokePaint.strokeWidth = if (b.third > 1.5f) 1.5f else 1.3f
            c.drawCircle(b.first, b.second, b.third, strokePaint)
        }
        paint.shader = null
        paint.color = (gold and 0xFFFFFF) or (((tail * 255).toInt().coerceIn(0, 255)) shl 24)
        c.drawCircle(32f, 49f, 2.4f, paint)
        // small bubbles keep rising inside the flask once it is complete
        if (t > FLASK_FULL) {
            val f = ((t - FLASK_FULL) / 700f).coerceIn(0f, 1f)
            for (i in 0 until 5) {
                val ph = ((t - FLASK_FULL) * 0.0009f + i * 0.2f) % 1f
                val bx = 32f + sin(ph * 12.56f + i) * (1.2f + i * 0.5f) * (0.4f + 0.6f * (1f - ph))
                val by = 54f - ph * 26f
                paint.color = 0x00FFFFFF or (((1f - ph) * 170f * f).toInt().coerceIn(0, 255) shl 24)
                c.drawCircle(bx, by, 0.9f + (i % 3) * 0.35f, paint)
            }
        }
        c.restore()
        strokePaint.alpha = 255
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }
}
