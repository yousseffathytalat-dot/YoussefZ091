package com.moknight.nexoraedu

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.Editable
import android.text.TextWatcher
import android.text.method.PasswordTransformationMethod
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView

class LoginActivity : BaseActivity() {
    private var teacher = false
    private var signup = false
    private var passVisible = false
    private var admin = false

    /** Hidden entry to the admin side: holding the logo for [ADMIN_HOLD_MS] without lifting the finger. */
    private val holdHandler = Handler(Looper.getMainLooper())
    private val enterAdmin = Runnable { openAdminMode() }

    private lateinit var card: View
    private lateinit var logo: View
    private lateinit var seg: SegControl
    private lateinit var fPass2: View
    private lateinit var etPass2: EditText
    private lateinit var signRow: View
    private lateinit var signCheck: DrawnCheck
    private lateinit var icLock1: View
    private lateinit var icLock2: View
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private lateinit var fName: View
    private lateinit var fPhone: View
    private lateinit var fGrade: View
    private lateinit var fCode: View
    private lateinit var etCode: EditText
    private lateinit var phoneError: TextView
    private lateinit var optPhone: View
    private lateinit var teacherHint: TextView
    private lateinit var error: TextView
    private lateinit var btnGo: TextView
    private lateinit var altRow: View
    private lateinit var altText: TextView
    private lateinit var altLink: TextView
    private lateinit var etName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPhone: EditText
    private lateinit var etPass: EditText
    private lateinit var gradeChips: GradeChips
    private lateinit var eye: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        card = findViewById(R.id.card)
        logo = findViewById(R.id.logo)
        seg = findViewById(R.id.seg)
        fPass2 = findViewById(R.id.fPass2)
        etPass2 = findViewById(R.id.etPass2)
        signRow = findViewById(R.id.signRow)
        signCheck = findViewById(R.id.signCheck)
        icLock1 = findViewById(R.id.icLock1)
        icLock2 = findViewById(R.id.icLock2)
        title = findViewById(R.id.title)
        subtitle = findViewById(R.id.subtitle)
        fName = findViewById(R.id.fName)
        fPhone = findViewById(R.id.fPhone)
        fGrade = findViewById(R.id.fGrade)
        fCode = findViewById(R.id.fCode)
        etCode = findViewById(R.id.etCode)
        phoneError = findViewById(R.id.phoneError)
        optPhone = findViewById(R.id.optPhone)
        teacherHint = findViewById(R.id.teacherHint)
        error = findViewById(R.id.error)
        btnGo = findViewById(R.id.btnGo)
        altRow = findViewById(R.id.altRow)
        altText = findViewById(R.id.altText)
        altLink = findViewById(R.id.altLink)
        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone)
        etPass = findViewById(R.id.etPass)
        gradeChips = findViewById(R.id.gradeChips)
        eye = findViewById(R.id.eye)

        savedInstanceState?.let {
            teacher = it.getBoolean("teacher")
            signup = it.getBoolean("signup")
            admin = it.getBoolean("admin")
            gradeChips.select(it.getInt("grade"), false)
        }

        // one accent indicator slides between student and teacher
        seg.setItems(listOf(getString(R.string.role_student), getString(R.string.role_teacher)), if (teacher) 1 else 0)
        seg.onSelect = { i -> setRole(i == 1) }
        // "create a new account" + drawn checkbox: ticking it grows the card
        signCheck.setChecked(signup, false, false)
        signCheck.onChange = { on -> signup = on; refresh(true) }
        signRow.setOnClickListener { signCheck.setChecked(!signCheck.checked, true) }
        altLink.setOnClickListener { if (admin) closeAdminMode() }
        btnGo.setOnClickListener { submit() }
        eye.setOnClickListener {
            passVisible = !passVisible
            val pos = etPass.selectionStart
            etPass.transformationMethod = if (passVisible) null else PasswordTransformationMethod.getInstance()
            etPass.setSelection(pos.coerceAtLeast(0))
            etPass2.transformationMethod = etPass.transformationMethod
            eyeBlink(eye, passVisible)
        }
        etPass.setOnFocusChangeListener { _, f -> if (f) lockWiggle(icLock1) }
        etPass2.setOnFocusChangeListener { _, f -> if (f) lockWiggle(icLock2) }
        etPass.imeOptions = EditorInfo.IME_ACTION_DONE
        etPass.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) { submit(); true } else false
        }
        etPass2.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) { submit(); true } else false
        }
        etPhone.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) { submit(); true } else false
        }
        val clear = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { error.visibility = View.GONE }
        }
        listOf(etName, etEmail, etPhone, etPass, etPass2, etCode).forEach { it.addTextChangedListener(clear) }
        // phone (student sign-up): the message under the field goes away while typing and comes back when the field is left
        etPhone.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { phoneError.visibility = View.GONE }
        })
        etPhone.setOnFocusChangeListener { _, focused ->
            if (!focused && phoneSignup() && etPhone.text.isNotBlank()) showPhoneError(PhoneRules.error(etPhone.text.toString()))
        }
        setupAdminHold()
        refresh(false)
        playIntro(savedInstanceState == null)
    }

    private var floatAnim: ObjectAnimator? = null

    /** Glass entrance: the logo pops in and keeps floating gently, the card slides up. No touch feedback on the logo. */
    private fun playIntro(first: Boolean) {
        walkPress(findViewById(android.R.id.content))
        glowView(logo, accent(), 14f)
        glowView(btnGo, accent(), 6f)
        floatAnim = ObjectAnimator.ofFloat(logo, "translationY", 0f, -dp(6).toFloat()).apply {
            duration = 2600
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            start()
        }
        if (!first) return
        logo.alpha = 0f
        logo.scaleX = 0.6f
        logo.scaleY = 0.6f
        logo.animate().setStartDelay(60).setInterpolator(android.view.animation.OvershootInterpolator(2f))
            .alpha(1f).scaleX(1f).scaleY(1f).setDuration(520).start()
        card.alpha = 0f
        card.translationY = dp(46).toFloat()
        card.animate().setStartDelay(200).setInterpolator(android.view.animation.DecelerateInterpolator(2f))
            .alpha(1f).translationY(0f).setDuration(520).start()
    }

    /** No hint of any kind: no ripple, no progress, no vibration until the full time has passed. */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupAdminHold() {
        logo.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    holdHandler.removeCallbacks(enterAdmin)
                    holdHandler.postDelayed(enterAdmin, ADMIN_HOLD_MS)
                }
                // sliding the finger off the logo cancels the count too
                MotionEvent.ACTION_MOVE ->
                    if (e.x < 0 || e.y < 0 || e.x > v.width || e.y > v.height) holdHandler.removeCallbacks(enterAdmin)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> holdHandler.removeCallbacks(enterAdmin)
            }
            true
        }
    }

    private fun openAdminMode() {
        if (admin || isFinishing) return
        buzz()
        admin = true
        signup = false
        signCheck.setChecked(false, false, false)
        clearFields()
        refresh(true)
    }

    private fun closeAdminMode() {
        admin = false
        clearFields()
        refresh(true)
    }

    private fun clearFields() {
        listOf(etName, etEmail, etPhone, etPass, etPass2, etCode).forEach { it.setText("") }
    }

    /** One light vibration. */
    @Suppress("DEPRECATION")
    private fun buzz() {
        try {
            val vib = getSystemService(VIBRATOR_SERVICE) as? Vibrator ?: return
            vib.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) { /* no vibrator or no permission: skip */ }
    }

    override fun onPause() {
        super.onPause()
        holdHandler.removeCallbacks(enterAdmin)
    }

    override fun onDestroy() {
        super.onDestroy()
        floatAnim?.cancel()
        holdHandler.removeCallbacks(enterAdmin)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (admin) closeAdminMode() else super.onBackPressed()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("teacher", teacher)
        outState.putBoolean("signup", signCheck.checked)
        outState.putBoolean("admin", admin)
        outState.putInt("grade", gradeChips.selected)
    }

    private fun setRole(t: Boolean) {
        if (teacher == t) return
        teacher = t
        refresh(true)
    }

    /** Phone is required for every new account (student and teacher); the admin screens are untouched. */
    private fun studentSignup() = signup && !teacher && !admin
    private fun phoneSignup() = signup && !admin

    private fun showPhoneError(msg: Int?) {
        if (msg == null) { phoneError.visibility = View.GONE; return }
        phoneError.setText(msg)
        phoneError.visibility = View.VISIBLE
    }

    private fun refresh(animate: Boolean) {
        seg.select(if (teacher) 1 else 0, false)
        error.visibility = View.GONE
        phoneError.visibility = View.GONE
        val up = signup && !admin
        val adminSetup = admin && Store.admin(this) == null
        seg.visibility = if (admin) View.GONE else View.VISIBLE
        signRow.visibility = if (admin) View.GONE else View.VISIBLE
        altRow.visibility = if (admin) View.VISIBLE else View.GONE
        etPass.imeOptions = if (adminSetup || up) EditorInfo.IME_ACTION_NEXT else EditorInfo.IME_ACTION_DONE
        when {
            admin -> if (adminSetup) { title.setText(R.string.title_admin_setup); subtitle.setText(R.string.sub_admin_setup) }
                     else { title.setText(R.string.title_admin); subtitle.setText(R.string.sub_admin) }
            teacher -> { title.setText(R.string.title_teacher); subtitle.setText(R.string.sub_teacher) }
            up -> { title.setText(R.string.title_signup); subtitle.setText(R.string.sub_signup) }
            else -> { title.setText(R.string.title_signin); subtitle.setText(R.string.sub_signin) }
        }
        // the extra fields appear one after the other, top to bottom
        val h = dp(52)
        val m = dp(14)
        val showName = up // teachers type their full name too
        val showPass2 = adminSetup || up
        val showPhone = up
        val showGrade = up && !teacher // students pick one of the 3 fixed classes
        optPhone.visibility = View.GONE // phone is required for students and teachers: no "optional" tag
        etPass2.imeOptions = if (showPhone) EditorInfo.IME_ACTION_NEXT else EditorInfo.IME_ACTION_DONE
        // the teacher needs the registration code before an account can be made (new teacher account = sign-up ticked, or first sign-in)
        animateRow(fCode, teacher && !admin && (signup || Store.teacher(this) == null), 0, h, m, animate)
        animateRow(fName, showName, 0, h, m, animate)
        animateRow(fPass2, showPass2, if (showName) 70 else 0, h, m, animate)
        animateRow(fPhone, showPhone, if (showName) 140 else 70, h, m, animate)
        animateRow(fGrade, showGrade, 210, dp(84), m, animate)
        teacherHint.visibility = if (teacher && !admin && !up && Store.teacher(this) == null) View.VISIBLE else View.GONE
        btnGo.setText(if (up || adminSetup) R.string.btn_signup else R.string.btn_signin)
        altText.text = ""
        altLink.setText(R.string.back)
    }

    private fun fail(msg: Int) {
        Sfx.play(Sfx.S.ERROR)
        error.setText(msg)
        error.visibility = View.VISIBLE
        lockWiggle(icLock1)
        if (fPass2.visibility == View.VISIBLE) lockWiggle(icLock2)
        ObjectAnimator.ofFloat(card, "translationX", 0f, -18f, 18f, -12f, 12f, -6f, 0f).setDuration(380).start()
    }

    /** Student sign-up: the phone problem is written under the field, the card shakes and the cursor goes to the field. */
    private fun failPhone(msg: Int) {
        Sfx.play(Sfx.S.ERROR)
        showPhoneError(msg)
        ObjectAnimator.ofFloat(card, "translationX", 0f, -18f, 18f, -12f, 12f, -6f, 0f).setDuration(380).start()
        etPhone.requestFocus()
    }

    private fun open(cls: Class<*>) {
        Sfx.play(Sfx.S.SUCCESS)
        startActivity(Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }

    private fun submit() {
        val email = etEmail.text.toString().trim().lowercase()
        val pass = etPass.text.toString()

        if (admin) {
            if (email.isEmpty() || pass.isEmpty()) return fail(R.string.err_enter_creds)
            val a = Store.admin(this)
            if (a == null) {
                if (!email.contains("@")) return fail(R.string.err_enter_creds)
                if (pass.length < 6) return fail(R.string.err_teacher_short)
                if (pass != etPass2.text.toString()) return fail(R.string.err_pw_mismatch)
                Store.setAdmin(this, email, pass)
            } else if (a.first != email || a.second != Store.hash(pass)) {
                return fail(R.string.err_bad_login)
            }
            Store.setSession(this, "admin", email)
            return open(AdminActivity::class.java)
        }

        if (teacher) {
            if (email.isEmpty() || pass.isEmpty()) return fail(R.string.err_enter_creds)
            val t = Store.teacher(this)
            if (signup) {
                if (!email.contains("@")) return fail(R.string.err_enter_creds)
                if (t != null) return fail(R.string.err_teacher_exists)
                TeacherCode.errorRes(TeacherCode.verify(this, etCode.text.toString()))?.let { return fail(it) }
                val tName = etName.text.toString().trim()
                if (tName.isEmpty()) return fail(R.string.err_name_required)
                if (pass.length < 6) return fail(R.string.err_teacher_short)
                if (pass != etPass2.text.toString()) return fail(R.string.err_pw_mismatch)
                // phone: required, checked by PhoneRules (same as the student sign-up)
                val tPhoneErr = PhoneRules.error(etPhone.text.toString())
                showPhoneError(tPhoneErr)
                if (tPhoneErr != null) return failPhone(tPhoneErr)
                val tPhone = PhoneRules.normalize(etPhone.text.toString())!!
                Store.setTeacher(this, email, pass, tPhone, tName)
                TeacherCode.markUsed(this, etCode.text.toString())
            } else if (t == null) {
                if (!email.contains("@")) return fail(R.string.err_enter_creds)
                TeacherCode.errorRes(TeacherCode.verify(this, etCode.text.toString()))?.let { return fail(it) }
                if (pass.length < 6) return fail(R.string.err_teacher_short)
                Store.setTeacher(this, email, pass)
                TeacherCode.markUsed(this, etCode.text.toString())
            } else if (t.first != email || t.second != Store.hash(pass)) {
                return fail(R.string.err_bad_login)
            }
            Store.setSession(this, "teacher", email)
            return open(TeacherActivity::class.java)
        }

        if (!signup) {
            if (email.isEmpty() || pass.isEmpty()) return fail(R.string.err_enter_creds)
            val s = Store.findStudent(this, email)
            if (s == null || s.pw != Store.hash(pass)) return fail(R.string.err_bad_login)
            Store.setSession(this, "student", email)
            return open(StudentActivity::class.java)
        }

        val name = etName.text.toString().trim()
        // phone: required, checked by PhoneRules; the message goes under the field (also when something else is missing too)
        val phoneErr = PhoneRules.error(etPhone.text.toString())
        showPhoneError(phoneErr)
        if (name.isEmpty() || !email.contains("@") || pass.length < 6)
            return fail(R.string.err_fill_all)
        if (phoneErr != null) return failPhone(phoneErr)
        val phone = PhoneRules.normalize(etPhone.text.toString())!!
        if (pass != etPass2.text.toString()) return fail(R.string.err_pw_mismatch)
        val all = Store.students(this)
        if (all.any { it.email == email }) return fail(R.string.err_email_used)
        val grade = Store.FIXED_GRADES.getOrElse(gradeChips.selected) { Store.FIXED_GRADES[0] }
        val createAccount = {
            all.add(Student(name, phone, email, Store.hash(pass), grade))
            Store.saveStudents(this, all)
            Store.setSession(this, "student", email)
            open(StudentActivity::class.java)
        }
        // code check (hidden while OtpConfig.PhoneOtpEnabled is false: show() returns false and the account is created as before)
        if (OtpConfig.PhoneOtpEnabled) PhoneVerifier.send(phone)
        val shown = OtpView(
            this, phone,
            verify = { PhoneVerifier.check(phone, it) },
            onResend = { PhoneVerifier.send(phone) },
            onVerified = createAccount,
        ).show()
        if (!shown) createAccount()
    }

    private companion object {
        const val ADMIN_HOLD_MS = 7000L
    }
}
