package com.moknight.nexoraedu

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.UUID

data class Student(
    var name: String,
    var phone: String,
    var email: String,
    var pw: String,
    var grade: String,
    var code: String = "",
    var active: Boolean = false
)

/** Local data store (SharedPreferences + JSON). Passwords are stored as SHA-256 hashes. */
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("nexora_data", Context.MODE_PRIVATE)

    fun hash(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    // ---- classes ----
    private val defaultGrades = listOf("الصف الأول الثانوي", "الصف الثاني الثانوي", "الصف الثالث الثانوي")

    /** The three fixed classes a student can pick when signing up (stored values; the labels shown come from strings). */
    val FIXED_GRADES: List<String> get() = defaultGrades

    fun grades(c: Context): MutableList<String> {
        val s = sp(c).getString("grades", null) ?: return defaultGrades.toMutableList()
        val a = JSONArray(s)
        return MutableList(a.length()) { a.getString(it) }
    }

    fun saveGrades(c: Context, g: List<String>) {
        sp(c).edit().putString("grades", JSONArray(g).toString()).apply()
    }

    // ---- students ----
    fun students(c: Context): MutableList<Student> {
        val s = sp(c).getString("students", null) ?: return mutableListOf()
        val a = JSONArray(s)
        return MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Student(
                o.optString("n"), o.optString("p"), o.optString("e"), o.optString("pw"),
                o.optString("g"), o.optString("c"), o.optBoolean("act")
            )
        }
    }

    fun saveStudents(c: Context, list: List<Student>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("n", it.name).put("p", it.phone).put("e", it.email)
                    .put("pw", it.pw).put("g", it.grade).put("c", it.code).put("act", it.active)
            )
        }
        sp(c).edit().putString("students", a.toString()).apply()
    }

    fun findStudent(c: Context, email: String): Student? = students(c).firstOrNull { it.email == email }

    // ---- teacher account (email, password hash) ----
    fun teacher(c: Context): Pair<String, String>? {
        val e = sp(c).getString("t_email", null) ?: return null
        val p = sp(c).getString("t_pw", null) ?: return null
        return e to p
    }

    fun setTeacher(c: Context, email: String, password: String, phone: String = "", name: String = "") {
        val e = sp(c).edit().putString("t_email", email).putString("t_pw", hash(password))
        if (phone.isNotEmpty()) e.putString("t_phone", phone) else e.remove("t_phone")
        if (name.isNotEmpty()) e.putString("t_name", name) else e.remove("t_name")
        e.apply()
    }

    /** The teacher's full name (entered at sign-up); empty when the account has none. */
    fun teacherName(c: Context): String = sp(c).getString("t_name", "")?.trim() ?: ""

    fun deleteTeacher(c: Context) {
        sp(c).edit().remove("t_email").remove("t_pw").remove("t_phone").remove("t_name").apply()
    }

    // ---- admin account (own keys, separate from the teacher) ----
    fun admin(c: Context): Pair<String, String>? {
        val e = sp(c).getString("a_email", null) ?: return null
        val p = sp(c).getString("a_pw", null) ?: return null
        return e to p
    }

    fun setAdmin(c: Context, email: String, password: String) {
        sp(c).edit().putString("a_email", email).putString("a_pw", hash(password)).apply()
    }

    // ---- session ----
    fun session(c: Context): Pair<String, String>? {
        val r = sp(c).getString("s_role", null) ?: return null
        val e = sp(c).getString("s_email", null) ?: return null
        return r to e
    }

    fun setSession(c: Context, role: String, email: String) {
        sp(c).edit().putString("s_role", role).putString("s_email", email).apply()
    }

    fun clearSession(c: Context) {
        sp(c).edit().remove("s_role").remove("s_email").apply()
    }

    fun setStudentActive(c: Context, email: String, on: Boolean) {
        saveStudents(c, students(c).onEach { if (it.email == email) it.active = on })
    }

    /** Makes a new 10-character code (no look-alikes: no O/0, I/1) that no other student has, saves it and returns it. */
    fun newStudentCode(c: Context, email: String): String {
        val all = students(c)
        val used = all.map { it.code }.toSet()
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        var code: String
        do {
            code = String(CharArray(10) { chars[java.security.SecureRandom().nextInt(chars.length)] })
        } while (code in used)
        all.forEach { if (it.email == email) it.code = code }
        saveStudents(c, all)
        return code
    }

    fun deleteStudent(c: Context, email: String) {
        saveStudents(c, students(c).filter { it.email != email })
        saveResults(c, results(c).filter { it.email != email })
        val subs = submissions(c)
        subs.filter { it.email == email && it.photo.isNotEmpty() }.forEach { photoFile(c, it.photo).delete() }
        saveSubmissions(c, subs.filter { it.email != email })
        avatarFile(c, email).delete()
        draftPhoto(c, email).delete()
        sp(c).edit().remove("fav:$email").remove("notes:$email").remove("hist:$email").apply()
    }

    // ---- small JSON helpers ----
    fun newId(): String = UUID.randomUUID().toString().replace("-", "").take(12)

    private fun <T> load(c: Context, key: String, f: (JSONObject) -> T): MutableList<T> {
        val s = sp(c).getString(key, null) ?: return mutableListOf()
        val a = JSONArray(s)
        return MutableList(a.length()) { f(a.getJSONObject(it)) }
    }

    private fun <T> save(c: Context, key: String, l: List<T>, f: (T) -> JSONObject) {
        val a = JSONArray()
        l.forEach { a.put(f(it)) }
        sp(c).edit().putString(key, a.toString()).apply()
    }

    private fun strings(a: JSONArray?): List<String> = if (a == null) emptyList() else List(a.length()) { a.getString(it) }

    // ---- chapters ----
    fun chapters(c: Context) = load(c, "chapters") { Chapter(it.optString("i"), it.optString("t"), it.optInt("pr", 0)) }
    fun saveChapters(c: Context, l: List<Chapter>) = save(c, "chapters", l) { JSONObject().put("i", it.id).put("t", it.title).put("pr", it.price) }

    // ---- lessons / videos ----
    fun lessons(c: Context) = load(c, "lessons") {
        Lesson(it.optString("i"), it.optString("c"), it.optString("t"), it.optString("y"), it.optLong("a"), it.optBoolean("p", true),
            it.optString("s", "yt"), it.optInt("pr", 0), it.optString("th"))
    }

    fun saveLessons(c: Context, l: List<Lesson>) = save(c, "lessons", l) {
        JSONObject().put("i", it.id).put("c", it.chapterId).put("t", it.title).put("y", it.yt).put("a", it.at).put("p", it.published)
            .put("s", it.src).put("pr", it.price).put("th", it.thumb)
    }

    /** Uploaded video file (src == "up"). Kept until the teacher deletes the video. No expiry. */
    fun videoFile(c: Context, id: String) = File(File(c.filesDir, "videos").apply { mkdirs() }, "$id.mp4")

    /** Whether the lesson has something to play (YouTube id or an uploaded file). */
    fun hasVideo(c: Context, l: Lesson) = if (l.src == "up") videoFile(c, l.id).exists() else l.yt.isNotEmpty()

    // ---- grants (who may see paid content). Written by the teacher (cash / free) or by the payment gateway (online). ----
    fun grants(c: Context) = load(c, "grants") { Grant(it.optString("t"), it.optString("e"), it.optString("m"), it.optString("b"), it.optLong("a")) }
    fun saveGrants(c: Context, l: List<Grant>) =
        save(c, "grants", l) { JSONObject().put("t", it.target).put("e", it.email).put("m", it.mode).put("b", it.by).put("a", it.at) }

    /** Opens [target] for [email]. Every call is logged (who opened it, for whom, when). */
    fun grant(c: Context, target: String, email: String, mode: String, by: String) {
        if (grants(c).any { it.target == target && it.email == email }) return
        val g = Grant(target, email, mode, by)
        saveGrants(c, grants(c) + g)
        save(c, "glog", glog(c) + g) { JSONObject().put("t", it.target).put("e", it.email).put("m", it.mode).put("b", it.by).put("a", it.at) } // never removed
    }

    /** Permanent log of every opening (who opened it, for whom, when). Revoking a grant does not delete its log line. */
    fun glog(c: Context) = load(c, "glog") { Grant(it.optString("t"), it.optString("e"), it.optString("m"), it.optString("b"), it.optLong("a")) }
    fun revoke(c: Context, target: String, email: String) =
        saveGrants(c, grants(c).filterNot { it.target == target && it.email == email })

    fun lesson(c: Context, id: String): Lesson? = lessons(c).firstOrNull { it.id == id }

    /** Only what students may see: hidden lessons are left out. */
    fun publishedLessons(c: Context) = lessons(c).filter { it.published }
    fun publishedLesson(c: Context, id: String): Lesson? = lesson(c, id)?.takeIf { it.published }

    // ---- announcements (teacher -> students) ----
    fun announcements(c: Context) = load(c, "ann") { Announcement(it.optString("i"), it.optString("t"), it.optString("x"), it.optLong("a")) }
    fun saveAnnouncements(c: Context, l: List<Announcement>) =
        save(c, "ann", l) { JSONObject().put("i", it.id).put("t", it.title).put("x", it.text).put("a", it.at) }

    fun deleteChapter(c: Context, id: String) {
        saveChapters(c, chapters(c).filter { it.id != id })
        lessons(c).filter { it.chapterId == id }.forEach { videoFile(c, it.id).delete() }
        saveLessons(c, lessons(c).filter { it.chapterId != id })
        saveGrants(c, grants(c).filterNot { it.target == "c:$id" })
    }

    // ---- books and files (PDF) ----
    fun docs(c: Context) = load(c, "docs") { Doc(it.optString("i"), it.optString("t"), it.optString("k"), it.optLong("a")) }
    fun saveDocs(c: Context, l: List<Doc>) = save(c, "docs", l) { JSONObject().put("i", it.id).put("t", it.title).put("k", it.kind).put("a", it.at) }
    fun doc(c: Context, id: String): Doc? = docs(c).firstOrNull { it.id == id }

    fun deleteDoc(c: Context, id: String) {
        saveDocs(c, docs(c).filter { it.id != id })
        docFile(c, id).delete()
    }

    fun docFile(c: Context, id: String) = File(File(c.filesDir, "docs").apply { mkdirs() }, "$id.pdf")
    fun photoFile(c: Context, name: String) = File(File(c.filesDir, "hw").apply { mkdirs() }, name)

    /** The homework photo a student picked but has not sent yet (one file per student, overwritten; it becomes the real photo when the answer is sent). */
    fun draftPhoto(c: Context, email: String) = photoFile(c, "draft_" + email.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".jpg")

    /** The student's profile photo: filesDir/avatars/<email with every char outside A-Z a-z 0-9 . _ - replaced by _>.jpg (may not exist). */
    fun avatarFile(c: Context, email: String) =
        File(File(c.filesDir, "avatars").apply { mkdirs() }, email.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".jpg")

    fun copyUri(c: Context, uri: Uri, dst: File): Boolean = try {
        c.contentResolver.openInputStream(uri)!!.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        true
    } catch (e: Exception) {
        dst.delete(); false
    }

    /** Saves a picked photo as a downscaled JPEG ([max] px, 1280 by default) with its EXIF rotation applied. */
    fun savePhoto(c: Context, uri: Uri, dst: File, max: Int = 1280): Boolean = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2000) sample *= 2
        val bmp = c.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }!!
        val deg = try {
            c.contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) { 0f }
        val k = minOf(1f, max.toFloat() / maxOf(bmp.width, bmp.height))
        val m = Matrix().apply { postScale(k, k); postRotate(deg) }
        val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        dst.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        true
    } catch (e: Exception) {
        dst.delete(); false
    }

    // ---- question bank ----
    fun questions(c: Context) = load(c, "questions") {
        Question(it.optString("i"), it.optString("t"), it.optString("c"), strings(it.optJSONArray("o")), it.optInt("a"))
    }

    fun saveQuestions(c: Context, l: List<Question>) = save(c, "questions", l) {
        JSONObject().put("i", it.id).put("t", it.text).put("c", it.chapter).put("o", JSONArray(it.options)).put("a", it.answer)
    }

    fun question(c: Context, id: String): Question? = questions(c).firstOrNull { it.id == id }

    /** Deletes a question and takes it out of every exam that used it. */
    fun deleteQuestion(c: Context, id: String) {
        saveQuestions(c, questions(c).filter { it.id != id })
        saveExams(c, exams(c).onEach { e -> e.qids = e.qids.filter { it != id } })
    }

    // ---- exams and results ----
    fun exams(c: Context) = load(c, "exams") {
        Exam(it.optString("i"), it.optString("t"), it.optBoolean("o"), strings(it.optJSONArray("q")), it.optLong("a"))
    }

    fun saveExams(c: Context, l: List<Exam>) = save(c, "exams", l) {
        JSONObject().put("i", it.id).put("t", it.title).put("o", it.official).put("q", JSONArray(it.qids)).put("a", it.at)
    }

    fun exam(c: Context, id: String): Exam? = exams(c).firstOrNull { it.id == id }

    fun results(c: Context) = load(c, "results") {
        Result(it.optString("x"), it.optString("e"), it.optInt("s"), it.optInt("c"), it.optInt("n"), it.optLong("a"))
    }

    fun saveResults(c: Context, l: List<Result>) = save(c, "results", l) {
        JSONObject().put("x", it.examId).put("e", it.email).put("s", it.score).put("c", it.correct).put("n", it.total).put("a", it.at)
    }

    fun addResult(c: Context, r: Result) = saveResults(c, results(c) + r)

    /** The latest result of a student in an exam, or null if never taken. */
    fun lastResult(c: Context, email: String, examId: String): Result? =
        results(c).filter { it.email == email && it.examId == examId }.maxByOrNull { it.at }

    fun deleteExam(c: Context, id: String) {
        saveExams(c, exams(c).filter { it.id != id })
        saveResults(c, results(c).filter { it.examId != id })
    }

    /** Average of a student's latest score in every official exam (null if none taken). */
    fun officialAverage(c: Context, email: String): Int? {
        val official = exams(c).filter { it.official }
        val scores = official.mapNotNull { lastResult(c, email, it.id)?.score }
        return if (scores.isEmpty()) null else scores.sum() / scores.size
    }

    // ---- homework and submissions ----
    fun homework(c: Context) = load(c, "homework") { Homework(it.optString("i"), it.optString("t"), it.optString("n"), it.optLong("a")) }
    fun saveHomework(c: Context, l: List<Homework>) = save(c, "homework", l) { JSONObject().put("i", it.id).put("t", it.title).put("n", it.note).put("a", it.at) }
    fun homeworkById(c: Context, id: String): Homework? = homework(c).firstOrNull { it.id == id }

    fun submissions(c: Context) = load(c, "subs") {
        Submission(it.optString("h"), it.optString("e"), it.optString("t"), it.optString("p"), it.optInt("g", -1), it.optString("n"), it.optLong("a"))
    }

    fun saveSubmissions(c: Context, l: List<Submission>) = save(c, "subs", l) {
        JSONObject().put("h", it.hwId).put("e", it.email).put("t", it.text).put("p", it.photo).put("g", it.grade).put("n", it.note).put("a", it.at)
    }

    fun submission(c: Context, hwId: String, email: String): Submission? =
        submissions(c).firstOrNull { it.hwId == hwId && it.email == email }

    fun putSubmission(c: Context, s: Submission) {
        saveSubmissions(c, submissions(c).filter { !(it.hwId == s.hwId && it.email == s.email) } + s)
    }

    fun deleteHomework(c: Context, id: String) {
        val subs = submissions(c)
        subs.filter { it.hwId == id && it.photo.isNotEmpty() }.forEach { photoFile(c, it.photo).delete() }
        saveSubmissions(c, subs.filter { it.hwId != id })
        saveHomework(c, homework(c).filter { it.id != id })
    }

    /** Average of every student's official-exam average (null while nobody has taken an official exam). */
    fun teacherOfficialAverage(c: Context): Int? {
        val v = students(c).mapNotNull { officialAverage(c, it.email) }
        return if (v.isEmpty()) null else v.sum() / v.size
    }

    fun ungraded(c: Context): Int = submissions(c).count { it.grade < 0 }

    // ---- per-student: favorites, notes, watch history ----
    val collections = listOf("fav", "later", "imp")

    fun favList(c: Context, email: String, coll: String): MutableList<String> {
        val s = sp(c).getString("fav:$email", null) ?: return mutableListOf()
        return strings(JSONObject(s).optJSONArray(coll)).toMutableList()
    }

    fun isIn(c: Context, email: String, coll: String, key: String) = favList(c, email, coll).contains(key)

    fun toggleIn(c: Context, email: String, coll: String, key: String) {
        val o = JSONObject(sp(c).getString("fav:$email", null) ?: "{}")
        val l = favList(c, email, coll)
        if (!l.remove(key)) l.add(0, key)
        o.put(coll, JSONArray(l))
        sp(c).edit().putString("fav:$email", o.toString()).apply()
    }

    fun notes(c: Context, email: String): MutableList<Note> = load(c, "notes:$email") { Note(it.optString("t"), it.optString("d")) }
    fun saveNotes(c: Context, email: String, l: List<Note>) = save(c, "notes:$email", l) { JSONObject().put("t", it.text).put("d", it.date) }

    /** Lesson ids, newest first, no duplicates. */
    fun history(c: Context, email: String): List<String> = strings(JSONArray(sp(c).getString("hist:$email", null) ?: "[]"))

    fun addHistory(c: Context, email: String, lessonId: String) {
        val l = (listOf(lessonId) + history(c, email).filter { it != lessonId }).take(200)
        sp(c).edit().putString("hist:$email", JSONArray(l).toString()).apply()
    }

    fun clearHistory(c: Context, email: String) = sp(c).edit().remove("hist:$email").apply()

    /** (watched lessons, all lessons) for a student. */
    fun progress(c: Context, email: String): Pair<Int, Int> {
        val all = publishedLessons(c)
        val seen = history(c, email).toSet()
        return all.count { it.id in seen } to all.size
    }

    fun percent(p: Pair<Int, Int>): Int = if (p.second == 0) 0 else p.first * 100 / p.second
}
