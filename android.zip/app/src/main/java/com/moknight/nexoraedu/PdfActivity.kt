package com.moknight.nexoraedu

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.View
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Simple in-app PDF reader (one page at a time) built on the framework's PdfRenderer. */
class PdfActivity : BaseActivity() {
    override val aurora: Boolean get() = false

    private var pfd: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var page = 0
    private lateinit var image: ImageView
    private lateinit var label: TextView
    private lateinit var scroll: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pdf)
        findViewById<TextView>(R.id.pTitle).text = intent.getStringExtra("title") ?: ""
        findViewById<View>(R.id.pBack).setOnClickListener { finish() }
        image = findViewById(R.id.pImage)
        label = findViewById(R.id.pPage)
        scroll = findViewById(R.id.pScroll)
        val id = intent.getStringExtra("id") ?: ""
        try {
            val p = ParcelFileDescriptor.open(Store.docFile(this, id), ParcelFileDescriptor.MODE_READ_ONLY)
            pfd = p
            renderer = PdfRenderer(p)
        } catch (e: Exception) {
            Sfx.play(Sfx.S.ERROR)
            Toast.makeText(this, R.string.err_no_file, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        // RTL screen: "previous" sits on the right, but page numbers still go 1 -> N.
        findViewById<View>(R.id.pPrev).setOnClickListener { showPage(page - 1) }
        findViewById<View>(R.id.pNext).setOnClickListener { showPage(page + 1) }
        showPage(savedInstanceState?.getInt("page") ?: 0)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("page", page)
    }

    private fun showPage(i: Int) {
        val r = renderer ?: return
        if (r.pageCount == 0) return
        page = i.coerceIn(0, r.pageCount - 1)
        val p = r.openPage(page)
        try {
            val w = resources.displayMetrics.widthPixels
            val h = (w.toLong() * p.height / p.width).toInt()
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            image.setImageBitmap(bmp)
        } finally {
            p.close()
        }
        label.text = "${page + 1} / ${r.pageCount}"
        scroll.scrollTo(0, 0)
    }

    override fun onDestroy() {
        try { renderer?.close(); pfd?.close() } catch (e: Exception) { /* already closed */ }
        super.onDestroy()
    }
}
