package com.moknight.nexoraedu

import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView

class SplashActivity : BaseActivity() {
    private var routed = false
    private var started = false
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var particles: SplashView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        val space = findViewById<View>(R.id.logoSpace)
        val brand = findViewById<TextView>(R.id.brand)
        val tag = findViewById<TextView>(R.id.tag)

        // the particle layer sits behind the texts, over the whole screen
        particles = SplashView(this)
        val root = (findViewById<ViewGroup>(android.R.id.content).getChildAt(0) as ViewGroup)
        root.addView(particles, 1, FrameLayout.LayoutParams(MATCH, MATCH)) // 0 = glowing background

        space.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
            if (!started && v.width > 0 && particles.width > 0) {
                started = true
                Sfx.play(Sfx.S.SPLASH)
                val a = IntArray(2)
                val b = IntArray(2)
                v.getLocationOnScreen(a)
                particles.getLocationOnScreen(b)
                particles.begin(
                    a[0] - b[0] + v.width / 2f, a[1] - b[1] + v.height / 2f, v.width.toFloat(),
                    accent(), resolve(R.attr.p2),
                )
            }
        }

        // brand name appears while the icon is finishing
        brand.translationY = dp(14).toFloat()
        // (times are in the real 3.3 s, the particle timeline runs 1.3x faster than the numbers in SplashView)
        val k = SplashView.TOTAL / SplashView.TIMELINE
        brand.animate().setStartDelay((2950 * k).toLong()).setDuration(450).alpha(1f).translationY(0f).start()
        tag.animate().setStartDelay((3300 * k).toLong()).setDuration(450).alpha(1f).start()

        findViewById<View>(android.R.id.content).setOnClickListener { route() }
        handler.postDelayed({ route() }, SplashView.TOTAL + 350)
    }

    private fun resolve(attr: Int): Int {
        val v = TypedValue()
        theme.resolveAttribute(attr, v, true)
        return v.data
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::particles.isInitialized) particles.stop()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun route() {
        if (routed || isFinishing) return
        routed = true
        val s = Store.session(this)
        val target = when {
            s?.first == "admin" && Store.admin(this) != null -> AdminActivity::class.java
            s?.first == "teacher" && Store.teacher(this) != null -> TeacherActivity::class.java
            s?.first == "student" && Store.findStudent(this, s.second) != null -> StudentActivity::class.java
            else -> LoginActivity::class.java
        }
        startActivity(Intent(this, target))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }
}
