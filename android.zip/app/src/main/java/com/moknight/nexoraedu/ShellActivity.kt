package com.moknight.nexoraedu

import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.graphics.Color
import android.graphics.Typeface
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class Tab(val label: Int, val icon: Int, val build: () -> Unit)

/** Common screen frame (header, scrolling body, bottom navigation, settings sheet) for student and teacher. */
abstract class ShellActivity : BaseActivity() {
    protected lateinit var body: LinearLayout
    private lateinit var nav: LinearLayout
    private lateinit var navBox: View
    private lateinit var navInd: View
    private lateinit var scroll: ScrollView
    private var tabs: List<Tab> = emptyList()
    private var current = 0
    private var prevTab = -1
    private var navReady = false
    private var topInset = 0
    private var bottomInset = 0
    private var settingsView: View? = null
    /** True while the screen is rebuilt after a language / theme / colour change: nothing slides in again. */
    private var quiet = false
    private var savedScroll = 0

    /** What is on screen right now (a tab, or a sub-screen opened with [show]) and the screens behind it. */
    private var cur: () -> Unit = {}
    private val backStack = ArrayList<() -> Unit>()
    private var pickCb: ((Uri) -> Unit)? = null

    protected abstract fun hello(): Int
    protected abstract fun displayName(): String
    /** Email whose profile photo is shown in the header (students only); null = just the first letter. */
    protected open fun avatarEmail(): String? = null
    protected abstract fun buildTabs(): List<Tab>
    /** A profile screen opened from the header (for sides whose profile is not a tab); null = none. */
    protected open fun profileScreen(): (() -> Unit)? = null
    /** Called before the screen is built; return false to abort (e.g. the account no longer exists). */
    protected open fun ready(): Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!ready()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        quiet = savedInstanceState != null
        savedScroll = savedInstanceState?.getInt("scrollY") ?: 0
        setContentView(R.layout.activity_shell)
        body = findViewById(R.id.body)
        nav = findViewById(R.id.nav)
        navBox = findViewById(R.id.navBox)
        navInd = findViewById(R.id.navInd)
        scroll = findViewById(R.id.scroll)
        setupInsets()
        val name = displayName()
        findViewById<TextView>(R.id.avatar).text = name.firstOrNull()?.toString()?.uppercase() ?: "?"
        refreshAvatar()
        findViewById<TextView>(R.id.hello).setText(hello())
        findViewById<TextView>(R.id.who).text = name
        findViewById<View>(R.id.btnSettings).setOnClickListener { openSettings() }
        findViewById<View>(R.id.profileBox).setOnClickListener {
            profileScreen()?.let { p -> if (settingsView == null) show(p) }
        }

        navInd.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(accent(), accent2())).apply {
            cornerRadius = dp(3).toFloat()
        }
        tabs = buildTabs()
        tabs.forEachIndexed { i, t ->
            val v = layoutInflater.inflate(R.layout.item_nav, nav, false)
            v.findViewById<ImageView>(R.id.navIcon).setImageResource(t.icon)
            v.findViewById<TextView>(R.id.navLabel).setText(t.label)
            v.setOnClickListener { select(i) }
            nav.addView(v)
        }
        navBox.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> moveIndicator(current, false) }
        select(savedInstanceState?.getInt("tab") ?: 0)
        walkPress(nav)
        walkPress(findViewById(R.id.btnSettings))
        // the avatar glows in the accent colour
        findViewById<View>(R.id.avatar).let { a ->
            glowView(a, accent(), 10f)
            glowView(findViewById(R.id.avatarImg), accent(), 11f) // above the letter, so the photo stays on top
            (a.parent?.parent as? ViewGroup)?.clipChildren = false
        }
        if (!quiet) {
            navBox.alpha = 0f
            navBox.translationY = dp(30).toFloat()
            navBox.animate().setStartDelay(150).alpha(1f).translationY(0f).setDuration(420).start()
        }
        if (savedInstanceState?.getBoolean("settings") == true) openSettings(false)
        if (quiet) scroll.post { scroll.scrollTo(0, savedScroll) }
        quiet = false
        // after a language / theme / colour change the old screen fades into the new one (no replayed animations)
        snap?.let { bmp ->
            snap = null
            val host = window.decorView as ViewGroup
            val iv = ImageView(this).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.FIT_XY }
            host.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
            iv.animate().setStartDelay(40).setDuration(420).alpha(0f).withEndAction { host.removeView(iv) }.start()
        }
    }

    /**
     * Applies a language / theme / colour change. The current screen is kept as a picture, the activity is rebuilt
     * with no transition, and the picture fades away: only the change itself is animated, nothing slides in again.
     */
    @Suppress("DEPRECATION")
    private fun switchConfig(apply: () -> Unit) {
        try {
            val d = window.decorView
            if (d.width > 0 && d.height > 0) {
                val bmp = Bitmap.createBitmap(d.width, d.height, Bitmap.Config.ARGB_8888)
                d.draw(Canvas(bmp))
                snap = bmp
            }
        } catch (e: Throwable) {
            snap = null
        }
        apply()
        recreate()
        overridePendingTransition(0, 0)
    }

    /** Content goes under the status / navigation bars (both transparent); the insets are applied by hand. */
    @Suppress("DEPRECATION")
    private fun setupInsets() {
        val d = window.decorView
        d.systemUiVisibility = d.systemUiVisibility or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        val root = findViewById<View>(R.id.shellRoot)
        root.setOnApplyWindowInsetsListener { _, ins ->
            topInset = ins.systemWindowInsetTop
            bottomInset = ins.systemWindowInsetBottom
            applyInsets()
            ins
        }
        root.requestApplyInsets()
    }

    private fun applyInsets() {
        val h = findViewById<View>(R.id.header)
        h.setPadding(h.paddingLeft, dp(8) + topInset, h.paddingRight, h.paddingBottom)
        (navBox.layoutParams as FrameLayout.LayoutParams).bottomMargin = dp(16) + bottomInset
        navBox.requestLayout()
        // room under the floating capsule: 68 dp bar + 16 dp margin + breathing room, so nothing is ever covered
        body.setPadding(body.paddingLeft, body.paddingTop, body.paddingRight, dp(120) + bottomInset)
        settingsView?.let { v ->
            val sh = v.findViewById<View>(R.id.sHeader)
            sh.setPadding(sh.paddingLeft, dp(16) + topInset, sh.paddingRight, sh.paddingBottom)
            val sb = v.findViewById<View>(R.id.sBody)
            sb.setPadding(sb.paddingLeft, sb.paddingTop, sb.paddingRight, dp(40) + bottomInset)
        }
    }

    private var firstResume = true

    /** Coming back from a video or PDF: rebuild so "watched" marks and counters are up to date. */
    override fun onResume() {
        super.onResume()
        AdminControl.guard(this)   // release 54: a removed teacher / admin is signed out; the main admin gets the alerts
        if (firstResume) { firstResume = false; return }
        if (::body.isInitialized && tabs.isNotEmpty()) render(true)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", current)
        outState.putBoolean("settings", settingsView != null)
        outState.putInt("scrollY", if (::scroll.isInitialized) scroll.scrollY else 0)
    }

    /** Shows the profile photo in the header when the student has one, otherwise the first letter. */
    protected fun refreshAvatar() {
        val img = findViewById<ImageView>(R.id.avatarImg)
        val bmp = avatarEmail()?.let { decodeScaled(Store.avatarFile(this, it), 256) }
        if (bmp != null) { img.setImageBitmap(bmp); img.visibility = View.VISIBLE } else img.visibility = View.GONE
    }

    protected fun select(i: Int) {
        val moved = navReady && i != current
        prevTab = current
        current = i
        backStack.clear()
        for (k in 0 until nav.childCount) {
            val v = nav.getChildAt(k)
            val on = k == i
            v.isSelected = on
            if (on && moved) { iconHop(v.findViewById(R.id.navIcon)); Sfx.play(Sfx.S.TAB) }
        }
        moveIndicator(i, navReady)
        navReady = true
        cur = tabs[i].build
        render(false)
    }

    /** The little bar under the chosen tab slides to the new one and settles with a soft bounce. */
    private fun moveIndicator(i: Int, animate: Boolean) {
        val v = nav.getChildAt(i) ?: return
        if (v.width == 0 || navInd.width == 0) {
            navBox.post { moveIndicator(i, false) }
            return
        }
        val tx = (nav.left + v.left + (v.width - navInd.width) / 2f) - navInd.left
        navInd.animate().cancel()
        if (animate) {
            navInd.animate().translationX(tx).setStartDelay(0).setInterpolator(OvershootInterpolator(2.6f)).setDuration(460).start()
        } else {
            navInd.translationX = tx
        }
    }

    private fun render(keepScroll: Boolean) {
        val y = if (keepScroll) scroll.scrollY else 0
        body.removeAllViews()
        cur()
        walkPress(body)
        if (!keepScroll && !quiet) staggerIn(body, resources.displayMetrics.density)
        scroll.post { scroll.scrollTo(0, y) }
    }

    /** Opens a sub-screen on top of the current one (hardware back returns). */
    protected fun show(builder: () -> Unit) {
        backStack.add(cur)
        cur = builder
        render(false)
    }

    /** Swaps the current sub-screen without adding to the back stack. */
    protected fun replace(builder: () -> Unit) {
        cur = builder
        render(false)
    }

    /** Rebuilds the current screen, keeping the scroll position. */
    protected fun refresh() = render(true)

    protected fun back() {
        if (backStack.isEmpty()) return
        cur = backStack.removeAt(backStack.size - 1)
        render(false)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            settingsView != null -> closeSettings()
            backStack.isNotEmpty() -> back()
            else -> super.onBackPressed()
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            val u = data?.data
            if (u != null) pickCb?.invoke(u)
        }
        if (requestCode == REQ_PICK) pickCb = null
    }

    /** Opens the system file picker for [mime] and calls [cb] with the chosen file. */
    @Suppress("DEPRECATION")
    protected fun pick(mime: String, cb: (Uri) -> Unit) {
        pickCb = cb
        val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = mime; addCategory(Intent.CATEGORY_OPENABLE) }
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: ActivityNotFoundException) {
            pickCb = null
            toast(R.string.err_no_picker)
        }
    }

    protected fun toast(res: Int) { Sfx.forToast(this, res); Toast.makeText(this, res, Toast.LENGTH_SHORT).show() }

    protected fun openVideo(l: Lesson, email: String? = null) {
        if (!Store.hasVideo(this, l)) return toast(R.string.err_no_video)
        if (email != null && !Access.canView(this, email, l)) return paywall(l, email) // students only; teacher preview passes null
        if (email != null) Store.addHistory(this, email, l.id)
        val i = if (l.src == "up") Intent(this, UploadVideoActivity::class.java).putExtra("id", l.id)
        else Intent(this, VideoActivity::class.java).putExtra("id", l.yt)
        startActivity(i.putExtra("title", l.title))
    }

    /** Locked lesson: shows what it costs. Online payment is a skeleton (see Payments in Access.kt). */
    protected fun paywall(l: Lesson, email: String) {
        val cp = Access.coursePrice(this, l)
        Sfx.play(Sfx.S.LOCKED)
        sheet(getString(R.string.locked_title)) { c, d ->
            c.addView(label(getString(R.string.locked_sub), 14f, R.color.mut, top = 8))
            if (cp > 0) c.addView(primary(getString(R.string.pay_course, cp), 16) { d.dismiss(); pay("c:" + l.chapterId, cp, email) })
            if (l.price > 0) c.addView(primary(getString(R.string.pay_video, l.price), 10) { d.dismiss(); pay("l:" + l.id, l.price, email) })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    private fun pay(target: String, amount: Int, email: String) {
        if (!Payments.start(this, target, amount, email) { recreate() }) toast(R.string.pay_soon)
    }

    protected fun openDoc(d: Doc) {
        if (!Store.docFile(this, d.id).exists()) return toast(R.string.err_no_file)
        startActivity(Intent(this, PdfActivity::class.java).putExtra("id", d.id).putExtra("title", d.title))
    }

    // ---- building blocks for tab content ----
    protected fun card(small: String?, title: String, sub: String?): View {
        val v = layoutInflater.inflate(R.layout.item_card, body, false)
        if (!small.isNullOrEmpty()) v.findViewById<TextView>(R.id.cardSmall).apply { text = small; visibility = View.VISIBLE }
        v.findViewById<TextView>(R.id.cardTitle).text = title
        if (!sub.isNullOrEmpty()) v.findViewById<TextView>(R.id.cardSub).apply { text = sub; visibility = View.VISIBLE }
        return v
    }

    protected fun addCard(small: String?, title: String, sub: String?): View = card(small, title, sub).also { body.addView(it) }

    protected fun stat(num: Int, label: Int, parent: ViewGroup): View {
        val v = layoutInflater.inflate(R.layout.item_stat, parent, false)
        v.findViewById<TextView>(R.id.statNum).text = num.toString()
        v.findViewById<TextView>(R.id.statLabel).setText(label)
        return v
    }

    protected fun addStats(a: Pair<Int, Int>, b: Pair<Int, Int>) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(stat(a.first, a.second, row))
        row.addView(stat(b.first, b.second, row))
        body.addView(row)
    }

    protected fun addEmpty(icon: Int, title: Int, sub: Int) {
        val v = layoutInflater.inflate(R.layout.item_empty, body, false)
        v.findViewById<ImageView>(R.id.emptyIcon).setImageResource(icon)
        v.findViewById<TextView>(R.id.emptyTitle).setText(title)
        v.findViewById<TextView>(R.id.emptySub).setText(sub)
        body.addView(v)
    }

    /** A card row: icon, title, optional subtitle and trailing views (buttons). */
    protected fun itemRow(icon: Int, title: String, sub: String?, trailing: List<View> = emptyList(), onClick: (() -> Unit)? = null): View {
        val v = layoutInflater.inflate(R.layout.item_row, body, false)
        v.findViewById<ImageView>(R.id.rowIcon).setImageResource(icon)
        v.findViewById<TextView>(R.id.rowTitle).text = title
        if (!sub.isNullOrEmpty()) v.findViewById<TextView>(R.id.rowSub).apply { text = sub; visibility = View.VISIBLE }
        val end = v.findViewById<LinearLayout>(R.id.rowEnd)
        trailing.forEach { end.addView(it) }
        if (onClick != null) v.setOnClickListener { onClick() }
        return v
    }

    protected fun addRow(icon: Int, title: String, sub: String?, trailing: List<View> = emptyList(), onClick: (() -> Unit)? = null) =
        body.addView(itemRow(icon, title, sub, trailing, onClick))

    protected fun heading(s: CharSequence, parent: LinearLayout = body) =
        parent.addView(label(s, 18f, R.color.tx, true, top = 32).apply { (layoutParams as LinearLayout.LayoutParams).bottomMargin = dp(4) })

    /** A "‹ back" link plus a title, used at the top of sub-screens. */
    protected fun addTop(title: CharSequence, count: Int = -1) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutParams = lp(top = 8, bottom = 8) }
        row.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_chev)
            imageTintList = resources.getColorStateList(R.color.tx, theme)
            setBackgroundResource(R.drawable.chip_bg)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            contentDescription = getString(R.string.back)
            if (resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_LTR) rotation = 180f
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
            setOnClickListener { back() }
        })
        row.addView(label(title, 20f, R.color.tx, true).apply { layoutParams = lp(w = 0, weight = 1f, start = 12) })
        if (count >= 0) row.addView(badge(count.toString()))
        body.addView(row)
    }

    protected fun addNote(s: CharSequence) = body.addView(label(s, 12f, R.color.mut, top = 18))

    /** Cards with big number + label, two per row. */
    protected fun addStatGrid(items: List<Pair<Int, Int>>) {
        items.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { row.addView(stat(it.first, it.second, row)) }
            if (pair.size == 1) row.addView(View(this), lp(w = 0, weight = 1f))
            body.addView(row)
        }
    }

    /** Same as [addStatGrid] but the number is a ready text (for "85%" or "-"). */
    protected fun addStatGridText(items: List<Pair<String, Int>>) {
        items.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { p ->
                val v = layoutInflater.inflate(R.layout.item_stat, row, false)
                v.findViewById<TextView>(R.id.statNum).text = p.first
                v.findViewById<TextView>(R.id.statLabel).setText(p.second)
                row.addView(v)
            }
            if (pair.size == 1) row.addView(View(this), lp(w = 0, weight = 1f))
            body.addView(row)
        }
    }

    /** Rows of three tappable tiles. [count] (optional) shows a small number under the label. */
    protected class TileSpec(val icon: Int, val label: Int, val count: Int = -1, val onClick: () -> Unit)

    protected fun addTiles(items: List<TileSpec>, parent: LinearLayout = body) {
        items.chunked(3).forEach { chunk ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEach { t ->
                val v = layoutInflater.inflate(R.layout.item_tile, row, false)
                v.findViewById<ImageView>(R.id.tileIcon).setImageResource(t.icon)
                v.findViewById<TextView>(R.id.tileLabel).setText(t.label)
                if (t.count >= 0) v.findViewById<TextView>(R.id.tileCount).apply { text = t.count.toString(); visibility = View.VISIBLE }
                v.setOnClickListener { t.onClick() }
                row.addView(v)
            }
            repeat(3 - chunk.size) { row.addView(View(this), lp(w = 0, weight = 1f, start = 8, end = 8)) }
            parent.addView(row)
        }
    }

    /** Bottom sheet with a title; [build] fills the content. Returns the dialog so callers can dismiss it. */
    protected fun sheet(title: CharSequence, build: (LinearLayout, Dialog) -> Unit): Dialog {
        val d = Dialog(this, R.style.SheetDialog)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LOCALE
            setBackgroundResource(R.drawable.sheet_bg)
            setPadding(dp(20), dp(20), dp(20), dp(12))
        }
        root.addView(label(title, 18f, R.color.tx, true))
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER; addView(content) })
        build(content, d)
        walkPress(root)
        d.setContentView(root)
        d.window?.apply {
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        blurBehind(d)
        d.setOnDismissListener { Sfx.play(Sfx.S.CLOSE) }
        d.show()
        Sfx.play(Sfx.S.OPEN)
        sheetIn(root, resources.displayMetrics.density)
        return d
    }

    protected fun confirm(msg: CharSequence, yes: Int = R.string.delete, onYes: () -> Unit) {
        sheet(msg) { c, d ->
            c.addView(primary(getString(yes), 18) { d.dismiss(); if (yes == R.string.delete) Sfx.play(Sfx.S.DELETE); onYes() })
            c.addView(link(getString(R.string.cancel)) { d.dismiss() })
        }
    }

    // ---- settings: a full screen that slides in (language, appearance; the palette button opens the themes sheet) ----
    protected fun openSettings(animate: Boolean = true) {
        if (settingsView != null) return
        val root = findViewById<FrameLayout>(R.id.shellRoot)
        val v = layoutInflater.inflate(R.layout.screen_settings, root, false) as FrameLayout
        v.addView(AuroraView(this), 0, FrameLayout.LayoutParams(MATCH, MATCH))
        settingsView = v
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        applyInsets()

        val back = v.findViewById<ImageView>(R.id.sBack)
        if (resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_LTR) back.rotation = 180f
        back.setOnClickListener { closeSettings() }

        val ar = Prefs.ar(this)
        v.findViewById<SegControl>(R.id.segLang).apply {
            setItems(listOf("العربية", "English"), if (ar) 0 else 1)
            onSelect = { i ->
                val wantAr = i == 0
                if (wantAr != Prefs.ar(this@ShellActivity)) {
                    v.postDelayed({ switchConfig { Prefs.setAr(this@ShellActivity, wantAr) } }, 330) // let the indicator finish sliding first
                }
            }
        }
        val dark = Prefs.dark(this)
        v.findViewById<SegControl>(R.id.segTheme).apply {
            setItems(listOf(getString(R.string.dark), getString(R.string.light)), if (dark) 0 else 1)
            onSelect = { i ->
                val wantDark = i == 0
                if (wantDark != Prefs.dark(this@ShellActivity)) {
                    v.postDelayed({ switchConfig { Prefs.setDark(this@ShellActivity, wantDark) } }, 330)
                }
            }
        }

        // who is signed in
        v.findViewById<TextView>(R.id.sAvatar).text = displayName().firstOrNull()?.toString()?.uppercase() ?: "?"
        v.findViewById<TextView>(R.id.sName).text = displayName()
        v.findViewById<TextView>(R.id.sSub).text = findViewById<TextView>(R.id.hello).text

        // colours: a live preview + round swatches, right inside the screen (no sheet)
        colorGrid(v)

        v.findViewById<View>(R.id.btnLogout).setOnClickListener {
            Store.clearSession(this)
            ServerSync.signOut(this)
            startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            finish()
        }
        walkPress(v)
        if (animate) {
            v.alpha = 0f
            v.translationY = dp(44).toFloat()
            v.animate().setStartDelay(0).setInterpolator(DecelerateInterpolator(2.2f)).alpha(1f).translationY(0f).setDuration(340).start()
            staggerIn(v.findViewById(R.id.sBody), resources.displayMetrics.density)
        }
    }

    /** Colour picker inside the settings screen: a preview bar with the chosen name, then round gradient swatches (4 per row). Tapping one previews it at once, then applies it. */
    private fun colorGrid(v: View) {
        val preview = v.findViewById<View>(R.id.sPreview)
        val nameView = v.findViewById<TextView>(R.id.sThemeName)
        val box = v.findViewById<LinearLayout>(R.id.sSwatches)
        val chosen = Prefs.accent(this)
        fun show(a: Accents.Accent) {
            preview.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(color(a.c1), color(a.c2))).apply { cornerRadius = dp(18).toFloat() }
            nameView.text = getString(a.name)
        }
        show(Accents.find(chosen))
        val rings = HashMap<String, View>()
        val ticks = HashMap<String, View>()
        Accents.all.chunked(4).forEach { items ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = lp(top = 12) }
            items.forEach { a ->
                val cell = FrameLayout(this).apply { isClickable = true }
                val dot = View(this).apply {
                    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(color(a.c1), color(a.c2))).apply { shape = GradientDrawable.OVAL }
                }
                cell.addView(dot, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.CENTER))
                val ring = View(this).apply {
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(3), color(R.color.tx)) }
                    alpha = if (a.id == chosen) 1f else 0f
                }
                cell.addView(ring, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER))
                val tick = ImageView(this).apply { setImageResource(R.drawable.ic_check); setColorFilter(Color.WHITE); alpha = if (a.id == chosen) 1f else 0f }
                cell.addView(tick, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
                rings[a.id] = ring
                ticks[a.id] = tick
                cell.setOnClickListener {
                    if (a.id == Prefs.accent(this)) return@setOnClickListener
                    rings.forEach { (k, r) -> r.animate().alpha(if (k == a.id) 1f else 0f).setDuration(180).start() }
                    ticks.forEach { (k, t) -> t.animate().alpha(if (k == a.id) 1f else 0f).setDuration(180).start() }
                    ring.scaleX = 1.15f; ring.scaleY = 1.15f
                    ring.animate().scaleX(1f).scaleY(1f).setInterpolator(OvershootInterpolator(2.4f)).setDuration(260).start()
                    show(a)
                    preview.scaleX = 0.97f; preview.scaleY = 0.97f
                    preview.animate().scaleX(1f).scaleY(1f).setInterpolator(OvershootInterpolator(2f)).setDuration(260).start()
                    cell.postDelayed({ switchConfig { Prefs.setAccent(this, a.id) } }, 420)
                }
                row.addView(cell, LinearLayout.LayoutParams(0, dp(62), 1f))
            }
            repeat(4 - items.size) { row.addView(View(this), LinearLayout.LayoutParams(0, dp(62), 1f)) }
            box.addView(row)
        }
    }

    protected fun refreshHeader() {
        val name = displayName()
        findViewById<TextView>(R.id.avatar).text = name.firstOrNull()?.toString()?.uppercase() ?: "?"
        findViewById<TextView>(R.id.who).text = name
    }

    private fun closeSettings() {
        val v = settingsView ?: return
        settingsView = null
        v.animate().setStartDelay(0).setInterpolator(DecelerateInterpolator(1.6f)).alpha(0f).translationY(dp(44).toFloat()).setDuration(260)
            .withEndAction { (v.parent as? ViewGroup)?.removeView(v) }.start()
    }

    private companion object {
        const val REQ_PICK = 4711
        /** The picture of the old screen, handed to the rebuilt activity (see [switchConfig]). */
        var snap: Bitmap? = null
    }
}
