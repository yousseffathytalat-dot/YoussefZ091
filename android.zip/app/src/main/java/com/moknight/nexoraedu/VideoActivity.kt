package com.moknight.nexoraedu

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.util.Locale

/**
 * In-app lesson player. The video is a YouTube video drawn by the YouTube IFrame player inside a WebView
 * (its own controls are hidden), and everything the student touches is a native control on top of it:
 * play/pause, 10s skip (buttons + double-tap), seek bar, playback speed, full screen, and resume position.
 */
class VideoActivity : BaseActivity() {
    override val aurora: Boolean get() = false

    private var web: WebView? = null
    private val ui = Handler(Looper.getMainLooper())

    private var vid = ""
    private var startAt = 0
    private var cur = 0.0
    private var dur = 0.0
    private var state = -2
    private var rate = 1.0
    private var want = 1.0
    private var lastState = -2
    private var dragging = false
    private var full = false
    private var gotState = false
    private var lastSave = 0L
    private var openedAt = 0L
    private var portraitH = 0

    private lateinit var frame: View
    private lateinit var header: View
    private lateinit var panel: View
    private lateinit var controls: View
    private lateinit var loading: View
    private lateinit var errorView: View
    private lateinit var flash: TextView
    private lateinit var playBtn: ImageView
    private lateinit var fullBtn: ImageView
    private lateinit var seek: SeekBar
    private lateinit var curTxt: TextView
    private lateinit var totTxt: TextView
    private lateinit var rateTxt: TextView
    private val chips = ArrayList<TextView>()
    private val stepChips = ArrayList<TextView>()
    private val steps = intArrayOf(5, 10, 15, 30)
    private var step = 10
    private lateinit var settings: View
    private lateinit var rewTxt: TextView
    private lateinit var fwdTxt: TextView

    private val rates = doubleArrayOf(0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0)
    private val rateLabels = listOf("0.5x", "0.75x", "1x", "1.25x", "1.5x", "1.75x", "2x")

    private val tick = object : Runnable {
        override fun run() {
            poll()
            ui.postDelayed(this, 400)
        }
    }
    private val hideControls = Runnable { if (state == 1 && !dragging) controls.visibility = View.GONE }
    private val hideFlash = Runnable { flash.visibility = View.GONE }

    private fun sp(): SharedPreferences = getSharedPreferences("nexora_video", MODE_PRIVATE)

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        vid = (intent.getStringExtra("id") ?: "").filter {
            it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' || it == '_' || it == '-'
        }
        findViewById<TextView>(R.id.vTitle).text = intent.getStringExtra("title") ?: ""
        findViewById<View>(R.id.vBack).setOnClickListener { finish() }

        frame = findViewById(R.id.vFrame)
        header = findViewById(R.id.vHeader)
        panel = findViewById(R.id.vPanel)
        controls = findViewById(R.id.vControls)
        loading = findViewById(R.id.vLoading)
        errorView = findViewById(R.id.vError)
        flash = findViewById(R.id.vFlash)
        playBtn = findViewById(R.id.vPlay)
        fullBtn = findViewById(R.id.vFull)
        seek = findViewById(R.id.vSeek)
        curTxt = findViewById(R.id.vCur)
        totTxt = findViewById(R.id.vTot)
        rateTxt = findViewById(R.id.vRate)
        settings = findViewById(R.id.vSettings)
        rewTxt = findViewById(R.id.vRew)
        fwdTxt = findViewById(R.id.vFwd)
        val touch = findViewById<View>(R.id.vTouch)
        val resumeTxt = findViewById<TextView>(R.id.vResume)

        val dm = resources.displayMetrics
        portraitH = minOf(dm.widthPixels, dm.heightPixels) * 9 / 16

        // ---- resume + speed ----
        val saved = sp().getLong("pos_$vid", 0L)
        startAt = if (saved > 5) saved.toInt() else 0
        if (startAt > 0) {
            resumeTxt.text = getString(R.string.resume_info, fmt(startAt.toDouble()))
            resumeTxt.visibility = View.VISIBLE
        }
        want = sp().getFloat("rate", 1f).toDouble()
        var rateIdx = rates.indexOfFirst { Math.abs(it - want) < 0.01 }
        if (rateIdx < 0) { rateIdx = 2; want = 1.0 }
        rateTxt.text = rateLabels[rateIdx]

        val speedRow = findViewById<LinearLayout>(R.id.vSpeedRow)
        rateLabels.forEachIndexed { i, l ->
            val c = pchip(l, i == rateIdx) { setRate(i) }
            chips.add(c)
            speedRow.addView(c)
        }
        step = sp().getInt("step", 10)
        if (step !in steps) step = 10
        val stepRow = findViewById<LinearLayout>(R.id.vStepRow)
        steps.forEach { v ->
            val c = pchip(getString(R.string.sec_fmt, v), v == step) { setStep(v) }
            stepChips.add(c)
            stepRow.addView(c)
        }
        updateStepLabels()

        findViewById<View>(R.id.vGear).setOnClickListener { openSettings() }
        findViewById<View>(R.id.vSetClose).setOnClickListener { closeSettings() }
        settings.setOnClickListener { closeSettings() }
        errorView.setOnClickListener { retry() }

        findViewById<View>(R.id.vRestart).setOnClickListener {
            js("nx.seek(0);nx.play()")
            sp().edit().remove("pos_$vid").apply()
            resumeTxt.visibility = View.GONE
            closeSettings()
        }

        // ---- controls ----
        playBtn.setOnClickListener {
            Sfx.play(if (state == 1) Sfx.S.PAUSE else Sfx.S.PLAY)
            when (state) {
                1 -> js("nx.pause()")
                0 -> js("nx.seek(0);nx.play()")
                else -> js("nx.play()")
            }
            showControls()
        }
        rewTxt.setOnClickListener { skip(-step.toDouble()) }
        fwdTxt.setOnClickListener { skip(step.toDouble()) }
        fullBtn.setOnClickListener { setFull(!full, true) }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser && dur > 0) curTxt.text = fmt(dur * p / 1000.0)
            }
            override fun onStartTrackingTouch(s: SeekBar) {
                dragging = true
                ui.removeCallbacks(hideControls)
            }
            override fun onStopTrackingTouch(s: SeekBar) {
                dragging = false
                if (dur > 0) {
                    val t = dur * s.progress / 1000.0
                    cur = t
                    js("nx.seek($t)")
                }
                showControls()
            }
        })

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (controls.visibility == View.VISIBLE) controls.visibility = View.GONE else showControls()
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (e.x < touch.width / 2f) skip(-step.toDouble()) else skip(step.toDouble())
                return true
            }
        })
        touch.setOnTouchListener { _, ev -> gd.onTouchEvent(ev); true }

        // ---- web player ----
        val w = findViewById<WebView>(R.id.web)
        web = w
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.webChromeClient = WebChromeClient()
        w.setBackgroundColor(Color.BLACK)
        w.loadDataWithBaseURL("https://www.youtube-nocookie.com", page(vid, startAt), "text/html", "utf-8", null)

        openedAt = SystemClock.elapsedRealtime()
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) setFull(true, false)
        else setFull(false, false)
        showControls()
    }

    private fun page(id: String, start: Int): String =
        "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}" +
            "#pl{position:absolute;left:0;top:0;width:100%;height:100%;border:0}</style>" +
            "<script src='https://www.youtube.com/iframe_api'></script></head><body><div id='pl'></div><script>" +
            "var p=null,st=-2;" +
            "function onYouTubeIframeAPIReady(){p=new YT.Player('pl',{host:'https://www.youtube-nocookie.com'," +
            "width:'100%',height:'100%',videoId:'" + id + "',playerVars:{controls:0,rel:0,playsinline:1,modestbranding:1," +
            "fs:0,iv_load_policy:3,disablekb:1,autoplay:1,start:" + start + ",origin:'https://www.youtube-nocookie.com'}," +
            "events:{onStateChange:function(e){st=e.data},onError:function(e){st=-100-e.data}}});}" +
            "window.nx={s:function(){if(!p)return '';var t=0,d=0,r=1;" +
            "try{t=p.getCurrentTime();d=p.getDuration();r=p.getPlaybackRate()}catch(x){}return [t,d,st,r].join(',')}," +
            "play:function(){try{p.playVideo()}catch(x){}},pause:function(){try{p.pauseVideo()}catch(x){}}," +
            "seek:function(t){try{p.seekTo(t,true)}catch(x){}},rate:function(r){try{p.setPlaybackRate(r)}catch(x){}}};" +
            "</script></body></html>"

    private fun js(code: String) {
        web?.evaluateJavascript(code, null)
    }

    private fun poll() {
        val w = web ?: return
        w.evaluateJavascript("window.nx?window.nx.s():''") { r ->
            val p = (r ?: "").trim('"').split(",")
            if (p.size < 4) {
                if (!gotState && SystemClock.elapsedRealtime() - openedAt > 12000) showError()
                return@evaluateJavascript
            }
            cur = p[0].toDoubleOrNull() ?: 0.0
            dur = p[1].toDoubleOrNull() ?: 0.0
            state = p[2].toIntOrNull() ?: -2
            rate = p[3].toDoubleOrNull() ?: 1.0
            gotState = true
            render()
        }
    }

    private fun render() {
        if (state <= -100) { showError(); return }
        errorView.visibility = View.GONE
        val playing = state == 1
        playBtn.setImageResource(if (playing) R.drawable.ic_p_pause else R.drawable.ic_p_play)
        loading.visibility = if (state == 3 || state == -1) View.VISIBLE else View.GONE
        if (!dragging) {
            seek.progress = if (dur > 0) (cur / dur * 1000).toInt() else 0
            curTxt.text = fmt(cur)
        }
        totTxt.text = fmt(dur)
        if (playing && Math.abs(rate - want) > 0.01) js("nx.rate($want)")
        if (state != lastState) {
            if (state == 0) {
                sp().edit().remove("pos_$vid").apply()
                controls.visibility = View.VISIBLE
            } else if (state == 1 && controls.visibility == View.VISIBLE) {
                showControls()
            }
            lastState = state
        }
        val now = SystemClock.elapsedRealtime()
        if (playing && cur > 5 && now - lastSave > 5000) {
            lastSave = now
            savePos()
        }
    }

    private fun showError() {
        loading.visibility = View.GONE
        errorView.visibility = View.VISIBLE
    }

    private fun savePos() {
        if (vid.isEmpty()) return
        val nearEnd = dur > 0 && cur > dur - 10
        if (cur > 5 && state != 0 && !nearEnd) sp().edit().putLong("pos_$vid", cur.toLong()).apply()
        else if (nearEnd || state == 0) sp().edit().remove("pos_$vid").apply()
    }

    private fun showControls() {
        controls.visibility = View.VISIBLE
        ui.removeCallbacks(hideControls)
        if (state == 1) ui.postDelayed(hideControls, 3000)
    }

    private fun skip(d: Double) {
        val max = if (dur > 0) dur else Double.MAX_VALUE
        val t = (cur + d).coerceIn(0.0, max)
        cur = t
        Sfx.play(Sfx.S.SKIP)
        js("nx.seek($t)")
        flash.text = if (d < 0) "-$step" else "+$step"
        flash.visibility = View.VISIBLE
        ui.removeCallbacks(hideFlash)
        ui.postDelayed(hideFlash, 600)
        showControls()
    }

    private fun pchip(s: String, on: Boolean, click: () -> Unit): TextView = TextView(this).apply {
        text = s
        textSize = 13f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        setPadding(dp(14), 0, dp(14), 0)
        setBackgroundResource(R.drawable.pchip_bg)
        isSelected = on
        layoutParams = LinearLayout.LayoutParams(WRAP, dp(34)).apply { marginEnd = dp(8) }
        setOnClickListener { click() }
    }

    private fun setStep(v: Int) {
        step = v
        sp().edit().putInt("step", v).apply()
        steps.forEachIndexed { j, n -> stepChips[j].isSelected = n == v }
        updateStepLabels()
    }

    private fun updateStepLabels() {
        rewTxt.text = "-$step"
        fwdTxt.text = "+$step"
    }

    private fun openSettings() {
        ui.removeCallbacks(hideControls)
        settings.visibility = View.VISIBLE
    }

    private fun closeSettings() {
        settings.visibility = View.GONE
        showControls()
    }

    private fun retry() {
        val w = web ?: return
        errorView.visibility = View.GONE
        loading.visibility = View.VISIBLE
        gotState = false
        state = -2
        openedAt = SystemClock.elapsedRealtime()
        val from = if (cur > 5) cur.toInt() else startAt
        w.loadDataWithBaseURL("https://www.youtube-nocookie.com", page(vid, from), "text/html", "utf-8", null)
    }

    private fun setRate(i: Int) {
        want = rates[i]
        sp().edit().putFloat("rate", want.toFloat()).apply()
        chips.forEachIndexed { j, c -> c.isSelected = j == i }
        rateTxt.text = rateLabels[i]
        js("nx.rate($want)")
    }

    @Suppress("DEPRECATION")
    private fun setFull(on: Boolean, byUser: Boolean) {
        if (byUser) Sfx.play(Sfx.S.TAB)
        full = on
        header.visibility = if (on) View.GONE else View.VISIBLE
        panel.visibility = if (on) View.GONE else View.VISIBLE
        val lpf = frame.layoutParams as LinearLayout.LayoutParams
        lpf.height = if (on) 0 else portraitH
        lpf.weight = if (on) 1f else 0f
        frame.layoutParams = lpf
        fullBtn.setImageResource(if (on) R.drawable.ic_p_full_exit else R.drawable.ic_p_full)

        val d = window.decorView
        if (on) {
            d.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            if (byUser) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            d.systemUiVisibility = if (Prefs.dark(this)) 0 else light
            if (byUser) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                ui.postDelayed({ requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }, 1500)
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val land = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (land != full) setFull(land, false)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (settings.visibility == View.VISIBLE) closeSettings()
        else if (full) setFull(false, true)
        else super.onBackPressed()
    }

    private fun fmt(t: Double): String {
        val s = if (t.isNaN() || t < 0) 0 else t.toInt()
        val hh = s / 3600
        val mm = (s % 3600) / 60
        val ss = s % 60
        return if (hh > 0) String.format(Locale.ENGLISH, "%d:%02d:%02d", hh, mm, ss)
        else String.format(Locale.ENGLISH, "%d:%02d", mm, ss)
    }

    override fun onResume() {
        super.onResume()
        web?.onResume()
        ui.removeCallbacks(tick)
        ui.post(tick)
    }

    override fun onPause() {
        savePos()
        js("nx.pause()")
        ui.removeCallbacksAndMessages(null)
        web?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        web?.destroy()
        super.onDestroy()
    }
}
