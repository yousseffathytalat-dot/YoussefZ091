package com.moknight.nexoraedu

import android.content.res.Resources

/** Accent themes (the gradient of buttons, chips, progress bars and the avatar). "nexora" = the normal colours of each side (student / teacher / admin). */
object Accents {
    const val DEFAULT = "nexora"

    class Accent(val id: String, val name: Int, val c1: Int, val c2: Int, val style: Int)

    val all: List<Accent> = listOf(
        Accent(DEFAULT, R.string.th_nexora, R.color.p1, R.color.p2, 0),
        Accent("ocean", R.string.th_ocean, R.color.th_ocean_1, R.color.th_ocean_2, R.style.Accent_ocean),
        Accent("emerald", R.string.th_emerald, R.color.th_emerald_1, R.color.th_emerald_2, R.style.Accent_emerald),
        Accent("sunset", R.string.th_sunset, R.color.th_sunset_1, R.color.th_sunset_2, R.style.Accent_sunset),
        Accent("rose", R.string.th_rose, R.color.th_rose_1, R.color.th_rose_2, R.style.Accent_rose),
        Accent("violet", R.string.th_violet, R.color.th_violet_1, R.color.th_violet_2, R.style.Accent_violet),
        Accent("gold", R.string.th_gold, R.color.th_gold_1, R.color.th_gold_2, R.style.Accent_gold),
        Accent("crimson", R.string.th_crimson, R.color.th_crimson_1, R.color.th_crimson_2, R.style.Accent_crimson),
        Accent("aurora", R.string.th_aurora, R.color.th_aurora_1, R.color.th_aurora_2, R.style.Accent_aurora),
        Accent("candy", R.string.th_candy, R.color.th_candy_1, R.color.th_candy_2, R.style.Accent_candy),
        Accent("lime", R.string.th_lime, R.color.th_lime_1, R.color.th_lime_2, R.style.Accent_lime),
        Accent("slate", R.string.th_slate, R.color.th_slate_1, R.color.th_slate_2, R.style.Accent_slate),
    )

    fun find(id: String): Accent = all.firstOrNull { it.id == id } ?: all[0]

    /** Called by [BaseActivity] before any view is built. */
    fun apply(a: BaseActivity) {
        val s = find(Prefs.accent(a)).style
        if (s != 0) a.theme.applyStyle(s, true)
    }
}
