LOCAL BUILD (server OFF): Remote.BASE_URL and Remote.ANON_KEY are empty, so Remote.enabled is false and the app runs only on local data (same as before release 52).
To connect it to the server again, paste the Supabase URL + publishable key back into Remote.kt (see HANDOFF.md in NexoraEdu-All).

# NEXORA EDU (Android, native)
Native Android app: screens are XML layouts (app/src/main/res/layout), logic is Kotlin.

## Status
- Phase 1: login, sign up, teacher account, settings (dark/light, Arabic/English).
- Phase 2 (this build): chapters, lessons, YouTube videos, PDF books and files, favorites / review later / important,
  notes and watch history (per student), study progress.
- Phase 2b: new in-app video player (native controls over the YouTube player: speed 0.5x-2x, +/-10s buttons and double-tap, seek bar, full screen, resume position).
- Phase 3 (release 14, 1.4.0): exams and homework (teacher + student), see below. Student management is in the admin side.
- Phase 4a (this build): admin side (AdminActivity), see below.
- Phase 4b (next): update, backup.

- Profile photo (1.2.1): Profile tab -> round photo with add / change / remove; the header avatar shows it too. Saved as a JPEG (max 512 px) in `filesDir/avatars/<email, other chars as _>.jpg` (`Store.avatarFile`, `StudentActivity.avatarBlock`); deleted with the student. Strings in `strings_photo.xml`.

- Themes (1.3.0, UI changed in 1.6.0): the colours are one horizontal strip of circles in the full settings screen (`ShellActivity.openSettings`, section "App colour"). `Nexora` keeps the colours of each side; 11 accent themes (`Accents.kt`, colours `th_<id>_1/_2` in `colors.xml`, styles `Accent.<id>` in `themes.xml`, names in `strings_themes.xml`) override p1/p2 for every side. Saved as `accent` in `Prefs`; `BaseActivity` applies it. Windows and iPhone use the same ids and colours.

## Exams and homework (1.4.0, port of the Windows screens)
Same keys as before (`questions`, `exams`, `results`, `homework`, `subs`; photos in `filesDir/hw/<name>`); strings in `strings_exams.xml`.
- Teacher, Exams tab (`TeacherActivity.examsTab`): chips Exams / Question bank / Homework, each with its add button.
  Questions: text, optional chapter, 2-4 options (empty ones are dropped), the right option; delete also removes the question from every exam (`Store.deleteQuestion`).
  Exams: title, practice / official, tick the questions; tap an exam for the students' latest results (best first); delete removes its results.
  Homework: title + note; tap one to read the students' answers (text + photo) and grade 0-10 with a note; delete removes the answers and photos.
  Home shows two more counters: exams and answers waiting for a grade.
- Student, Exams tab (`StudentActivity.examsTab`): chips Exams / Homework. Exams: official average, list with the last result; tap = one question at a time
  (previous / next, submit; a warning if something is unanswered), result + review of every answer, retake. A result is saved only when the student submits (`Store.addResult`).
  Homework: list with status (not submitted / waiting / graded n of 10); the form has a text answer + one photo (`Store.savePhoto`, max 1280 px). The picked photo waits in
  `Store.draftPhoto` until the answer is sent; sending again replaces the old answer and clears the grade.
- No timer, questions are not shuffled, no admin screens for exams (same as Windows).

## Admin side
How to open it (no button, tab or text on the normal sign-in screen shows it):
- On the sign-in screen, press and hold the flask logo for 7 full seconds. Lifting the finger (or sliding it off the logo) before that cancels the count and the next press starts from zero.
  There is no hint, progress bar or vibration while holding; at 7 seconds one light vibration, then the admin sign-in appears.
- First time (no admin account yet) the same screen is "Create admin account": email, password (6+ characters) and confirm password.
  After that it is a normal sign-in (email + password). "Back" returns to the normal sign-in.
- The admin account is stored under its own keys (`a_email`, `a_pw` as SHA-256), separate from the teacher. The session role is `admin` in `s_role`;
  Splash opens the admin side when a valid admin session exists.

Admin tabs (same shell, header, settings screen as the other sides, own gold/orange theme `ap1`/`ap2`):
- Dashboard: counters (students, classes, chapters, lessons, books and files) and the same add buttons as the teacher.
- Teacher: the teacher email, change the teacher password, delete the teacher account (the next teacher sign-in creates a new account; students and content stay).
- Students: search by name or email, filter by class, and on every card: active/inactive, student code (generate, copy, new code), delete with confirmation.
- Content: all chapters, lessons, videos, books and files with delete + confirmation, the same add buttons, and the class list (add / delete a class).
- My account: admin email and change password (current + new).

Note: AdminActivity repeats the teacher's add sheets on purpose, so TeacherActivity was not touched.
Not built here: there is no Android toolchain in the build environment, so compile it with Actions or Android Studio.

## Release 16 (1.6.0) - what changed in the UI
- Launch animation (`SplashView.kt`) is unchanged on purpose: atoms form the icon square, more atoms draw the flask, then the real icon.
- Login: "Create a new account" + drawn checkbox under the button (`DrawnCheck`); ticking it grows the card and shows confirm password, phone (optional) and, for students, name + class. Same for the teacher tab. Student / Teacher is a `SegControl` (one sliding indicator).
- Bottom bar: floating glass capsule with a sliding bounce indicator; student = Home / Subjects / Tests / Account, teacher = Home / Students / Content / Tests (teacher profile opens from the header avatar).
- Settings is a full screen (`screen_settings.xml`): Language, Appearance, App colour, Log out. Arabic = RTL, English = LTR (layouts use `layoutDirection="locale"`).
- `Widgets.kt` holds `SegControl`, `DrawnCheck`, `animateRow`, `iconHop`, `lockWiggle`, `eyeBlink`, `drawTick`.
- Not built here: no Android toolchain, compile with Actions.

## Release 28 (1.8.1) - phone verification screen, round 1
- New `OtpView.kt`: the code entry screen as a glass bottom sheet (`OtpView(activity, phone, verify, onResend, onVerified, onCancel).show()`). 6 boxes over one invisible input, wrong-code state (red boxes, shake, `otp_err_wrong`), verify button dimmed until 6 digits, resend link with a real 60 s countdown (`otp_resend_in`, then `otp_resend`).
- `OtpConfig.PhoneOtpEnabled = false`: `show()` returns false and shows nothing while the flag is false. Not connected to `LoginActivity` yet (round 2). No server: `verify` / `onResend` come from the caller.
- Strings: `strings_otp.xml` (values + values-en). versionCode 11.
- Not built here (no Android toolchain): compile with Actions or Android Studio.

## Release 29 (1.8.2) - phone rules + glass entry
- `PhoneRules.kt`: `PhoneRules.normalize / error`, `PhoneVerifier` (the one place to connect an SMS backend). Student sign-up: phone required, message under the field (`phoneError` in `activity_login.xml`), `OtpView` opens before the account is created only while `OtpConfig.PhoneOtpEnabled` is true. Teacher unchanged (phone optional).
- `SplashView`: `TOTAL` 3300 ms (timeline 4300 ms played 1.3x), glass plate + beads (`drawGlass`). `SplashActivity` routes at 3.65 s. Strings: `strings_phone.xml`. versionCode 12.

## Release 33 (1.8.5) - announcement editing + themes sheet like iPhone / Windows
- Teacher, Content tab: an announcement now has a pencil button (and tapping the row) that opens the same sheet to edit title and text; the posting date stays. `addAnnouncementSheet(existing)`.
- Settings: the "App colour" row is gone. A palette button in the header (like iPhone / Windows) opens the themes sheet (`th_title`, 3 per row, bold name on the chosen one, close link). Same ids and colours as before. `app_color` string is no longer used.
- Not built here (no Android toolchain): compile with Actions.

## Release 34 (1.8.6) - themes sheet: rounded tiles instead of circles
The themes sheet (palette button in Settings) now shows rounded gradient tiles, 2 per row, each with the theme name in white; the chosen one has a ring and a tick. Same on iPhone (`ThemesSheet`) and Windows (`Ui.OpenThemes`). Same ids and colours.

## Sound effects (1.8.15)
Short interface sounds, all synthesized by `tools/make_sfx.py` (no outside samples) into `app/src/main/res/raw/sfx_*.wav`; played by `Sfx.kt` (one SoundPool).
- Where: every tappable view (soft tap, from `pressable` in Glass.kt; skipped when a more specific sound plays at the same moment), bottom tabs and segmented controls (tab), chips and exam options (select), switches / check box (on / off), sheets (open / close), delete confirm (delete), locked lesson (locked), every toast (success / error / notice, chosen from the string name: `err_*`, `*_saved`, `*_copied`...), sign-in (success / error), OTP code, exam result (pass from 50% / fail), homework sent, video (play, pause, skip 10 s, full screen), PDF missing file, launch animation (3.3 s, the burst lands on the icon flash).
- Follows the phone: silent / vibrate mode mutes it and so does the system "Touch sounds" switch. No new strings, no new screen.
- To change a sound: edit `tools/make_sfx.py`, run `python3 tools/make_sfx.py`, rebuild. To change where one plays: `Sfx.play(Sfx.S.<NAME>)`.
